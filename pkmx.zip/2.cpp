#include <iostream>
#include <vector>
#include <string>
#include <filesystem>
#include <atomic>
#include <mutex>
#include <sys/wait.h>
#include <unistd.h>

namespace fs = std::filesystem;

class TextureConverter {
    std::atomic<size_t> success_count{0};
    std::atomic<size_t> fail_count{0};
    std::mutex output_mutex;

    // 检查文件扩展名是否支持
    bool is_supported_extension(const std::string& extension) {
        return extension == ".png" || extension == ".webp";
    }

    // 处理单个文件转换
    bool convert_file(const fs::path& input_path, const fs::path& output_path, const std::string& mode) {
        try {
            std::string cmd = "etcpack \"" + input_path.string() + "\" \"" + 
                            output_path.string() + "\" -s " + mode + " -c etc1";
            return std::system(cmd.c_str()) == 0;
        } catch (...) {
            return false;
        }
    }

    // 工作进程主函数
    void worker_process(const std::vector<fs::path>& files, const std::string& mode) {
        for (const auto& file : files) {
            fs::path output_path = file;
            output_path.replace_extension(".pkm");
            
            bool success = convert_file(file, output_path, mode);
            success ? ++success_count : ++fail_count;
            
            // 安全地输出进度
            {
                std::lock_guard<std::mutex> lock(output_mutex);
                std::cout << "\r处理进度: " << (success_count + fail_count) 
                          << "/" << total_files << std::flush;
            }
        }
    }

    size_t total_files;
    size_t worker_count;

public:
    // 查找所有支持的图像文件
    std::vector<fs::path> find_supported_images() {
        std::vector<fs::path> supported_files;
        
        for (const auto& entry : fs::directory_iterator(".")) {
            if (entry.is_regular_file() && 
                is_supported_extension(entry.path().extension().string())) {
                supported_files.push_back(entry.path());
            }
        }
        
        return supported_files;
    }

    // 主转换函数
    void convert(const std::string& mode) {
        auto image_files = find_supported_images();
        if (image_files.empty()) {
            std::cout << "错误：未找到支持的图像文件(.png/.webp)\n";
            return;
        }

        total_files = image_files.size();
        worker_count = std::min<size_t>(sysconf(_SC_NPROCESSORS_ONLN), total_files);
        size_t files_per_worker = (total_files + worker_count - 1) / worker_count;

        std::cout << "使用 " << worker_count << " 个工作进程处理 " 
                  << total_files << " 个文件...\n";

        std::vector<pid_t> child_processes;
        
        // 创建子进程
        for (size_t i = 0; i < worker_count; ++i) {
            size_t start = i * files_per_worker;
            size_t end = std::min(start + files_per_worker, total_files);
            std::vector<fs::path> worker_files(image_files.begin() + start, 
                                             image_files.begin() + end);

            pid_t pid = fork();
            if (pid == 0) { // 子进程
                worker_process(worker_files, mode);
                _exit(0);
            } else if (pid > 0) { // 父进程
                child_processes.push_back(pid);
            } else {
                std::cerr << "创建子进程失败\n";
            }
        }

        // 等待所有子进程完成
        for (auto pid : child_processes) {
            waitpid(pid, nullptr, 0);
        }

        std::cout << "\n转换完成: 成功 " << success_count 
                  << " | 失败 " << fail_count << "\n";
    }
};

void show_usage() {
    std::cout << "纹理压缩处理系统 (多进程版)\n"
              << "---------------------------\n"
              << "支持格式: PNG, WebP → PKM (ETC1压缩格式)\n\n";
}

std::string get_user_mode() {
    while (true) {
        std::cout << "请选择压缩模式:\n"
                  << "1. 慢速模式 (质量优先)\n"
                  << "2. 快速模式 (速度优先)\n"
                  << "选择 (1/2): ";
        
        std::string choice;
        std::cin >> choice;
        
        if (choice == "1") return "slow";
        if (choice == "2") return "fast";
        
        std::cout << "无效输入，请重新输入\n";
    }
}

int main() {
    show_usage();
    
    TextureConverter converter;
    auto image_files = converter.find_supported_images();
    if (image_files.empty()) {
        std::cout << "错误：未找到可处理的图像文件(.png/.webp)\n";
        return 1;
    }

    std::cout << "发现 " << image_files.size() << " 个可处理文件\n";
    std::string mode = get_user_mode();
    
    converter.convert(mode);
    return 0;
}
