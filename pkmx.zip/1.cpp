#include <iostream>
#include <vector>
#include <string>
#include <filesystem>
#include <chrono>
#include <thread>
#include <mutex>
#include <queue>
#include <future>
#include <algorithm>
#include <fstream>

namespace fs = std::filesystem;
using namespace std::chrono_literals;

class TextureConverter {
    const unsigned hw_concurrency;
    std::atomic<size_t> success_count{0};
    std::atomic<size_t> fail_count{0};
    std::vector<double> time_records;
    std::mutex record_mutex;

    // 获取系统负载 (Android兼容版)
    double get_loadavg() {
        std::ifstream loadavg("/proc/loadavg");
        double load = 0;
        if (loadavg) loadavg >> load;
        return load;
    }

    // 执行单文件转换
    bool convert_file(const fs::path& png_path, const std::string& mode) {
        auto pkm_path = png_path;
        pkm_path.replace_extension(".pkm");
        
        try {
            auto start = std::chrono::high_resolution_clock::now();
            
            std::string cmd = "etcpack -s " + mode + " -c etc1 \"" + 
                             png_path.string() + "\" \"" + 
                             pkm_path.string() + "\"";
            
            int ret = std::system(cmd.c_str());
            if (ret != 0) throw std::runtime_error("Command failed");
            
            auto duration = std::chrono::duration_cast<std::chrono::duration<double>>(
                std::chrono::high_resolution_clock::now() - start).count();
            
            {
                std::lock_guard lock(record_mutex);
                time_records.push_back(duration);
            }
            
            return true;
        } catch (...) {
            return false;
        }
    }

    // 工作线程函数
    void worker(const std::vector<std::string>& files, const std::string& mode) {
        for (const auto& file : files) {
            bool status = convert_file(file, mode);
            
            if (get_loadavg() > hw_concurrency * 0.8) {
                std::this_thread::sleep_for(50ms);
            }
            
            status ? ++success_count : ++fail_count;
            
            static std::mutex io_mutex;
            {
                std::lock_guard lock(io_mutex);
                std::cout << "\r进度: " << success_count << "/" 
                          << (success_count + fail_count) << std::flush;
            }
        }
    }

    // 智能分块算法
    std::vector<std::vector<std::string>> make_chunks(
        const std::vector<fs::path>& files, 
        double file_time) 
    {
        const double target_chunk_time = 0.5;
        size_t ideal_chunk = std::max<size_t>(1, target_chunk_time / file_time);
        size_t max_chunk = std::max<size_t>(10, files.size() / (hw_concurrency * 2));
        size_t chunk_size = std::min(ideal_chunk, max_chunk);
        
        std::vector<std::vector<std::string>> chunks;
        for (size_t i = 0; i < files.size(); i += chunk_size) {
            auto end = std::min(i + chunk_size, files.size());
            chunks.emplace_back();
            for (size_t j = i; j < end; ++j) {
                chunks.back().push_back(files[j].string());
            }
        }
        return chunks;
    }

public:
    TextureConverter() : hw_concurrency(std::thread::hardware_concurrency()) {}

    // 查找PNG文件
    static std::vector<fs::path> find_png_files() {
        std::vector<fs::path> files;
        for (const auto& entry : fs::directory_iterator(".")) {
            if (entry.is_regular_file() && 
                entry.path().extension() == ".png") {
                files.push_back(entry.path());
            }
        }
        return files;
    }

    // 主转换逻辑
    void convert(const std::string& mode) {
        auto png_files = find_png_files();
        if (png_files.empty()) {
            std::cout << "错误：未找到PNG文件\n";
            return;
        }

        // 简单基准测试
        auto start = std::chrono::high_resolution_clock::now();
        convert_file(png_files.front(), mode);
        double file_time = std::chrono::duration<double>(
            std::chrono::high_resolution_clock::now() - start).count();
        
        auto chunks = make_chunks(png_files, file_time);
        std::cout << "智能分块: " << png_files.size() << "文件 → " 
                  << chunks.size() << "任务块\n";

        // 工作线程池
        unsigned workers = std::max(1u, static_cast<unsigned>(hw_concurrency * 0.75));
        std::vector<std::thread> thread_pool;
        for (unsigned i = 0; i < workers && i < chunks.size(); ++i) {
            thread_pool.emplace_back(
                &TextureConverter::worker, this, 
                std::ref(chunks[i]), mode);
        }

        // 等待完成
        for (auto& t : thread_pool) {
            if (t.joinable()) t.join();
        }

        // 性能报告
        auto min_time = *std::min_element(time_records.begin(), time_records.end());
        std::cout << "\n转换完成: 成功 " << success_count 
                  << " | 失败 " << fail_count << "\n";
        std::cout << "峰值效率: " << (1.0 / min_time) << " 文件/秒\n";
    }
};

int main() {
    std::cout << "纹理压缩智能处理系统 (Termux兼容版)\n"
              << "---------------------------\n";

    TextureConverter converter;
    auto png_files = TextureConverter::find_png_files();
    if (png_files.empty()) {
        std::cout << "错误：未找到可处理的PNG文件\n";
        return 1;
    }

    std::cout << "系统检测: CPU核心=" << std::thread::hardware_concurrency() 
              << " 待处理文件=" << png_files.size() << "\n";
    std::cout << "\n模式选择:\n"
              << "1. 慢速模式 (质量优先)\n"
              << "2. 快速模式 (速度优先)\n";

    while (true) {
        std::cout << "请选择模式 (1/2): ";
        std::string choice;
        std::cin >> choice;
        
        if (choice == "1") {
            converter.convert("slow");
            break;
        } else if (choice == "2") {
            converter.convert("fast");
            break;
        }
        std::cout << "无效输入，请重新输入\n";
    }

    return 0;
}
