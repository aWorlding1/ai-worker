#include <iostream>
#include <vector>
#include <string>
#include <filesystem>
#include <atomic>
#include <mutex>
#include <sys/wait.h>
#include <unistd.h>

namespace fs = std::filesystem;

class TextureConverter {
    std::atomic<size_t> success_count{0};
    std::atomic<size_t> fail_count{0};
    std::mutex output_mutex;

    // 检查文件扩展名是否支持
    bool is_supported_extension(const std::string& extension) {
        return extension == ".png" || extension == ".webp";
    }

    // 在工作目录中处理单个文件
    bool process_in_workspace(const fs::path& workspace, 
                             const fs::path& input_path, 
                             const std::string& mode) {
        try {
            // 准备路径
            fs::path filename = input_path.filename();
            fs::path workspace_input = workspace / filename;
            fs::path workspace_output = workspace / filename.stem().concat(".pkm");
            fs::path final_output = input_path;
            final_output.replace_extension(".pkm");

            // 复制源文件到工作目录
            fs::copy_file(input_path, workspace_input, fs::copy_options::overwrite_existing);

            // 执行转换命令
            std::string cmd = "cd \"" + workspace.string() + "\" && etcpack \"" + 
                             filename.string() + "\" \"" + 
                             workspace_output.filename().string() + "\" -s " + mode + " -c etc1";
            
            int ret = std::system(cmd.c_str());
            if (ret != 0) {
                return false;
            }

            // 将结果文件移回原目录
            if (fs::exists(workspace_output)) {
                fs::rename(workspace_output, final_output);
                return true;
            }
            return false;
        } catch (const std::exception& e) {
            std::lock_guard<std::mutex> lock(output_mutex);
            std::cerr << "\n处理文件 " << input_path << " 时出错: " << e.what() << std::endl;
            return false;
        }
    }

    // 工作进程主函数
    void worker_process(const std::vector<fs::path>& files, const std::string& mode) {
        // 为每个工作进程创建唯一的工作目录
        std::string workspace_dir = "worker_" + std::to_string(getpid());
        fs::create_directory(workspace_dir);

        try {
            for (const auto& file : files) {
                bool success = process_in_workspace(workspace_dir, file, mode);
                success ? ++success_count : ++fail_count;

                // 更新进度显示
                {
                    std::lock_guard<std::mutex> lock(output_mutex);
                    std::cout << "\r处理进度: " << (success_count + fail_count) 
                              << "/" << total_files << std::flush;
                }
            }
        } catch (...) {
            ++fail_count;
        }

        // 清理工作目录
        fs::remove_all(workspace_dir);
    }

    size_t total_files;
    size_t worker_count;

public:
    // 查找所有支持的图像文件
    std::vector<fs::path> find_supported_images() {
        std::vector<fs::path> supported_files;
        
        for (const auto& entry : fs::directory_iterator(".")) {
            if (entry.is_regular_file() && 
                is_supported_extension(entry.path().extension().string())) {
                supported_files.push_back(entry.path());
            }
        }
        
        return supported_files;
    }

    // 主转换函数
    void convert(const std::string& mode) {
        auto image_files = find_supported_images();
        if (image_files.empty()) {
            std::cout << "错误：未找到支持的图像文件(.png/.webp)\n";
            return;
        }

        total_files = image_files.size();
        worker_count = std::min<size_t>(sysconf(_SC_NPROCESSORS_ONLN), total_files);
        size_t files_per_worker = (total_files + worker_count - 1) / worker_count;

        std::cout << "使用 " << worker_count << " 个工作进程处理 " 
                  << total_files << " 个文件...\n";

        std::vector<pid_t> child_processes;
        
        // 创建子进程
        for (size_t i = 0; i < worker_count; ++i) {
            size_t start = i * files_per_worker;
            size_t end = std::min(start + files_per_worker, total_files);
            std::vector<fs::path> worker_files(image_files.begin() + start, 
                                             image_files.begin() + end);

            pid_t pid = fork();
            if (pid == 0) { // 子进程
                worker_process(worker_files, mode);
                _exit(0);
            } else if (pid > 0) { // 父进程
                child_processes.push_back(pid);
            } else {
                std::cerr << "创建子进程失败\n";
            }
        }

        // 等待所有子进程完成
        for (auto pid : child_processes) {
            waitpid(pid, nullptr, 0);
        }

        std::cout << "\n转换完成: 成功 " << success_count 
                  << " | 失败 " << fail_count << "\n";

        // 最终检查
        if (fail_count > 0) {
            std::cout << "警告：部分文件转换失败，请检查错误信息\n";
        }
    }
};

// 显示程序使用说明
void show_usage() {
    std::cout << "================================\n"
              << " 纹理压缩处理系统 (安全多进程版)\n"
              << "================================\n"
              << "功能特性:\n"
              << "- 支持格式: PNG, WebP → PKM (ETC1压缩格式)\n"
              << "- 自动多进程并行处理\n"
              << "- 安全隔离临时文件\n"
              << "- 实时进度显示\n\n";
}

// 获取用户选择的模式
std::string get_user_mode() {
    while (true) {
        std::cout << "请选择压缩模式:\n"
                  << "1. 慢速模式 (质量优先)\n"
                  << "2. 快速模式 (速度优先)\n"
                  << "选择 (1/2): ";
        
        std::string choice;
        std::cin >> choice;
        
        if (choice == "1") return "slow";
        if (choice == "2") return "fast";
        
        std::cout << "无效输入，请重新输入\n";
    }
}

int main() {
    show_usage();
    
    TextureConverter converter;
    auto image_files = converter.find_supported_images();
    if (image_files.empty()) {
        std::cout << "错误：当前目录未找到可处理的图像文件(.png/.webp)\n";
        return 1;
    }

    std::cout << "发现 " << image_files.size() << " 个可处理文件\n";
    std::string mode = get_user_mode();
    
    converter.convert(mode);
    return 0;
}
