/**
 * 纹理压缩处理系统 - 优化版
 * 支持多进程并行处理 PNG/WebP 到 PKM (ETC1) 格式转换
 * 特性: 进程池管理、智能负载均衡、实时进度显示、错误恢复
 */

#include <iostream>
#include <vector>
#include <string>
#include <filesystem>
#include <atomic>
#include <mutex>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <memory>
#include <cstring>
#include <sys/wait.h>
#include <sys/mman.h>
#include <unistd.h>
#include <signal.h>

namespace fs = std::filesystem;
using Clock = std::chrono::steady_clock;
using TimePoint = std::chrono::time_point<Clock>;

// 共享内存结构用于进程间通信
struct SharedData {
    std::atomic<size_t> success_count{0};
    std::atomic<size_t> fail_count{0};
    std::atomic<size_t> processing_count{0};
    std::atomic<bool> should_stop{false};
    char error_buffer[4096]{0};
};

// 进度显示器类
class ProgressDisplay {
private:
    size_t total_files;
    TimePoint start_time;
    mutable std::mutex mutex;
    bool is_active{true};

public:
    explicit ProgressDisplay(size_t total) 
        : total_files(total), start_time(Clock::now()) {}

    void update(size_t completed, size_t failed) const {
        std::lock_guard<std::mutex> lock(mutex);
        if (!is_active) return;

        auto now = Clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - start_time).count();
        
        size_t processed = completed + failed;
        double progress = static_cast<double>(processed) / total_files * 100.0;
        
        // 计算预估剩余时间
        std::string eta_str = "计算中...";
        if (processed > 0 && elapsed > 0) {
            double rate = static_cast<double>(processed) / elapsed;
            if (rate > 0) {
                size_t remaining = total_files - processed;
                size_t eta_seconds = static_cast<size_t>(remaining / rate);
                
                size_t hours = eta_seconds / 3600;
                size_t minutes = (eta_seconds % 3600) / 60;
                size_t seconds = eta_seconds % 60;
                
                std::ostringstream oss;
                if (hours > 0) {
                    oss << hours << "h " << minutes << "m";
                } else if (minutes > 0) {
                    oss << minutes << "m " << seconds << "s";
                } else {
                    oss << seconds << "s";
                }
                eta_str = oss.str();
            }
        }

        // 绘制进度条
        const int bar_width = 40;
        int filled = static_cast<int>(progress * bar_width / 100.0);
        
        std::cout << "\r[";
        for (int i = 0; i < bar_width; ++i) {
            if (i < filled) std::cout << "█";
            else std::cout << "░";
        }
        std::cout << "] " << std::fixed << std::setprecision(1) << progress << "% "
                  << "(" << processed << "/" << total_files << ") "
                  << "成功:" << completed << " 失败:" << failed << " "
                  << "ETA:" << eta_str << "  " << std::flush;
    }

    void finish(size_t completed, size_t failed) {
        std::lock_guard<std::mutex> lock(mutex);
        is_active = false;
        
        auto now = Clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - start_time).count();
        
        std::cout << "\r[";
        for (int i = 0; i < 40; ++i) std::cout << "█";
        std::cout << "] 100.0% (" << (completed + failed) << "/" << total_files << ") "
                  << "成功:" << completed << " 失败:" << failed << " "
                  << "耗时:" << elapsed << "s    \n";
    }
};

// 纹理转换器核心类
class TextureConverter {
private:
    SharedData* shared_data;
    size_t total_files{0};
    size_t worker_count{0};
    std::unique_ptr<ProgressDisplay> progress;
    std::vector<std::string> supported_extensions{".png", ".webp"};

    // 检查文件扩展名
    bool is_supported_extension(const std::string& ext) const {
        std::string lower_ext = ext;
        std::transform(lower_ext.begin(), lower_ext.end(), lower_ext.begin(), ::tolower);
        return std::find(supported_extensions.begin(), supported_extensions.end(), 
                        lower_ext) != supported_extensions.end();
    }

    // 在隔离工作区处理单个文件
    bool process_file_safely(const fs::path& workspace, 
                            const fs::path& input_path, 
                            const std::string& mode) {
        try {
            fs::path filename = input_path.filename();
            fs::path workspace_input = workspace / filename;
            fs::path workspace_output = workspace / filename.stem().concat(".pkm");
            fs::path final_output = input_path.parent_path() / workspace_output.filename();

            // 复制输入文件到工作区
            if (!fs::copy_file(input_path, workspace_input, 
                              fs::copy_options::overwrite_existing)) {
                return false;
            }

            // 构建并执行转换命令
            std::ostringstream cmd;
            cmd << "cd \"" << workspace.string() << "\" 2>/dev/null && "
                << "etcpack \"" << filename.string() << "\" \""
                << workspace_output.filename().string() << "\" "
                << "-s " << mode << " -c etc1 >/dev/null 2>&1";

            int ret = std::system(cmd.str().c_str());
            
            // 检查转换结果
            if (ret != 0 || !fs::exists(workspace_output)) {
                return false;
            }

            // 验证输出文件大小
            if (fs::file_size(workspace_output) == 0) {
                fs::remove(workspace_output);
                return false;
            }

            // 移动结果到目标位置
            if (fs::exists(final_output)) {
                fs::remove(final_output);
            }
            fs::rename(workspace_output, final_output);

            // 清理工作区输入文件
            fs::remove(workspace_input);
            return true;

        } catch (const std::exception& e) {
            return false;
        }
    }

    // 工作进程主逻辑
    void worker_process(const std::vector<fs::path>& files, 
                       const std::string& mode, 
                       int worker_id) {
        // 创建唯一工作目录
        std::ostringstream workspace_name;
        workspace_name << "worker_" << worker_id << "_" << getpid();
        fs::path workspace = workspace_name.str();

        try {
            fs::create_directory(workspace);

            for (const auto& file : files) {
                if (shared_data->should_stop.load()) {
                    break;
                }

                ++shared_data->processing_count;
                bool success = process_file_safely(workspace, file, mode);
                --shared_data->processing_count;

                if (success) {
                    ++shared_data->success_count;
                } else {
                    ++shared_data->fail_count;
                }

                // 更新进度（降低更新频率以减少锁竞争）
                static std::atomic<size_t> update_counter{0};
                if (++update_counter % 5 == 0 || success) {
                    progress->update(shared_data->success_count.load(), 
                                   shared_data->fail_count.load());
                }
            }

        } catch (const std::exception& e) {
            shared_data->fail_count += files.size();
        }

       // 清理工作目录
        try {
            if (fs::exists(workspace)) {
                fs::remove_all(workspace);
            }
        } catch (...) {}

        _exit(0);
    }

    // 分配文件到各个工作进程（负载均衡）
    std::vector<std::vector<fs::path>> distribute_files(
        const std::vector<fs::path>& files, size_t num_workers) {
        
        std::vector<std::vector<fs::path>> distributions(num_workers);
        
        // 简单轮询分配
        for (size_t i = 0; i < files.size(); ++i) {
            distributions[i % num_workers].push_back(files[i]);
        }

        return distributions;
    }

    // 初始化共享内存
    bool init_shared_memory() {
        shared_data = static_cast<SharedData*>(
            mmap(nullptr, sizeof(SharedData), 
                 PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0)
        );

        if (shared_data == MAP_FAILED) {
            std::cerr << "共享内存初始化失败\n";
            return false;
        }

        new (shared_data) SharedData();
        return true;
    }

    // 清理共享内存
    void cleanup_shared_memory() {
        if (shared_data != nullptr && shared_data != MAP_FAILED) {
            munmap(shared_data, sizeof(SharedData));
            shared_data = nullptr;
        }
    }

public:
    TextureConverter() : shared_data(nullptr) {}

    ~TextureConverter() {
        cleanup_shared_memory();
    }

    // 查找所有支持的图像文件
    std::vector<fs::path> find_supported_images(const fs::path& directory = ".") {
        std::vector<fs::path> supported_files;

        try {
            for (const auto& entry : fs::directory_iterator(directory)) {
                if (entry.is_regular_file()) {
                    std::string ext = entry.path().extension().string();
                    if (is_supported_extension(ext)) {
                        supported_files.push_back(entry.path());
                    }
                }
            }
        } catch (const std::exception& e) {
            std::cerr << "扫描目录失败: " << e.what() << "\n";
        }

        // 按文件名排序
        std::sort(supported_files.begin(), supported_files.end());
        return supported_files;
    }

    // 主转换函数
    bool convert(const std::string& mode, const std::vector<fs::path>& image_files) {
        if (image_files.empty()) {
            std::cerr << "错误: 没有可处理的文件\n";
            return false;
        }

        if (!init_shared_memory()) {
            return false;
        }

        total_files = image_files.size();
        worker_count = std::min<size_t>(
            static_cast<size_t>(sysconf(_SC_NPROCESSORS_ONLN)), 
            total_files
        );

        std::cout << "\n使用 " << worker_count << " 个工作进程处理 " 
                  << total_files << " 个文件\n";
        std::cout << "压缩模式: " << (mode == "slow" ? "慢速(高质量)" : "快速") << "\n\n";

        progress = std::make_unique<ProgressDisplay>(total_files);
        
        auto file_distributions = distribute_files(image_files, worker_count);
        std::vector<pid_t> child_processes;

        // 创建工作进程
        for (size_t i = 0; i < worker_count; ++i) {
            if (file_distributions[i].empty()) continue;

            pid_t pid = fork();
            if (pid == 0) {
                // 子进程
                worker_process(file_distributions[i], mode, static_cast<int>(i));
                _exit(0);
            } else if (pid > 0) {
                child_processes.push_back(pid);
            } else {
                std::cerr << "创建工作进程 " << i << " 失败\n";
            }
        }

        // 等待所有子进程完成
        for (auto pid : child_processes) {
            int status;
            waitpid(pid, &status, 0);
            if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
                std::cerr << "\n警告: 工作进程 " << pid << " 异常退出\n";
            }
        }

        // 显示最终结果
        size_t success = shared_data->success_count.load();
        size_t failed = shared_data->fail_count.load();
        progress->finish(success, failed);

        std::cout << "\n转换完成!\n";
        std::cout << "  成功: " << success << " 个文件\n";
        std::cout << "  失败: " << failed << " 个文件\n";

        cleanup_shared_memory();
        return failed == 0;
    }

    // 检查 etcpack 工具是否可用
    static bool check_etcpack_available() {
        int ret = std::system("which etcpack >/dev/null 2>&1");
        return ret == 0;
    }
};

// 显示使用说明
void show_banner() {
    std::cout << "\n";
    std::cout << "╔════════════════════════════════════════════════╗\n";
    std::cout << "║     纹理压缩处理系统 v2.0 (优化版)            ║\n";
    std::cout << "╚════════════════════════════════════════════════╝\n";
    std::cout << "\n功能特性:\n";
    std::cout << "  • 支持格式: PNG, WebP → PKM (ETC1)\n";
    std::cout << "  • 多进程并行处理\n";
    std::cout << "  • 智能负载均衡\n";
    std::cout << "  • 实时进度显示\n";
    std::cout << "  • 安全隔离临时文件\n";
    std::cout << "  • 错误恢复机制\n\n";
}

// 获取用户选择的压缩模式
std::string get_compression_mode() {
    while (true) {
        std::cout << "请选择压缩模式:\n";
        std::cout << "  1. 慢速模式 (质量优先, 压缩时间较长)\n";
        std::cout << "  2. 快速模式 (速度优先, 质量略低)\n";
        std::cout << "\n请输入选择 (1/2): ";

        std::string choice;
        if (!std::getline(std::cin, choice)) {
            std::cout << "\n";
            return "";
        }

        // 移除首尾空白
        choice.erase(0, choice.find_first_not_of(" \t\n\r"));
        choice.erase(choice.find_last_not_of(" \t\n\r") + 1);

        if (choice == "1") {
            return "slow";
        } else if (choice == "2") {
            return "fast";
        }

        std::cout << "无效输入，请输入 1 或 2\n\n";
    }
}

// 用户确认操作
bool confirm_action(const std::string& message) {
    std::cout << "\n" << message << " (y/n): ";
    std::string response;
    if (!std::getline(std::cin, response)) {
        return false;
    }

    response.erase(0, response.find_first_not_of(" \t\n\r"));
    response.erase(response.find_last_not_of(" \t\n\r") + 1);
    std::transform(response.begin(), response.end(), response.begin(), ::tolower);

    return response == "y" || response == "yes" || response == "是";
}

// 清理所有临时工作目录
void cleanup_workspaces() {
    try {
        for (const auto& entry : fs::directory_iterator(".")) {
            if (entry.is_directory()) {
                std::string dirname = entry.path().filename().string();
                if (dirname.find("worker_") == 0) {
                    fs::remove_all(entry.path());
                }
            }
        }
    } catch (...) {}
}

// 信号处理函数
void signal_handler(int signum) {
    std::cout << "\n\n收到中断信号，正在清理...\n";
    cleanup_workspaces();
    exit(signum);
}

int main() {
    // 注册信号处理
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    // 清理可能残留的工作目录
    cleanup_workspaces();

    show_banner();

    // 检查 etcpack 工具
    if (!TextureConverter::check_etcpack_available()) {
        std::cerr << "错误: 未找到 etcpack 工具\n";
        std::cerr << "请确保 etcpack 已安装并在系统 PATH 中\n";
        return 1;
    }

    // 创建转换器实例
    TextureConverter converter;

    // 查找可处理文件
    auto image_files = converter.find_supported_images();
    if (image_files.empty()) {
        std::cerr << "错误: 当前目录未找到可处理的图像文件 (.png/.webp)\n";
        return 1;
    }

    std::cout << "发现 " << image_files.size() << " 个可处理文件:\n";
    
    // 显示前几个文件作为示例
    size_t preview_count = std::min<size_t>(5, image_files.size());
    for (size_t i = 0; i < preview_count; ++i) {
        std::cout << "  • " << image_files[i].filename().string() << "\n";
    }
    if (image_files.size() > preview_count) {
        std::cout << "  ... 等 " << (image_files.size() - preview_count) << " 个文件\n";
    }
    std::cout << "\n";

    // 获取压缩模式
    std::string mode = get_compression_mode();
    if (mode.empty()) {
        std::cout << "操作已取消\n";
        return 0;
    }

    // 确认操作
    if (!confirm_action("确认开始处理?")) {
        std::cout << "操作已取消\n";
        return 0;
    }

    // 执行转换
    bool success = converter.convert(mode, image_files);

    // 清理临时目录
    cleanup_workspaces();

    std::cout << "\n";
    return success ? 0 : 1;
}
