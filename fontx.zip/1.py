#!/usr/bin/env python3
import re
from fontTools.ttLib import TTFont
from fontTools.subset import Subsetter, Options
import os

def extract_chars_from_text(text):
    """从文本中提取所有唯一字符（包括中文等UTF-8字符）"""
    chars = set(re.findall(r'[^\x00-\x1F\x7F-\xA0\u1680\u180E\u2000-\u200F\u2028-\u202F\u205F-\u206F\u3000]', text))
    return chars

def read_file_as_text(file_path):
    """将文件作为纯文本读取"""
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read()

def subset_font(font_path, chars, output_path):
    """子集化字体，只保留需要的字符"""
    font = TTFont(font_path)
    
    options = Options()
    options.desubroutinize = True
    options.hinting = False
    
    subsetter = Subsetter(options=options)
    subsetter.populate(text=''.join(chars))
    subsetter.subset(font)
    
    # 根据输出文件扩展名确定保存格式
    ext = os.path.splitext(output_path)[1].lower()
    if ext == '.woff':
        font.flavor = 'woff'
    elif ext == '.woff2':
        font.flavor = 'woff2'
    
    font.save(output_path)
    return True

def get_file_path(prompt, default=None, file_types=None):
    """获取用户输入的文件路径，带验证"""
    while True:
        path = input(prompt)
        if not path and default:
            path = default
        if not path:
            print("错误：路径不能为空")
            continue
        if not os.path.exists(path):
            print(f"错误：文件 '{path}' 不存在")
            continue
        if file_types:
            ext = os.path.splitext(path)[1].lower()
            if ext not in file_types:
                print(f"错误：文件必须是 {', '.join(file_types)} 格式")
                continue
        return path

def show_summary(required_chars, font_chars):
    """显示字符摘要信息"""
    print("\n" + "="*50)
    print(f"从文本文件中提取到 {len(required_chars)} 个唯一字符")
    if len(required_chars) > 50:
        print("前50个字符示例:", ''.join(sorted(required_chars)[:50]))
    else:
        print("所有字符:", ''.join(sorted(required_chars)))
    
    print(f"\n字体中匹配到 {len(font_chars)} 个所需字符")
    print("="*50 + "\n")

def find_files_in_directory(directory, filename):
    """在目录及其子目录中查找指定文件名的文件"""
    matches = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower() == filename.lower():
                matches.append(os.path.join(root, file))
    return matches

def get_font_chars(font_path):
    """获取字体中包含的所有字符"""
    font = TTFont(font_path)
    font_chars = set()
    for table in font['cmap'].tables:
        font_chars.update(chr(code) for code in table.cmap.keys())
    return font_chars

def process_auto_mode():
    """自动模式处理：查找并处理NotoSans_cn.otf和stringtable_cn.ini"""
    current_dir = os.getcwd()
    
    # 查找字体文件
    font_files = find_files_in_directory(current_dir, "NotoSans_cn.otf")
    if not font_files:
        print("错误：在当前目录及其子目录中未找到 NotoSans_cn.otf")
        return False
    
    # 查找文本文件
    text_files = find_files_in_directory(current_dir, "stringtable_cn.ini")
    if not text_files:
        print("错误：在当前目录及其子目录中未找到 stringtable_cn.ini")
        return False
    
    # 处理每对找到的文件
    for font_path in font_files:
        for text_path in text_files:
            print(f"\n处理字体文件: {font_path}")
            print(f"使用文本文件: {text_path}")
            
            # 读取文件并提取字符
            text_content = read_file_as_text(text_path)
            required_chars = extract_chars_from_text(text_content)
            
            # 检查字体中包含的字符
            font_chars = get_font_chars(font_path)
            matched_chars = required_chars & font_chars
            
            # 显示摘要信息
            show_summary(required_chars, matched_chars)
            
            # 确认操作
            confirm = input(f"即将精简字体并覆盖原文件 {font_path}，是否继续? (y/n): ").lower()
            if confirm != 'y':
                print("跳过此文件")
                continue
            
            # 创建临时文件
            temp_path = font_path + ".tmp"
            
            # 执行字体子集化
            print("\n正在处理字体，请稍候...")
            if subset_font(font_path, matched_chars, temp_path):
                # 备份原文件
                backup_path = font_path + ".bak"
                os.rename(font_path, backup_path)
                # 重命名临时文件
                os.rename(temp_path, font_path)
                
                print(f"\n操作完成！原文件已备份到: {backup_path}")
                print(f"原始字体大小: {os.path.getsize(backup_path)/1024:.2f} KB")
                print(f"精简后大小: {os.path.getsize(font_path)/1024:.2f} KB")
            else:
                print("字体处理失败")
    
    return True

def process_manual_mode():
    """手动模式处理：用户指定文件路径"""
    # 支持的字体格式
    supported_font_types = ['.otf', '.ttf', '.woff', '.woff2']
    
    # 获取输入文件路径
    font_path = get_file_path(
        "请输入字体文件路径(支持OTF/TTF/WOFF/WOFF2): ",
        file_types=supported_font_types
    )
    text_path = get_file_path("请输入包含字符的文本文件路径(如INI文件): ")
    
    # 读取文件并提取字符
    text_content = read_file_as_text(text_path)
    required_chars = extract_chars_from_text(text_content)
    
    # 检查字体中包含的字符
    font_chars = get_font_chars(font_path)
    matched_chars = required_chars & font_chars
    
    # 显示摘要信息
    show_summary(required_chars, matched_chars)
    
    # 获取输出路径
    default_output = os.path.join(
        os.path.dirname(font_path),
        f"subset_{os.path.basename(font_path)}"
    )
    output_path = input(f"请输入精简后的字体保存路径[默认: {default_output}]: ") or default_output
    
    # 确认输出文件格式是否支持
    output_ext = os.path.splitext(output_path)[1].lower()
    if output_ext not in supported_font_types:
        print(f"警告：输出文件格式{output_ext}不在支持的格式列表中，将使用原始字体格式")
        output_path = os.path.splitext(output_path)[0] + os.path.splitext(font_path)[1]
    
    # 确认操作
    confirm = input(f"即将精简字体并保存到 {output_path}，是否继续? (y/n): ").lower()
    if confirm != 'y':
        print("操作已取消")
        return
    
    # 执行字体子集化
    print("\n正在处理字体，请稍候...")
    if subset_font(font_path, matched_chars, output_path):
        print(f"\n操作完成！精简后的字体已保存到: {output_path}")
        print(f"原始字体大小: {os.path.getsize(font_path)/1024:.2f} KB")
        print(f"精简后大小: {os.path.getsize(output_path)/1024:.2f} KB")
    else:
        print("字体处理失败")

def process_difference_mode():
    """差集模式：从字体中剔除指定文本中的字符"""
    # 支持的字体格式
    supported_font_types = ['.otf', '.ttf', '.woff', '.woff2']
    
    print("\n" + "="*50)
    print("差集模式：从字体中剔除指定文本中的字符")
    print("="*50)
    
    # 获取输入文件路径
    font_path = get_file_path(
        "请输入原始字体文件路径(支持OTF/TTF/WOFF/WOFF2): ",
        file_types=supported_font_types
    )
    exclude_text_path = get_file_path("请输入要排除字符的文本文件路径: ")
    
    # 读取文件并提取字符
    exclude_text = read_file_as_text(exclude_text_path)
    exclude_chars = extract_chars_from_text(exclude_text)
    
    # 获取字体中的所有字符
    font_chars = get_font_chars(font_path)
    
    # 计算差集：保留字体中不在排除列表的字符
    keep_chars = font_chars - exclude_chars
    
    # 显示摘要信息
    print("\n" + "="*50)
    print(f"从排除文本中提取到 {len(exclude_chars)} 个唯一字符")
    if len(exclude_chars) > 50:
        print("前50个排除字符示例:", ''.join(sorted(exclude_chars)[:50]))
    else:
        print("所有排除字符:", ''.join(sorted(exclude_chars)))
    
    print(f"\n字体中将保留 {len(keep_chars)} 个字符")
    print("="*50 + "\n")
    
    # 获取输出路径
    default_output = os.path.join(
        os.path.dirname(font_path),
        f"excluded_{os.path.basename(font_path)}"
    )
    output_path = input(f"请输入排除后的字体保存路径[默认: {default_output}]: ") or default_output
    
    # 确认输出文件格式是否支持
    output_ext = os.path.splitext(output_path)[1].lower()
    if output_ext not in supported_font_types:
        print(f"警告：输出文件格式{output_ext}不在支持的格式列表中，将使用原始字体格式")
        output_path = os.path.splitext(output_path)[0] + os.path.splitext(font_path)[1]
    
    # 确认操作
    confirm = input(f"即将从字体中排除指定字符并保存到 {output_path}，是否继续? (y/n): ").lower()
    if confirm != 'y':
        print("操作已取消")
        return
    
    # 执行字体子集化（保留差集字符）
    print("\n正在处理字体，请稍候...")
    if subset_font(font_path, keep_chars, output_path):
        print(f"\n操作完成！排除后的字体已保存到: {output_path}")
        print(f"原始字体大小: {os.path.getsize(font_path)/1024:.2f} KB")
        print(f"排除后大小: {os.path.getsize(output_path)/1024:.2f} KB")
    else:
        print("字体处理失败")

def main():
    print("="*50)
    print("字体精简工具")
    print("="*50)
    print("请选择操作模式:")
    print("1. 手动模式 (手动指定字体和文本文件)")
    print("2. 自动模式 (自动查找并处理NotoSans_cn.otf和stringtable_cn.ini)")
    print("3. 差集模式 (从字体中剔除指定文本中的字符)")
    
    while True:
        choice = input("\n请输入选择(1/2/3): ")
        if choice == '1':
            process_manual_mode()
            break
        elif choice == '2':
            process_auto_mode()
            break
        elif choice == '3':
            process_difference_mode()
            break
        else:
            print("无效输入，请重新选择")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"发生错误: {str(e)}")
    finally:
        input("\n按Enter键退出...")
