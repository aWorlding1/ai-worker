#!/usr/bin/env python3
"""
字体精简工具 - 优化版
支持根据文本内容精简字体文件，减小字体文件大小
"""
import re
import os
import sys
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.subset import Subsetter, Options


class FontSubsetTool:
    """字体精简工具类"""
    
    SUPPORTED_FONT_TYPES = {'.otf', '.ttf', '.woff', '.woff2'}
    CHAR_PATTERN = re.compile(r'[^\x00-\x1F\x7F-\xA0\u1680\u180E\u2000-\u200F\u2028-\u202F\u205F-\u206F\u3000]')
    
    def __init__(self):
        self.cache = {}  # 字符集缓存
    
    @staticmethod
    def extract_chars_from_text(text):
        """从文本中提取所有唯一字符"""
        return set(FontSubsetTool.CHAR_PATTERN.findall(text))
    
    @staticmethod
    def read_file_as_text(file_path):
        """读取文件为文本"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception as e:
            raise IOError(f"无法读取文件 {file_path}: {str(e)}")
    
    def get_font_chars(self, font_path):
        """获取字体中包含的所有字符（带缓存）"""
        if font_path in self.cache:
            return self.cache[font_path]
        
        try:
            font = TTFont(font_path)
            font_chars = set()
            for table in font['cmap'].tables:
                font_chars.update(chr(code) for code in table.cmap.keys())
            font.close()
            self.cache[font_path] = font_chars
            return font_chars
        except Exception as e:
            raise ValueError(f"无法读取字体文件 {font_path}: {str(e)}")
    
    @staticmethod
    def subset_font(font_path, chars, output_path):
        """子集化字体，只保留需要的字符"""
        if not chars:
            raise ValueError("字符集为空，无法生成字体")
        
        try:
            font = TTFont(font_path)
            
            options = Options()
            options.desubroutinize = True
            options.hinting = False
            options.drop_tables = ['DSIG']  # 删除数字签名表
            
            subsetter = Subsetter(options=options)
            subsetter.populate(text=''.join(chars))
            subsetter.subset(font)
            
            # 根据输出文件扩展名确定保存格式
            ext = Path(output_path).suffix.lower()
            if ext == '.woff':
                font.flavor = 'woff'
            elif ext == '.woff2':
                font.flavor = 'woff2'
            
            font.save(output_path)
            font.close()
            return True
        except Exception as e:
            raise RuntimeError(f"字体处理失败: {str(e)}")
    
    @staticmethod
    def get_file_size_mb(file_path):
        """获取文件大小（KB）"""
        return os.path.getsize(file_path) / 1024
    
    @staticmethod
    def find_files_in_directory(directory, filename):
        """在目录及其子目录中查找指定文件名的文件"""
        matches = []
        directory = Path(directory)
        for file_path in directory.rglob(filename):
            if file_path.is_file():
                matches.append(str(file_path))
        return matches
    
    @staticmethod
    def print_separator(char='=', length=60):
        """打印分隔线"""
        print(char * length)
    
    @staticmethod
    def print_header(title):
        """打印标题"""
        FontSubsetTool.print_separator()
        print(f" {title}")
        FontSubsetTool.print_separator()
    
    def show_summary(self, required_chars, font_chars, show_samples=True):
        """显示字符摘要信息"""
        self.print_separator()
        print(f"文本中提取的唯一字符数: {len(required_chars)}")
        
        if show_samples:
            if len(required_chars) > 100:
                sample = ''.join(sorted(required_chars)[:100])
                print(f"前100个字符示例: {sample}")
            else:
                print(f"所有字符: {''.join(sorted(required_chars))}")
        
        print(f"\n字体中匹配到的字符数: {len(font_chars)}")
        
        missing = required_chars - font_chars
        if missing:
            print(f"字体中缺失的字符数: {len(missing)}")
            if len(missing) <= 20:
                print(f"缺失字符: {''.join(sorted(missing))}")
        
        self.print_separator()
    
    def validate_file_path(self, path, file_types=None, must_exist=True):
        """验证文件路径"""
        path = Path(path)
        
        if must_exist and not path.exists():
            raise FileNotFoundError(f"文件不存在: {path}")
        
        if file_types:
            if path.suffix.lower() not in file_types:
                raise ValueError(f"文件格式必须是: {', '.join(file_types)}")
        
        return str(path)
    
    def get_user_input(self, prompt, default=None, validator=None):
        """获取用户输入并验证"""
        while True:
            try:
                user_input = input(prompt).strip()
                
                if not user_input and default is not None:
                    return default
                
                if not user_input:
                    print("输入不能为空，请重新输入")
                    continue
                
                if validator:
                    return validator(user_input)
                
                return user_input
            except (ValueError, FileNotFoundError) as e:
                print(f"错误: {e}")
            except KeyboardInterrupt:
                print("\n操作已取消")
                sys.exit(0)
    
    def confirm_action(self, message):
        """确认用户操作"""
        while True:
            response = input(f"{message} (y/n): ").lower().strip()
            if response in ('y', 'yes', '是'):
                return True
            if response in ('n', 'no', '否'):
                return False
            print("请输入 y 或 n")


class AutoMode:
    """自动模式处理器"""
    
    def __init__(self, tool):
        self.tool = tool
    
    def run(self):
        """执行自动模式"""
        self.tool.print_header("自动模式")
        current_dir = os.getcwd()
        
        # 查找字体文件
        print("正在查找 NotoSans_cn.otf 文件...")
        font_files = self.tool.find_files_in_directory(current_dir, "NotoSans_cn.otf")
        if not font_files:
            print("错误: 未找到 NotoSans_cn.otf 文件")
            return False
        
        print(f"找到 {len(font_files)} 个字体文件")
        
        # 查找文本文件
        print("正在查找 stringtable_cn.ini 文件...")
        text_files = self.tool.find_files_in_directory(current_dir, "stringtable_cn.ini")
        if not text_files:
            print("错误: 未找到 stringtable_cn.ini 文件")
            return False
        
        print(f"找到 {len(text_files)} 个文本文件\n")
        
        # 处理每对文件
        total = len(font_files) * len(text_files)
        current = 0
        
        for font_path in font_files:
            for text_path in text_files:
                current += 1
                print(f"\n[{current}/{total}] 处理配对:")
                print(f"  字体: {font_path}")
                print(f"  文本: {text_path}")
                
                try:
                    self._process_pair(font_path, text_path)
                except Exception as e:
                    print(f"处理失败: {e}")
                    continue
        
        print("\n所有文件处理完成！")
        return True
    
    def _process_pair(self, font_path, text_path):
        """处理单对文件"""
        # 读取并提取字符
        text_content = self.tool.read_file_as_text(text_path)
        required_chars = self.tool.extract_chars_from_text(text_content)
        
        # 获取字体字符
        font_chars = self.tool.get_font_chars(font_path)
        matched_chars = required_chars & font_chars
        
        # 显示摘要
        self.tool.show_summary(required_chars, matched_chars, show_samples=False)
        
        # 确认操作
        if not self.tool.confirm_action(f"\n覆盖原文件 {Path(font_path).name}?"):
            print("已跳过")
            return
        
        # 创建临时文件
        temp_path = font_path + ".tmp"
        
        # 执行字体子集化
        print("\n正在处理字体...")
        original_size = self.tool.get_file_size_mb(font_path)
        
        self.tool.subset_font(font_path, matched_chars, temp_path)
        
        # 备份并替换
        backup_path = font_path + ".bak"
        if Path(backup_path).exists():
            os.remove(backup_path)
        
        os.rename(font_path, backup_path)
        os.rename(temp_path, font_path)
        
        new_size = self.tool.get_file_size_mb(font_path)
        reduction = ((original_size - new_size) / original_size) * 100
        
        print(f"✓ 完成!")
        print(f"  原始大小: {original_size:.2f} KB")
        print(f"  精简大小: {new_size:.2f} KB")
        print(f"  减少: {reduction:.1f}%")
        print(f"  备份: {backup_path}")


class ManualMode:
    """手动模式处理器"""
    
    def __init__(self, tool):
        self.tool = tool
    
    def run(self):
        """执行手动模式"""
        self.tool.print_header("手动模式")
        
        # 获取字体文件路径
        font_path = self.tool.get_user_input(
            "字体文件路径 (支持 OTF/TTF/WOFF/WOFF2): ",
            validator=lambda p: self.tool.validate_file_path(
                p, file_types=self.tool.SUPPORTED_FONT_TYPES
            )
        )
        
        # 获取文本文件路径
        text_path = self.tool.get_user_input(
            "文本文件路径: ",
            validator=lambda p: self.tool.validate_file_path(p)
        )
        
        # 读取并提取字符
        print("\n正在分析文件...")
        text_content = self.tool.read_file_as_text(text_path)
        required_chars = self.tool.extract_chars_from_text(text_content)
        
        # 获取字体字符
        font_chars = self.tool.get_font_chars(font_path)
        matched_chars = required_chars & font_chars
        
        # 显示摘要
        self.tool.show_summary(required_chars, matched_chars)
        
        # 获取输出路径
        default_output = str(Path(font_path).parent / f"subset_{Path(font_path).name}")
        output_path = self.tool.get_user_input(
            f"\n输出路径 [默认: {default_output}]: ",
            default=default_output
        )
        
        # 验证输出格式
        if Path(output_path).suffix.lower() not in self.tool.SUPPORTED_FONT_TYPES:
            print(f"警告: 输出格式不支持，将使用 {Path(font_path).suffix}")
            output_path = str(Path(output_path).with_suffix(Path(font_path).suffix))
        
        # 确认操作
        if not self.tool.confirm_action(f"\n保存到 {output_path}?"):
            print("操作已取消")
            return
        
        # 执行字体子集化
        print("\n正在处理字体...")
        original_size = self.tool.get_file_size_mb(font_path)
        
        self.tool.subset_font(font_path, matched_chars, output_path)
     
        new_size = self.tool.get_file_size_mb(output_path)
        reduction = ((original_size - new_size) / original_size) * 100
        
        print(f"\n✓ 完成!")
        print(f"  原始大小: {original_size:.2f} KB")
        print(f"  精简大小: {new_size:.2f} KB")
        print(f"  减少: {reduction:.1f}%")
        print(f"  保存位置: {output_path}")


class DifferenceMode:
    """差集模式处理器"""
    
    def __init__(self, tool):
        self.tool = tool
    
    def run(self):
        """执行差集模式"""
        self.tool.print_header("差集模式 - 剔除指定字符")
        
        # 获取字体文件路径
        font_path = self.tool.get_user_input(
            "字体文件路径 (支持 OTF/TTF/WOFF/WOFF2): ",
            validator=lambda p: self.tool.validate_file_path(
                p, file_types=self.tool.SUPPORTED_FONT_TYPES
            )
        )
        
        # 获取排除字符文本文件
        exclude_text_path = self.tool.get_user_input(
            "要排除字符的文本文件路径: ",
            validator=lambda p: self.tool.validate_file_path(p)
        )
        
        # 读取并提取字符
        print("\n正在分析文件...")
        exclude_text = self.tool.read_file_as_text(exclude_text_path)
        exclude_chars = self.tool.extract_chars_from_text(exclude_text)
        
        # 获取字体字符
        font_chars = self.tool.get_font_chars(font_path)
        keep_chars = font_chars - exclude_chars
        
        # 显示摘要
        self.tool.print_separator()
        print(f"排除字符数: {len(exclude_chars)}")
        if len(exclude_chars) <= 100:
            print(f"排除字符: {''.join(sorted(exclude_chars))}")
        else:
            print(f"前100个排除字符: {''.join(sorted(exclude_chars)[:100])}")
        
        print(f"\n字体中保留字符数: {len(keep_chars)}")
        print(f"字体中移除字符数: {len(font_chars & exclude_chars)}")
        self.tool.print_separator()
        
        # 获取输出路径
        default_output = str(Path(font_path).parent / f"excluded_{Path(font_path).name}")
        output_path = self.tool.get_user_input(
            f"\n输出路径 [默认: {default_output}]: ",
            default=default_output
        )
        
        # 验证输出格式
        if Path(output_path).suffix.lower() not in self.tool.SUPPORTED_FONT_TYPES:
            print(f"警告: 输出格式不支持，将使用 {Path(font_path).suffix}")
            output_path = str(Path(output_path).with_suffix(Path(font_path).suffix))
        
        # 确认操作
        if not self.tool.confirm_action(f"\n保存到 {output_path}?"):
            print("操作已取消")
            return
        
        # 执行字体子集化
        print("\n正在处理字体...")
        original_size = self.tool.get_file_size_mb(font_path)
        
        self.tool.subset_font(font_path, keep_chars, output_path)
        
        new_size = self.tool.get_file_size_mb(output_path)
        reduction = ((original_size - new_size) / original_size) * 100
        
        print(f"\n✓ 完成!")
        print(f"  原始大小: {original_size:.2f} KB")
        print(f"  处理后大小: {new_size:.2f} KB")
        print(f"  减少: {reduction:.1f}%")
        print(f"  保存位置: {output_path}")


def main():
    """主函数"""
    tool = FontSubsetTool()
    
    tool.print_header("字体精简工具")
    print("请选择操作模式:")
    print("  1. 手动模式 (手动指定字体和文本文件)")
    print("  2. 自动模式 (自动查找并处理 NotoSans_cn.otf 和 stringtable_cn.ini)")
    print("  3. 差集模式 (从字体中剔除指定文本中的字符)")
    print("  0. 退出")
    
    modes = {
        '1': ManualMode(tool),
        '2': AutoMode(tool),
        '3': DifferenceMode(tool)
    }
    
    while True:
        choice = input("\n请选择 (0-3): ").strip()
        
        if choice == '0':
            print("再见!")
            break
        
        if choice in modes:
            try:
                modes[choice].run()
            except KeyboardInterrupt:
                print("\n\n操作已中断")
            except Exception as e:
                print(f"\n发生错误: {e}")
            
            if not tool.confirm_action("\n是否继续使用工具?"):
                print("再见!")
                break
        else:
            print("无效选择，请重新输入")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n程序已退出")
        sys.exit(0)
    except Exception as e:
        print(f"\n严重错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        input("\n按 Enter 键退出...")
