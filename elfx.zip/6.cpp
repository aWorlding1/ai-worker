#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <unistd.h>
#include <cctype>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <readline/readline.h>
#include <readline/history.h>
#include <unordered_map>
#include <mutex>
#include <future>

namespace fs = std::filesystem;

// ====================== 终端颜色格式化工具 ======================
class TerminalFormatter {
public:
    static const std::string RESET;
    static const std::string BOLD;
    static const std::string GREEN;
    static const std::string BLUE;
    static const std::string RED;
    static const std::string YELLOW;
    static const std::string CYAN;

    static std::string formatSuccess(const std::string& text) {
        return BOLD + GREEN + text + RESET;
    }

    static std::string formatError(const std::string& text) {
        return BOLD + RED + text + RESET;
    }

    static void printSeparator(int length = 50) {
        std::cout << BOLD << std::string(length, '=') << RESET << "\n";
    }
};

const std::string TerminalFormatter::RESET = "\033[0m";
const std::string TerminalFormatter::BOLD = "\033[1m";
const std::string TerminalFormatter::GREEN = "\033[32m";
const std::string TerminalFormatter::BLUE = "\033[34m";
const std::string TerminalFormatter::RED = "\033[31m";
const std::string TerminalFormatter::YELLOW = "\033[33m";
const std::string TerminalFormatter::CYAN = "\033[36m";

// ====================== 字符串工具 ======================
class StringUtils {
public:
    static std::string trim(const std::string& str) {
        const char* whitespace = " \t\n\r\f\v";
        size_t start = str.find_first_not_of(whitespace);
        size_t end = str.find_last_not_of(whitespace);
        return (start == std::string::npos) ? "" : str.substr(start, end - start + 1);
    }

    static bool is_numeric(const std::string& str) {
        return !str.empty() && std::all_of(str.begin(), str.end(), ::isdigit);
    }
};

// ====================== 目录扫描器 ======================
class DirectoryScanner {
public:
    static std::vector<fs::path> scanDirectories(const fs::path& path) {
        std::vector<fs::path> directories;
        try {
            for (const auto& entry : fs::directory_iterator(path)) {
                if (entry.is_directory()) {
                    directories.emplace_back(entry.path());
                }
            }
        } catch (const fs::filesystem_error& e) {
            std::cerr << TerminalFormatter::formatError("扫描错误: ") << e.what() << "\n";
        }
        return directories;
    }
};

// ====================== 用户输入处理器 ======================
class InputHandler {
public:
    static size_t getDirectoryChoice(const std::vector<fs::path>& directories) {
        while (true) {
            std::cout << "\n请选择目录 (1-" << directories.size() << "): ";
            std::string input;
            std::getline(std::cin, input);
            input = StringUtils::trim(input);

            if (StringUtils::is_numeric(input)) {
                size_t choice = std::stoul(input);
                if (choice > 0 && choice <= directories.size()) {
                    return choice;
                }
            }
            std::cout << TerminalFormatter::formatError("请输入有效的数字\n");
        }
    }

    static std::string getCommand() {
        char* input = readline("\n请输入命令: ");
        if (input) {
            std::string command = StringUtils::trim(input);
            free(input);
            if (!command.empty()) {
                add_history(command.c_str());
                return command;
            }
        }
        return "";
    }
};

// ====================== 命令执行器 ======================
class CommandExecutor {
public:
    static int executeCommand(const fs::path& directory, const std::string& command) {
        if (chdir(directory.c_str()) != 0) {
            std::perror(TerminalFormatter::formatError("更改目录失败").c_str());
            return -1;
        }
        std::cout << TerminalFormatter::formatSuccess("执行命令: ") << command << "\n";
        return std::system(command.c_str());
    }
};

// ====================== 主循环 ======================
void mainLoop(fs::path current_path) {
    while (true) {
        auto directories = DirectoryScanner::scanDirectories(current_path);
        if (directories.empty()) {
            std::cout << TerminalFormatter::formatError("没有找到子目录\n");
            return;
        }

        for (size_t i = 0; i < directories.size(); ++i) {
            std::cout << std::setw(3) << (i + 1) << ". " << directories[i].filename().string() << "\n";
        }

        size_t choice = InputHandler::getDirectoryChoice(directories);
        current_path = directories[choice - 1];

        std::string command = InputHandler::getCommand();
        if (!command.empty()) {
            int result = CommandExecutor::executeCommand(current_path, command);
            if (result == 0) {
                std::cout << TerminalFormatter::formatSuccess("命令执行成功\n");
            } else {
                std::cout << TerminalFormatter::formatError("命令执行失败\n");
            }
        }
    }
}

// ====================== 主函数 ======================
int main(int argc, char* argv[]) {
    fs::path target_path = (argc > 1) ? argv[1] : fs::current_path();
    
    if (!fs::exists(target_path) || !fs::is_directory(target_path)) {
        std::cerr << TerminalFormatter::formatError("路径不存在或不是目录: ") << target_path << "\n";
        return 1;
    }

    mainLoop(target_path);
    return 0;
}
