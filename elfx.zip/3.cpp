#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <unistd.h>
#include <cctype>
#include <iomanip>
#include <sstream>
#include <chrono>

namespace fs = std::filesystem;

class TerminalFormatter {
public:
    static const std::string RESET;
    static const std::string BOLD;
    static const std::string GREEN;
    static const std::string BLUE;
    static const std::string RED;
    static const std::string YELLOW;
    static const std::string CYAN;
    static const std::string MAGENTA;
    
    static std::string formatHeader(const std::string& text) {
        return BOLD + BLUE + text + RESET;
    }
    
    static std::string formatSuccess(const std::string& text) {
        return BOLD + GREEN + text + RESET;
    }
    
    static std::string formatError(const std::string& text) {
        return BOLD + RED + text + RESET;
    }
    
    static std::string formatWarning(const std::string& text) {
        return BOLD + YELLOW + text + RESET;
    }
    
    static std::string formatDirectory(const std::string& text) {
        return BOLD + CYAN + text + RESET;
    }
    
    static void printSeparator(int length = 50) {
        std::cout << BOLD << std::string(length, '=') << RESET << "\n";
    }
};

const std::string TerminalFormatter::RESET = "\033[0m";
const std::string TerminalFormatter::BOLD = "\033[1m";
const std::string TerminalFormatter::GREEN = "\033[32m";
const std::string TerminalFormatter::BLUE = "\033[34m";
const std::string TerminalFormatter::RED = "\033[31m";
const std::string TerminalFormatter::YELLOW = "\033[33m";
const std::string TerminalFormatter::CYAN = "\033[36m";
const std::string TerminalFormatter::MAGENTA = "\033[35m";

class StringUtils {
public:
    static std::string trim(const std::string& str) {
        const char* whitespace = " \t\n\r\f\v";
        size_t start = str.find_first_not_of(whitespace);
        if (start == std::string::npos) return "";
        size_t end = str.find_last_not_of(whitespace);
        return str.substr(start, end - start + 1);
    }
    
    static bool is_numeric(const std::string& str) {
        if (str.empty()) return false;
        for (char c : str) {
            if (!std::isdigit(static_cast<unsigned char>(c))) {
                return false;
            }
        }
        return true;
    }
    
    static std::string getCurrentTime() {
        auto now = std::chrono::system_clock::now();
        auto in_time_t = std::chrono::system_clock::to_time_t(now);
        std::stringstream ss;
        ss << std::put_time(std::localtime(&in_time_t), "%Y-%m-%d %H:%M:%S");
        return ss.str();
    }
};

class DirectoryScanner {
public:
    static std::vector<fs::path> scanDirectories(const fs::path& path) {
        std::vector<fs::path> directories;
        
        try {
            auto start = std::chrono::high_resolution_clock::now();
            
            for (const auto& entry : fs::directory_iterator(path, 
                 fs::directory_options::skip_permission_denied)) {
                if (entry.is_directory()) {
                    directories.emplace_back(entry.path());
                }
            }
            
            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            
            std::cout << TerminalFormatter::formatSuccess("✓ 扫描完成: ") 
                      << directories.size() << " 个目录, 耗时 " 
                      << duration.count() << "ms\n";
                      
        } catch (const fs::filesystem_error& e) {
            std::cerr << TerminalFormatter::formatError("扫描错误: ") << e.what() << "\n";
        }
        
        return directories;
    }
};

class InputHandler {
public:
    static size_t getDirectoryChoice(const std::vector<fs::path>& directories) {
        while (true) {
            std::cout << "\n" << TerminalFormatter::formatHeader("请选择目录 (1-") 
                      << directories.size() << TerminalFormatter::formatHeader("): ");
            
            std::string input;
            if (!std::getline(std::cin, input)) {
                std::cout << TerminalFormatter::formatError("输入错误\n");
                continue;
            }
            
            input = StringUtils::trim(input);
            
            if (input == "q" || input == "Q") {
                std::cout << TerminalFormatter::formatWarning("退出程序\n");
                std::exit(0);
            }
            
            if (!StringUtils::is_numeric(input)) {
                std::cout << TerminalFormatter::formatError("请输入有效的数字\n");
                continue;
            }
            
            try {
                size_t choice = std::stoul(input);
                if (choice >= 1 && choice <= directories.size()) {
                    return choice;
                }
                std::cout << TerminalFormatter::formatError("请输入 1-") 
                          << directories.size() << " 之间的数字\n";
            } catch (const std::exception&) {
                std::cout << TerminalFormatter::formatError("无效的选择\n");
            }
        }
    }
    
    static std::string getCommand() {
        while (true) {
            std::cout << TerminalFormatter::formatHeader("\n请输入要执行的命令: ");
            
            std::string command;
            if (!std::getline(std::cin, command)) {
                std::cout << TerminalFormatter::formatError("输入错误\n");
                continue;
            }
            
            command = StringUtils::trim(command);
            if (!command.empty()) {
                return command;
            }
            std::cout << TerminalFormatter::formatError("命令不能为空\n");
        }
    }
    
    static bool getConfirmation(const std::string& message) {
        std::cout << TerminalFormatter::formatWarning(message);
        
        std::string input;
        if (!std::getline(std::cin, input)) {
            return true;  // 默认返回true
        }
        
        input = StringUtils::trim(input);
        if (input.empty()) return true;  // 空输入默认为y
        
        return (input == "y" || input == "Y" || input == "yes");
    }
};

class CommandExecutor {
public:
    static int executeCommand(const fs::path& directory, const std::string& command) {
        // 保存当前目录
        char old_cwd[1024];
        if (!getcwd(old_cwd, sizeof(old_cwd))) {
            std::cerr << TerminalFormatter::formatError("无法获取当前目录\n");
            return -1;
        }
        
        // 切换到目标目录
        if (chdir(directory.c_str()) != 0) {
            std::perror(TerminalFormatter::formatError("更改目录失败").c_str());
            return -1;
        }
        
        // 显示执行信息
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd))) {
            std::cout << TerminalFormatter::formatDirectory("当前目录: ") << cwd << "\n";
        }
        
        std::cout << TerminalFormatter::formatDirectory("执行命令: ") << command << "\n";
        TerminalFormatter::printSeparator();
        
        auto start_time = std::chrono::high_resolution_clock::now();
        
        // 执行命令
        int result = std::system(command.c_str());
        
        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
        
        TerminalFormatter::printSeparator();
        std::cout << TerminalFormatter::formatSuccess("执行完成, 耗时: ") 
                  << duration.count() << "ms\n";
        
        // 恢复原目录
        chdir(old_cwd);
        
        return result;
    }
};

void displayWelcome() {
    std::cout << TerminalFormatter::formatHeader("🚀 目录命令执行工具") << "\n";
    std::cout << TerminalFormatter::formatHeader("════════════════════════════════════════") << "\n";
    std::cout << "启动时间: " << StringUtils::getCurrentTime() << "\n\n";
}

void displayDirectoryList(const std::vector<fs::path>& directories, const fs::path& current_path) {
    std::cout << TerminalFormatter::formatHeader("📁 当前路径: ") << current_path << "\n";
    std::cout << TerminalFormatter::formatHeader("可用的子目录:") << "\n";
    TerminalFormatter::printSeparator();
    
    for (size_t i = 0; i < directories.size(); ++i) {
        std::cout << std::setw(3) << (i + 1) << ". " 
                  << TerminalFormatter::formatDirectory(directories[i].filename().string()) 
                  << "\n";
    }
    
    TerminalFormatter::printSeparator();
}

int main(int argc, char* argv[]) {
    displayWelcome();
    
    // 获取目标路径
    fs::path target_path = (argc > 1) ? argv[1] : fs::current_path();
    
    try {
        // 快速路径验证
        if (!fs::exists(target_path)) {
            std::cerr << TerminalFormatter::formatError("错误: 路径不存在 - ") << target_path << "\n";
            return 1;
        }
        
        if (!fs::is_directory(target_path)) {
            std::cerr << TerminalFormatter::formatError("错误: 不是目录 - ") << target_path << "\n";
            return 1;
        }
        
        // 扫描目录
        std::cout << TerminalFormatter::formatSuccess("正在扫描目录...\n");
        auto directories = DirectoryScanner::scanDirectories(target_path);
        
        if (directories.empty()) {
            std::cout << TerminalFormatter::formatWarning("没有找到子目录\n");
            return 0;
        }
        
        // 按名称排序
        std::sort(directories.begin(), directories.end(), [](const fs::path& a, const fs::path& b) {
            return a.filename().string() < b.filename().string();
        });
        
        // 显示目录列表
        displayDirectoryList(directories, target_path);
        
        // 获取用户选择
        size_t choice = InputHandler::getDirectoryChoice(directories);
        fs::path selected_dir = directories[choice - 1];
        
        // 获取命令
        std::string command = InputHandler::getCommand();
        
        // 确认执行
        std::cout << "\n" << TerminalFormatter::formatWarning("⚠️  执行确认:") << "\n";
        std::cout << "目录: " << TerminalFormatter::formatDirectory(selected_dir.string()) << "\n";
        std::cout << "命令: " << TerminalFormatter::formatDirectory(command) << "\n";
        
        if (!InputHandler::getConfirmation("确定要执行吗? (Y/n): ")) {
            std::cout << TerminalFormatter::formatWarning("操作已取消\n");
            return 0;
        }
        
        // 执行命令
        std::cout << TerminalFormatter::formatSuccess("\n开始执行命令...\n");
        int result = CommandExecutor::executeCommand(selected_dir, command);
        
        if (result == 0) {
            std::cout << TerminalFormatter::formatSuccess("✅ 命令执行成功\n");
        } else {
            std::cout << TerminalFormatter::formatError("❌ 命令执行失败, 返回码: ") << result << "\n";
            return 1;
        }
        
    } catch (const fs::filesystem_error& e) {
        std::cerr << TerminalFormatter::formatError("文件系统错误: ") << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << TerminalFormatter::formatError("错误: ") << e.what() << "\n";
        return 1;
    }
    
    std::cout << TerminalFormatter::formatSuccess("\n程序执行完成\n");
    return 0;
}
