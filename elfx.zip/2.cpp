#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <unistd.h>
#include <cctype>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <sys/wait.h>

namespace fs = std::filesystem;

class TerminalFormatter {
public:
    static const std::string RESET;
    static const std::string BOLD;
    static const std::string GREEN;
    static const std::string BLUE;
    static const std::string RED;
    static const std::string YELLOW;
    static const std::string CYAN;
    
    static std::string formatHeader(const std::string& text) {
        return BOLD + BLUE + text + RESET;
    }
    
    static std::string formatSuccess(const std::string& text) {
        return BOLD + GREEN + text + RESET;
    }
    
    static std::string formatError(const std::string& text) {
        return BOLD + RED + text + RESET;
    }
    
    static std::string formatWarning(const std::string& text) {
        return BOLD + YELLOW + text + RESET;
    }
    
    static std::string formatDirectory(const std::string& text) {
        return BOLD + CYAN + text + RESET;
    }
    
    static void printSeparator(int length = 50) {
        std::cout << BOLD << std::string(length, '=') << RESET << "\n";
    }
};

const std::string TerminalFormatter::RESET = "\033[0m";
const std::string TerminalFormatter::BOLD = "\033[1m";
const std::string TerminalFormatter::GREEN = "\033[32m";
const std::string TerminalFormatter::BLUE = "\033[34m";
const std::string TerminalFormatter::RED = "\033[31m";
const std::string TerminalFormatter::YELLOW = "\033[33m";
const std::string TerminalFormatter::CYAN = "\033[36m";

class StringUtils {
public:
    static std::string trim(const std::string& str) {
        const char* whitespace = " \t\n\r\f\v";
        size_t start = str.find_first_not_of(whitespace);
        if (start == std::string::npos) return "";
        size_t end = str.find_last_not_of(whitespace);
        return str.substr(start, end - start + 1);
    }
    
    static bool is_numeric(const std::string& str) {
        if (str.empty()) return false;
        for (char c : str) {
            if (!std::isdigit(static_cast<unsigned char>(c))) {
                return false;
            }
        }
        return true;
    }
    
    static std::string getCurrentTime() {
        auto now = std::chrono::system_clock::now();
        auto in_time_t = std::chrono::system_clock::to_time_t(now);
        std::stringstream ss;
        ss << std::put_time(std::localtime(&in_time_t), "%Y-%m-%d %H:%M:%S");
        return ss.str();
    }
};

class DirectoryScanner {
public:
    static std::vector<fs::path> scanDirectoriesParallel(const fs::path& path) {
        std::vector<fs::path> directories;
        std::mutex dir_mutex;
        std::atomic<size_t> processed{0};
        
        try {
            auto start = std::chrono::high_resolution_clock::now();
            
            // 先收集所有目录条目
            std::vector<fs::path> all_entries;
            for (const auto& entry : fs::directory_iterator(path, 
                 fs::directory_options::skip_permission_denied)) {
                all_entries.push_back(entry.path());
            }
            
            const size_t total_entries = all_entries.size();
            const unsigned num_threads = std::thread::hardware_concurrency();
            std::vector<std::thread> workers;
            
            auto worker_func = [&](size_t start_idx, size_t end_idx) {
                for (size_t i = start_idx; i < end_idx; ++i) {
                    if (fs::is_directory(all_entries[i])) {
                        std::lock_guard<std::mutex> lock(dir_mutex);
                        directories.push_back(all_entries[i]);
                    }
                    ++processed;
                }
            };
            
            // 启动并行工作线程
            size_t chunk_size = total_entries / num_threads;
            for (unsigned t = 0; t < num_threads; ++t) {
                size_t start = t * chunk_size;
                size_t end = (t == num_threads - 1) ? total_entries : start + chunk_size;
                workers.emplace_back(worker_func, start, end);
            }
            
            // 显示进度
            while (processed < total_entries) {
                std::cout << "\r扫描进度: " << processed << "/" << total_entries 
                          << " (" << (processed * 100 / total_entries) << "%)" << std::flush;
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            
            for (auto& worker : workers) {
                worker.join();
            }
            
            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            
            std::cout << "\r" << TerminalFormatter::formatSuccess("✓ 扫描完成: ") 
                      << directories.size() << " 个目录, 耗时 " 
                      << duration.count() << "ms (并行)" << std::endl;
                      
        } catch (const fs::filesystem_error& e) {
            std::cerr << TerminalFormatter::formatError("扫描错误: ") << e.what() << "\n";
        }
        
        return directories;
    }
};

class CommandExecutor {
public:
    static int executeCommandDirect(const fs::path& directory, const std::string& command) {
        // 保存当前目录
        char old_cwd[1024];
        if (!getcwd(old_cwd, sizeof(old_cwd))) {
            std::cerr << TerminalFormatter::formatError("无法获取当前目录\n");
            return -1;
        }
        
        // 切换到目标目录
        if (chdir(directory.c_str()) != 0) {
            std::perror(TerminalFormatter::formatError("更改目录失败").c_str());
            return -1;
        }
        
        // 显示执行信息
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd))) {
            std::cout << TerminalFormatter::formatDirectory("当前目录: ") << cwd << "\n";
        }
        
        std::cout << TerminalFormatter::formatDirectory("执行命令: ") << command << "\n";
        TerminalFormatter::printSeparator();
        
        auto start_time = std::chrono::high_resolution_clock::now();
        
        // 使用fork+execvp直接执行命令（避免shell开销）
        int result = -1;
        pid_t pid = fork();
        
        if (pid == 0) {
            // 子进程：解析命令并执行
            std::vector<std::string> tokens;
            std::istringstream iss(command);
            std::string token;
            
            while (iss >> token) {
                tokens.push_back(token);
            }
            
            std::vector<char*> args;
            for (auto& token : tokens) {
                args.push_back(&token[0]);
            }
            args.push_back(nullptr);
            
            execvp(args[0], args.data());
            _exit(127); // exec失败
        } else if (pid > 0) {
            // 父进程：等待子进程完成
            int status;
            waitpid(pid, &status, 0);
            
            if (WIFEXITED(status)) {
                result = WEXITSTATUS(status);
            }
        }
        
        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
        
        TerminalFormatter::printSeparator();
        std::cout << TerminalFormatter::formatSuccess("执行完成, 耗时: ") 
                  << duration.count() << "ms\n";
        
        // 恢复原目录
        chdir(old_cwd);
        
        return result;
    }
};

class InputHandler {
public:
    static size_t getDirectoryChoice(const std::vector<fs::path>& directories) {
        while (true) {
            std::cout << "\n" << TerminalFormatter::formatHeader("请选择目录 (1-") 
                      << directories.size() << TerminalFormatter::formatHeader("): ");
            
            std::string input;
            if (!std::getline(std::cin, input)) {
                std::cout << TerminalFormatter::formatError("输入错误\n");
                continue;
            }
            
            input = StringUtils::trim(input);
            
            if (input == "q" || input == "Q") {
                std::cout << TerminalFormatter::formatWarning("退出程序\n");
                std::exit(0);
            }
            
            if (!StringUtils::is_numeric(input)) {
                std::cout << TerminalFormatter::formatError("请输入有效的数字\n");
                continue;
            }
            
            try {
                size_t choice = std::stoul(input);
                if (choice >= 1 && choice <= directories.size()) {
                    return choice;
                }
                std::cout << TerminalFormatter::formatError("请输入 1-") 
                          << directories.size() << " 之间的数字\n";
            } catch (const std::exception&) {
                std::cout << TerminalFormatter::formatError("无效的选择\n");
            }
        }
    }
    
    static std::string getCommand() {
        while (true) {
            std::cout << TerminalFormatter::formatHeader("\n请输入要执行的命令: ");
            
            std::string command;
            if (!std::getline(std::cin, command)) {
                std::cout << TerminalFormatter::formatError("输入错误\n");
                continue;
            }
            
            command = StringUtils::trim(command);
            if (!command.empty()) {
                return command;
            }
            std::cout << TerminalFormatter::formatError("命令不能为空\n");
        }
    }
    
    static bool getConfirmation(const std::string& message) {
        std::cout << TerminalFormatter::formatWarning(message);
        
        std::string input;
        if (!std::getline(std::cin, input)) {
            return false;
        }
        
        input = StringUtils::trim(input);
        return (input == "y" || input == "Y" || input == "yes");
    }
};

void displayWelcome() {
    std::cout << TerminalFormatter::formatHeader("🚀 目录命令执行工具 (并行优化版)") << "\n";
    std::cout << TerminalFormatter::formatHeader("════════════════════════════════════════") << "\n";
    std::cout << "启动时间: " << StringUtils::getCurrentTime() << "\n";
    std::cout << "CPU核心数: " << std::thread::hardware_concurrency() << "\n\n";
}

void displayDirectoryList(const std::vector<fs::path>& directories, const fs::path& current_path) {
    std::cout << TerminalFormatter::formatHeader("📁 当前路径: ") << current_path << "\n";
    std::cout << TerminalFormatter::formatHeader("可用的子目录:") << "\n";
    TerminalFormatter::printSeparator();
    
    for (size_t i = 0; i < directories.size(); ++i) {
        std::cout << std::setw(3) << (i + 1) << ". " 
                  << TerminalFormatter::formatDirectory(directories[i].filename().string()) 
                  << "\n";
    }
    
    TerminalFormatter::printSeparator();
}

int main(int argc, char* argv[]) {
    displayWelcome();
    
    // 获取目标路径
    fs::path target_path = (argc > 1) ? argv[1] : fs::current_path();
    
    try {
        // 快速路径验证
        if (!fs::exists(target_path)) {
            std::cerr << TerminalFormatter::formatError("错误: 路径不存在 - ") << target_path << "\n";
            return 1;
        }
        
        if (!fs::is_directory(target_path)) {
            std::cerr << TerminalFormatter::formatError("错误: 不是目录 - ") << target_path << "\n";
            return 1;
        }
        
        // 并行扫描目录
        std::cout << TerminalFormatter::formatSuccess("正在并行扫描目录...\n");
        auto directories = DirectoryScanner::scanDirectoriesParallel(target_path);
        
        if (directories.empty()) {
            std::cout << TerminalFormatter::formatWarning("没有找到子目录\n");
            return 0;
        }
        
        // 按名称排序
        std::sort(directories.begin(), directories.end(), [](const fs::path& a, const fs::path& b) {
            return a.filename().string() < b.filename().string();
        });
        
        // 显示目录列表
        displayDirectoryList(directories, target_path);
        
        // 获取用户选择
        size_t choice = InputHandler::getDirectoryChoice(directories);
        fs::path selected_dir = directories[choice - 1];
        
        // 获取命令
        std::string command = InputHandler::getCommand();
        
        // 确认执行
        std::cout << "\n" << TerminalFormatter::formatWarning("⚠️  执行确认:") << "\n";
        std::cout << "目录: " << TerminalFormatter::formatDirectory(selected_dir.string()) << "\n";
        std::cout << "命令: " << TerminalFormatter::formatDirectory(command) << "\n";
        
        if (!InputHandler::getConfirmation("确定要执行吗? (y/N): ")) {
            std::cout << TerminalFormatter::formatWarning("操作已取消\n");
            return 0;
        }
        
        // 执行命令（使用直接执行方式）
        std::cout << TerminalFormatter::formatSuccess("\n开始执行命令...\n");
        int result = CommandExecutor::executeCommandDirect(selected_dir, command);
        
        if (result == 0) {
            std::cout << TerminalFormatter::formatSuccess("✅ 命令执行成功\n");
        } else {
            std::cout << TerminalFormatter::formatError("❌ 命令执行失败, 返回码: ") << result << "\n";
            return 1;
        }
        
    } catch (const fs::filesystem_error& e) {
        std::cerr << TerminalFormatter::formatError("文件系统错误: ") << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << TerminalFormatter::formatError("错误: ") << e.what() << "\n";
        return 1;
    }
    
    std::cout << TerminalFormatter::formatSuccess("\n程序执行完成\n");
    return 0;
}
