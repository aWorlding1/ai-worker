#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <cstdlib>
#include <algorithm>
#include <unistd.h>
#include <cctype>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <readline/readline.h>
#include <readline/history.h>
#include <list>
#include <unordered_map>
#include <mutex>
#include <future>

namespace fs = std::filesystem;

// ====================== 终端颜色格式化工具 ======================
class TerminalFormatter {
public:
    static const std::string RESET;
    static const std::string BOLD;
    static const std::string GREEN;
    static const std::string BLUE;
    static const std::string RED;
    static const std::string YELLOW;
    static const std::string CYAN;
    static const std::string MAGENTA;
    
    static std::string formatHeader(const std::string& text) {
        return BOLD + BLUE + text + RESET;
    }
    
    static std::string formatSuccess(const std::string& text) {
        return BOLD + GREEN + text + RESET;
    }
    
    static std::string formatError(const std::string& text) {
        return BOLD + RED + text + RESET;
    }
    
    static std::string formatWarning(const std::string& text) {
        return BOLD + YELLOW + text + RESET;
    }
    
    static std::string formatDirectory(const std::string& text) {
        return BOLD + CYAN + text + RESET;
    }
    
    static void printSeparator(int length = 50) {
        std::cout << BOLD << std::string(length, '=') << RESET << "\n";
    }
};

const std::string TerminalFormatter::RESET = "\033[0m";
const std::string TerminalFormatter::BOLD = "\033[1m";
const std::string TerminalFormatter::GREEN = "\033[32m";
const std::string TerminalFormatter::BLUE = "\033[34m";
const std::string TerminalFormatter::RED = "\033[31m";
const std::string TerminalFormatter::YELLOW = "\033[33m";
const std::string TerminalFormatter::CYAN = "\033[36m";
const std::string TerminalFormatter::MAGENTA = "\033[35m";

// ====================== 字符串工具 ======================
class StringUtils {
public:
    static std::string trim(const std::string& str) {
        const char* whitespace = " \t\n\r\f\v";
        size_t start = str.find_first_not_of(whitespace);
        if (start == std::string::npos) return "";
        size_t end = str.find_last_not_of(whitespace);
        return str.substr(start, end - start + 1);
    }
    
    static bool is_numeric(const std::string& str) {
        if (str.empty()) return false;
        for (char c : str) {
            if (!std::isdigit(static_cast<unsigned char>(c))) {
                return false;
            }
        }
        return true;
    }
    
    static std::string getCurrentTime() {
        auto now = std::chrono::system_clock::now();
        auto in_time_t = std::chrono::system_clock::to_time_t(now);
        std::stringstream ss;
        ss << std::put_time(std::localtime(&in_time_t), "%Y-%m-%d %H:%M:%S");
        return ss.str();
    }
};

// ====================== 超激进目录缓存系统 ======================
class DirectoryCache {
private:
    struct CacheEntry {
        fs::path path;
        std::vector<fs::path> subdirs;
        std::chrono::system_clock::time_point last_access;
        bool is_fully_cached = false;
    };

    std::unordered_map<fs::path, CacheEntry> cache;
    std::list<fs::path> lru_queue;
    size_t max_size = 1000000;
    mutable std::mutex cache_mutex;

public:
    size_t size() const { 
        std::lock_guard<std::mutex> lock(cache_mutex);
        return cache.size(); 
    }

    bool get(const fs::path& path, std::vector<fs::path>& out_subdirs) {
        std::lock_guard<std::mutex> lock(cache_mutex);
        auto it = cache.find(path);
        if (it == cache.end()) return false;

        lru_queue.remove(path);
        lru_queue.push_front(path);
        it->second.last_access = std::chrono::system_clock::now();

        out_subdirs = it->second.subdirs;
        return true;
    }

    void set(const fs::path& path, const std::vector<fs::path>& subdirs, bool fully_cached = false) {
        std::lock_guard<std::mutex> lock(cache_mutex);
        if (cache.size() >= max_size) {
            fs::path old_path = lru_queue.back();
            lru_queue.pop_back();
            cache.erase(old_path);
        }

        CacheEntry entry{path, subdirs, std::chrono::system_clock::now(), fully_cached};
        cache[path] = entry;
        lru_queue.push_front(path);
    }

    bool isFullyCached(const fs::path& path) const {
        std::lock_guard<std::mutex> lock(cache_mutex);
        auto it = cache.find(path);
        return it != cache.end() && it->second.is_fully_cached;
    }

    void markFullyCached(const fs::path& path) {
        std::lock_guard<std::mutex> lock(cache_mutex);
        auto it = cache.find(path);
        if (it != cache.end()) {
            it->second.is_fully_cached = true;
        }
    }
};

static DirectoryCache dir_cache;

// ====================== 目录扫描器 ======================
class DirectoryScanner {
private:
    static std::vector<fs::path> scanDirectoriesImpl(const fs::path& path) {
        std::vector<fs::path> directories;
        
        if (dir_cache.get(path, directories)) {
            return directories;
        }

        try {
            auto start = std::chrono::high_resolution_clock::now();
            
            for (const auto& entry : fs::directory_iterator(path, 
                 fs::directory_options::skip_permission_denied)) {
                if (entry.is_directory()) {
                    directories.emplace_back(entry.path());
                }
            }
            
            auto end = std::chrono::high_resolution_clock::now();
            std::cout << TerminalFormatter::formatSuccess("✓ 扫描完成: ") 
                      << directories.size() << " 个目录, 耗时 " 
                      << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() 
                      << "ms\n";
            
            dir_cache.set(path, directories);
        } catch (const fs::filesystem_error& e) {
            std::cerr << TerminalFormatter::formatError("扫描错误: ") << e.what() << "\n";
        }
        
        return directories;
    }

    static void preloadSubdirectories(const fs::path& parent) {
        std::vector<fs::path> subdirs;
        if (dir_cache.get(parent, subdirs)) {
            for (const auto& dir : subdirs) {
                if (!dir_cache.isFullyCached(dir)) {
                    std::async(std::launch::async, [dir]() {
                        try {
                            auto dirs = scanDirectoriesImpl(dir);
                            dir_cache.set(dir, dirs, true);
                            preloadSubdirectories(dir);
                        } catch (...) {}
                    });
                }
            }
        }
    }

public:
    static std::vector<fs::path> scanDirectories(const fs::path& path) {
        auto directories = scanDirectoriesImpl(path);
        if (!directories.empty()) {
            std::async(std::launch::async, [path]() {
                dir_cache.markFullyCached(path);
                preloadSubdirectories(path);
            });
        }
        return directories;
    }
};

// ====================== 用户输入处理器 ======================
class InputHandler {
public:
    static size_t getDirectoryChoice(const std::vector<fs::path>& directories, bool allow_back = false) {
        while (true) {
            std::cout << "\n" << TerminalFormatter::formatHeader("请选择目录 (1-") 
                      << directories.size() << TerminalFormatter::formatHeader(")");
            if (allow_back) {
                std::cout << TerminalFormatter::formatHeader(", 或输入 'b' 返回上级目录");
            }
            std::cout << TerminalFormatter::formatHeader(": ");
            
            std::string input;
            if (!std::getline(std::cin, input)) {
                std::cout << TerminalFormatter::formatError("输入错误\n");
                continue;
            }
            
            input = StringUtils::trim(input);
            
            if (input == "q" || input == "Q") {
                std::cout << TerminalFormatter::formatWarning("退出程序\n");
                std::exit(0);
            }
            
            if (allow_back && (input == "b" || input == "B")) {
                return 0;
            }
            
            if (!StringUtils::is_numeric(input)) {
                std::cout << TerminalFormatter::formatError("请输入有效的数字\n");
                continue;
            }
            
            try {
                size_t choice = std::stoul(input);
                if (choice >= 1 && choice <= directories.size()) {
                    return choice;
                }
                std::cout << TerminalFormatter::formatError("请输入 1-") 
                          << directories.size() << " 之间的数字\n";
            } catch (const std::exception&) {
                std::cout << TerminalFormatter::formatError("无效的选择\n");
            }
        }
    }
    
    static std::string getCommand() {
        using_history();
        stifle_history(100);
        
        while (true) {
            char* input = readline(TerminalFormatter::formatHeader("\n请输入要执行的命令: ").c_str());
            if (!input) {
                std::cout << TerminalFormatter::formatError("输入错误\n");
                continue;
            }
            
            std::string command = StringUtils::trim(input);
            free(input);
            
            if (command == "q" || command == "Q") {
                std::cout << TerminalFormatter::formatWarning("退出程序\n");
                std::exit(0);
            }
            
            if (!command.empty()) {
                add_history(command.c_str());
                return command;
            }
            std::cout << TerminalFormatter::formatError("命令不能为空\n");
        }
    }
    
    static bool getConfirmation(const std::string& message) {
        std::cout << TerminalFormatter::formatWarning(message);
        
        char* input = readline("");
        if (!input) {
            return true;
        }
        
        std::string response = StringUtils::trim(input);
        free(input);
        
        if (response.empty()) return true;
        return (response == "y" || response == "Y" || response == "yes");
    }
};

// ====================== 异步命令执行器 ======================
class CommandExecutor {
public:
    static int executeCommand(const fs::path& directory, const std::string& command) {
        char old_cwd[1024];
        if (!getcwd(old_cwd, sizeof(old_cwd))) {
            std::cerr << TerminalFormatter::formatError("无法获取当前目录\n");
            return -1;
        }
        
        if (chdir(directory.c_str()) != 0) {
            std::perror(TerminalFormatter::formatError("更改目录失败").c_str());
            return -1;
        }
        
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd))) {
            std::cout << TerminalFormatter::formatDirectory("当前目录: ") << cwd << "\n";
        }
        
        std::cout << TerminalFormatter::formatDirectory("执行命令: ") << command << "\n";
        TerminalFormatter::printSeparator();
        
        auto start_time = std::chrono::high_resolution_clock::now();
        int ret = std::system(command.c_str());
        auto end_time = std::chrono::high_resolution_clock::now();
        
        TerminalFormatter::printSeparator();
        std::cout << TerminalFormatter::formatSuccess("执行完成, 耗时: ") 
                  << std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count() 
                  << "ms\n";
        
        chdir(old_cwd);
        return ret;
    }
};

// ====================== 界面显示工具 ======================
void displayWelcome() {
    std::cout << TerminalFormatter::formatHeader("🚀 终极目录命令执行工具 (RAM优化版)") << "\n";
    std::cout << TerminalFormatter::formatHeader("════════════════════════════════════════") << "\n";
    std::cout << "启动时间: " << StringUtils::getCurrentTime() << "\n";
    std::cout << "内存缓存: " << dir_cache.size() << " 条目录\n\n";
}

void displayDirectoryList(const std::vector<fs::path>& directories, const fs::path& current_path) {
    std::cout << TerminalFormatter::formatHeader("📁 当前路径: ") << current_path << "\n";
    std::cout << TerminalFormatter::formatHeader("内存缓存: ") << dir_cache.size() << " 条目录\n";
    std::cout << TerminalFormatter::formatHeader("可用的子目录:") << "\n";
    TerminalFormatter::printSeparator();
    
    for (size_t i = 0; i < directories.size(); ++i) {
        std::string cache_status = dir_cache.isFullyCached(directories[i]) 
            ? TerminalFormatter::formatSuccess("[已缓存]") 
            : TerminalFormatter::formatWarning("[未缓存]");
        
        std::cout << std::setw(3) << (i + 1) << ". " 
                  << TerminalFormatter::formatDirectory(directories[i].filename().string()) 
                  << " " << cache_status << "\n";
    }
    
    TerminalFormatter::printSeparator();
}

// ====================== 主循环 ======================
void mainLoop(fs::path current_path) {
    while (true) {
        auto directories = DirectoryScanner::scanDirectories(current_path);
        
        if (directories.empty()) {
            std::cout << TerminalFormatter::formatWarning("没有找到子目录\n");
            return;
        }
        
        std::sort(directories.begin(), directories.end(), [](const fs::path& a, const fs::path& b) {
            return a.filename().string() < b.filename().string();
        });
        
        displayDirectoryList(directories, current_path);
        size_t choice = InputHandler::getDirectoryChoice(directories, true);
        
        if (choice == 0) {
            current_path = current_path.parent_path();
            continue;
        }
        
        fs::path selected_dir = directories[choice - 1];
        std::string command = InputHandler::getCommand();
        
        std::cout << "\n" << TerminalFormatter::formatWarning("⚠️  执行确认:") << "\n";
        std::cout << "目录: " << TerminalFormatter::formatDirectory(selected_dir.string()) << "\n";
        std::cout << "命令: " << TerminalFormatter::formatDirectory(command) << "\n";
        
        if (!InputHandler::getConfirmation("确定要执行吗? (Y/n): ")) {
            std::cout << TerminalFormatter::formatWarning("操作已取消\n");
            continue;
        }
        
        std::cout << TerminalFormatter::formatSuccess("\n开始执行命令...\n");
        int result = CommandExecutor::executeCommand(selected_dir, command);
        
        if (result == 0) {
            std::cout << TerminalFormatter::formatSuccess("✅ 命令执行成功\n");
        } else {
            std::cout << TerminalFormatter::formatError("❌ 命令执行失败, 返回码: ") << result << "\n";
        }
        
        if (!InputHandler::getConfirmation("是否继续在当前目录操作? (Y/n): ")) {
            return;
        }
    }
}

// ====================== 主函数 ======================
int main(int argc, char* argv[]) {
    displayWelcome();
    fs::path target_path = (argc > 1) ? argv[1] : fs::current_path();
    
    try {
        if (!fs::exists(target_path)) {
            std::cerr << TerminalFormatter::formatError("错误: 路径不存在 - ") << target_path << "\n";
            return 1;
        }
        
        if (!fs::is_directory(target_path)) {
            std::cerr << TerminalFormatter::formatError("错误: 不是目录 - ") << target_path << "\n";
            return 1;
        }
        
        mainLoop(target_path);
        
    } catch (const fs::filesystem_error& e) {
        std::cerr << TerminalFormatter::formatError("文件系统错误: ") << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << TerminalFormatter::formatError("错误: ") << e.what() << "\n";
        return 1;
    }
    
    std::cout << TerminalFormatter::formatSuccess("\n程序执行完成\n");
    return 0;
}
