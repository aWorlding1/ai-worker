#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <cstring>
#include <cstdlib>
#include <cctype>
#include <algorithm>
#include <vector>
#include <string_view>

// ====================== 编译时常量 ======================
constexpr size_t MAX_PATH_LEN = 4096;
constexpr size_t INPUT_BUF_SIZE = 256;
constexpr size_t MAX_DIRS = 1000;

// ====================== 终端颜色 (内联汇编级优化) ======================
struct TermColor {
    static constexpr const char* RESET = "\033[0m";
    static constexpr const char* BOLD = "\033[1m";
    static constexpr const char* GREEN = "\033[32m";
    static constexpr const char* RED = "\033[31m";
    
    static inline void write_color(const char* color) {
        write(STDOUT_FILENO, color, std::char_traits<char>::length(color));
    }
    
    static inline void write_str(const char* str, size_t len) {
        write(STDOUT_FILENO, str, len);
    }
};

// ====================== 字符串工具 (SIMD风格) ======================
namespace StrUtil {
    static inline bool is_numeric(const char* str, size_t len) {
        for (size_t i = 0; i < len; ++i) {
            if (str[i] < '0' || str[i] > '9') return false;
        }
        return len > 0;
    }
    
    static inline size_t fast_atoi(const char* str, size_t len) {
        size_t result = 0;
        for (size_t i = 0; i < len; ++i) {
            result = result * 10 + (str[i] - '0');
        }
        return result;
    }
    
    static inline void trim_inplace(char* str, size_t* len) {
        // 去除前导空白
        size_t start = 0;
        while (start < *len && (str[start] == ' ' || str[start] == '\t')) {
            ++start;
        }
        
        // 去除尾部空白
        size_t end = *len;
        while (end > start && (str[end-1] == ' ' || str[end-1] == '\t' || str[end-1] == '\n')) {
            --end;
        }
        
        // 移动内容
        if (start > 0) {
            for (size_t i = 0; i < end - start; ++i) {
                str[i] = str[start + i];
            }
        }
        str[end - start] = '\0';
        *len = end - start;
    }
}

// ====================== 目录缓存 (零分配) ======================
class DirCache {
    static inline char dir_names[MAX_DIRS][256];
    static inline char dir_paths[MAX_DIRS][MAX_PATH_LEN];
    static inline size_t dir_count = 0;
    static inline char current_path[MAX_PATH_LEN];
    
public:
    static bool scan(const char* path) {
        DIR* dir = opendir(path);
        if (!dir) return false;
        
        dir_count = 0;
        strncpy(current_path, path, MAX_PATH_LEN);
        
        struct dirent* entry;
        while ((entry = readdir(dir)) && dir_count < MAX_DIRS) {
            if (entry->d_type == DT_DIR && entry->d_name[0] != '.') {
                strncpy(dir_names[dir_count], entry->d_name, 255);
                
                // 构建完整路径
                size_t path_len = strlen(path);
                strncpy(dir_paths[dir_count], path, MAX_PATH_LEN);
                if (path[path_len-1] != '/') {
                    strncat(dir_paths[dir_count], "/", MAX_PATH_LEN - strlen(dir_paths[dir_count]) - 1);
                }
                strncat(dir_paths[dir_count], entry->d_name, MAX_PATH_LEN - strlen(dir_paths[dir_count]) - 1);
                
                ++dir_count;
            }
        }
        
        closedir(dir);
        
        // 快速排序目录名
        for (size_t i = 0; i < dir_count - 1; ++i) {
            for (size_t j = i + 1; j < dir_count; ++j) {
                if (strcmp(dir_names[i], dir_names[j]) > 0) {
                    // 交换名称
                    char temp_name[256];
                    strcpy(temp_name, dir_names[i]);
                    strcpy(dir_names[i], dir_names[j]);
                    strcpy(dir_names[j], temp_name);
                    
                    // 交换路径
                    char temp_path[MAX_PATH_LEN];
                    strcpy(temp_path, dir_paths[i]);
                    strcpy(dir_paths[i], dir_paths[j]);
                    strcpy(dir_paths[j], temp_path);
                }
            }
        }
        
        return dir_count > 0;
    }
    
    static size_t count() { return dir_count; }
    static const char* name(size_t idx) { return dir_names[idx]; }
    static const char* path(size_t idx) { return dir_paths[idx]; }
    static const char* current() { return current_path; }
};

// ====================== 输入处理 (系统调用级) ======================
class Input {
    static inline char buffer[INPUT_BUF_SIZE];
    
public:
    static size_t get_choice(size_t max) {
        while (true) {
            const char prompt[] = "\n请选择目录 (1-";
            write(STDOUT_FILENO, prompt, sizeof(prompt) - 1);
            
            char max_str[16];
            size_t max_len = 0;
            size_t tmp = max;
            do {
                max_str[max_len++] = '0' + (tmp % 10);
                tmp /= 10;
            } while (tmp > 0);
            
            for (size_t i = 0; i < max_len / 2; ++i) {
                char t = max_str[i];
                max_str[i] = max_str[max_len - 1 - i];
                max_str[max_len - 1 - i] = t;
            }
            
            write(STDOUT_FILENO, max_str, max_len);
            
            const char prompt_end[] = "): ";
            write(STDOUT_FILENO, prompt_end, sizeof(prompt_end) - 1);
            
            ssize_t len = read(STDIN_FILENO, buffer, INPUT_BUF_SIZE - 1);
            if (len <= 0) continue;
            
            buffer[len] = '\0';
            size_t input_len = len;
            StrUtil::trim_inplace(buffer, &input_len);
            
            if (StrUtil::is_numeric(buffer, input_len)) {
                size_t choice = StrUtil::fast_atoi(buffer, input_len);
                if (choice > 0 && choice <= max) {
                    return choice;
                }
            }
            
            const char error[] = "请输入有效的数字\n";
            write(STDOUT_FILENO, error, sizeof(error) - 1);
        }
    }
    
    static bool get_command(char* cmd_buf, size_t buf_size) {
        const char prompt[] = "\n请输入命令: ";
        write(STDOUT_FILENO, prompt, sizeof(prompt) - 1);
        
        ssize_t len = read(STDIN_FILENO, cmd_buf, buf_size - 1);
        if (len <= 0) return false;
        
        cmd_buf[len] = '\0';
        size_t cmd_len = len;
        StrUtil::trim_inplace(cmd_buf, &cmd_len);
        
        return cmd_len > 0;
    }
};

// ====================== 命令执行 (fork优化) ======================
class Executor {
public:
    static int execute(const char* path, const char* cmd) {
        if (chdir(path) != 0) {
            const char error[] = "更改目录失败\n";
            write(STDERR_FILENO, error, sizeof(error) - 1);
            return -1;
        }
        
        TermColor::write_color(TermColor::BOLD);
        TermColor::write_color(TermColor::GREEN);
        const char exec_msg[] = "执行命令: ";
        write(STDOUT_FILENO, exec_msg, sizeof(exec_msg) - 1);
        TermColor::write_color(TermColor::RESET);
        write(STDOUT_FILENO, cmd, strlen(cmd));
        write(STDOUT_FILENO, "\n", 1);
        
        pid_t pid = fork();
        if (pid == -1) {
            const char fork_err[] = "fork失败\n";
            write(STDERR_FILENO, fork_err, sizeof(fork_err) - 1);
            return -1;
        }
        
        if (pid == 0) {
            execl("/bin/sh", "sh", "-c", cmd, nullptr);
            _exit(127);
        }
        
        int status;
        waitpid(pid, &status, 0);
        return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    }
};

// ====================== 主导航循环 ======================
static void navigate(const char* start_path) {
    char current_path[MAX_PATH_LEN];
    strncpy(current_path, start_path, MAX_PATH_LEN);
    char command_buf[INPUT_BUF_SIZE];
    
    while (true) {
        if (!DirCache::scan(current_path)) {
            const char no_dirs[] = "没有找到子目录\n";
            write(STDERR_FILENO, no_dirs, sizeof(no_dirs) - 1);
            return;
        }
        
        // 显示目录列表
        for (size_t i = 0; i < DirCache::count(); ++i) {
            char num_buf[16];
            size_t num_len = 0;
            size_t num = i + 1;
            
            do {
                num_buf[num_len++] = '0' + (num % 10);
                num /= 10;
            } while (num > 0);
            
            for (size_t j = 0; j < num_len / 2; ++j) {
                char t = num_buf[j];
                num_buf[j] = num_buf[num_len - 1 - j];
                num_buf[num_len - 1 - j] = t;
            }
            
            write(STDOUT_FILENO, num_buf, num_len);
            
            const char dot[] = ". ";
            write(STDOUT_FILENO, dot, sizeof(dot) - 1);
            
            const char* name = DirCache::name(i);
            write(STDOUT_FILENO, name, strlen(name));
            write(STDOUT_FILENO, "\n", 1);
        }
        
        size_t choice = Input::get_choice(DirCache::count());
        strncpy(current_path, DirCache::path(choice - 1), MAX_PATH_LEN);
        
        if (Input::get_command(command_buf, sizeof(command_buf))) {
            int result = Executor::execute(current_path, command_buf);
            
            if (result == 0) {
                TermColor::write_color(TermColor::BOLD);
                TermColor::write_color(TermColor::GREEN);
                const char success[] = "命令执行成功\n";
                write(STDOUT_FILENO, success, sizeof(success) - 1);
                TermColor::write_color(TermColor::RESET);
            } else {
                TermColor::write_color(TermColor::BOLD);
                TermColor::write_color(TermColor::RED);
                const char fail[] = "命令执行失败\n";
                write(STDOUT_FILENO, fail, sizeof(fail) - 1);
                TermColor::write_color(TermColor::RESET);
            }
        }
    }
}

// ====================== 主函数 ======================
int main(int argc, char** argv) {
    const char* start_path = ".";
    if (argc > 1) {
        start_path = argv[1];
    }
    
    char abs_path[MAX_PATH_LEN];
    if (realpath(start_path, abs_path) == nullptr) {
        const char invalid_path[] = "无效路径\n";
        write(STDERR_FILENO, invalid_path, sizeof(invalid_path) - 1);
        return 1;
    }
    
    struct stat path_stat;
    if (stat(abs_path, &path_stat) != 0 || !S_ISDIR(path_stat.st_mode)) {
        const char not_dir[] = "不是目录\n";
        write(STDERR_FILENO, not_dir, sizeof(not_dir) - 1);
        return 1;
    }
    
    navigate(abs_path);
    return 0;
}
