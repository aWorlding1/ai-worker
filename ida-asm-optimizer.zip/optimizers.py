#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
IDA反汇编.asm文件智能优化工具 - 优化器模块
包含所有优化相关的类
"""

import re
from collections import defaultdict
from functools import lru_cache
from typing import Union

from constants import (
    ARM_INSTRUCTION_SETS,
    JUMP_OPCODES,
    CALL_OPCODES,
    DATA_OPCODES,
    MEM_OPCODES,
    KEEP_COMMENT_MARKERS,
    ELF_STRUCTS,
    RE_SUBROUTINE,
    RE_SEPARATOR,
    RE_CODE_XREF,
    RE_DATA_XREF,
    RE_STRUCT_BEGIN,
    RE_STRUCT_END,
    RE_STRUCT_FIELD,
    RE_STRING_DCB,
    RE_ALIGN_DIRECTIVE,
    RE_REPEATED_OP,
)


def calculate_compression_ratio(original: Union[str, int], compressed: Union[str, int]) -> float:
    """计算压缩率"""
    original_size = len(original) if isinstance(original, str) else original
    compressed_size = len(compressed) if isinstance(compressed, str) else compressed
    return 1.0 - (compressed_size / original_size) if original_size > 0 else 0.0


def is_elf_struct(name: str) -> bool:
    """检查是否为ELF相关结构体"""
    return name in ELF_STRUCTS or "::$" in name


@lru_cache(maxsize=1024)
def get_opcode_type(opcode: str) -> str:
    """确定操作码类型 - 使用缓存提高性能"""
    opcode_upper = opcode.upper()

    # 移除后缀以获取基本指令
    base_opcode = opcode_upper
    for suffix in ARM_INSTRUCTION_SETS["thumb"]["condition_codes"].union(
        ARM_INSTRUCTION_SETS["arm"]["condition_codes"]
    ):
        if base_opcode.endswith(suffix):
            base_opcode = base_opcode[: -len(suffix)]
            break

    # 移除.W/.N后缀
    if base_opcode.endswith(".W") or base_opcode.endswith(".N"):
        base_opcode = base_opcode[:-2]

    if any(base_opcode.startswith(jump) for jump in JUMP_OPCODES):
        return "jump"
    elif any(base_opcode.startswith(call) for call in CALL_OPCODES):
        return "call"
    elif any(base_opcode == data for data in DATA_OPCODES):
        return "data"
    elif any(base_opcode.startswith(mem) for mem in MEM_OPCODES):
        return "memory"
    elif base_opcode.startswith("IT"):
        return "it_block"
    return "other"


class CommentCompressor:
    """注释压缩子系统 - 负责智能压缩注释内容"""

    def __init__(self, preservation_level=0.5):
        self.preservation_level = preservation_level  # 0.0-1.0，表示保留程度
        self.comment_patterns = self._compile_patterns()
        self.structure_detectors = self._init_structure_detectors()
        self.stats = {"total_comments": 0, "preserved_comments": 0, "compressed_comments": 0, "removed_comments": 0}

    def _compile_patterns(self):
        """编译常见注释模式的正则表达式"""
        patterns = {
            "separator": re.compile(r"; [-=]{10,}"),
            "xref": re.compile(r"; (CODE|DATA) XREF: (.+)"),
            "address": re.compile(r"; addr: ([0-9A-Fa-f]+)"),
            "function": re.compile(r"; Function start|end"),
            "struct_field": re.compile(r"; field at 0x([0-9A-Fa-f]+)"),
            "align": re.compile(r"; align ([0-9A-Fa-f]+)"),
            "subroutine": RE_SUBROUTINE,
            "unwind": re.compile(r"; __unwind \{"),
            "end_bracket": re.compile(r"; \}"),
        }
        return patterns

    def _init_structure_detectors(self):
        """初始化结构检测器"""
        return {
            "function_start": lambda i, lines: i > 0 and RE_SUBROUTINE.match(lines[i - 1]) is not None,
            "function_end": lambda i, lines: i < len(lines) - 1 and "; End of function" in lines[i],
            "xref_section": lambda i, lines: "; XREF:" in lines[i],
            "unwind_section": lambda i, lines: "; __unwind {" in lines[i],
        }

    def compress(self, asm_content):
        """压缩ASM内容中的注释"""
        lines = asm_content.split("\n")
        result = []

        # 重置统计
        self.stats = {"total_comments": 0, "preserved_comments": 0, "compressed_comments": 0, "removed_comments": 0}

        # 构建注释图谱
        comment_map = self._build_comment_map(lines)

        # 应用压缩策略
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            if line_stripped.startswith(";"):
                self.stats["total_comments"] += 1
                # 应用注释压缩策略
                if self._should_preserve_comment(line, i, comment_map):
                    # 对保留的注释进行格式优化
                    optimized = self._optimize_comment_format(line)
                    result.append(optimized)

                    if optimized != line:
                        self.stats["compressed_comments"] += 1
                    else:
                        self.stats["preserved_comments"] += 1
                else:
                    self.stats["removed_comments"] += 1
            else:
                result.append(line)

        return "\n".join(result)

    def _build_comment_map(self, lines):
        """构建注释的位置和重要性图谱"""
        comment_map = {}
        function_level = 0  # 跟踪函数嵌套级别
        in_function = False

        for i, line in enumerate(lines):
            line_stripped = line.strip()
            if line_stripped.startswith(";"):
                importance = 0.0

                # 检测函数结构
                if RE_SUBROUTINE.match(line):
                    in_function = True
                    importance += 1.0  # 函数头注释重要性最高
                elif "; End of function" in line:
                    in_function = False
                    importance += 0.8  # 函数尾注释重要性高

                # 检测XREF
                if "XREF:" in line:
                    importance += 0.7  # XREF注释重要

                # 检测描述性注释
                if any(marker in line for marker in ["address", "field at", "offset"]):
                    importance += 0.5

                # 检测分隔符
                if RE_SEPARATOR.match(line):
                    importance += 0.1  # 分隔符注释重要性最低

                comment_map[i] = {
                    "line": line,
                    "importance": importance,
                    "in_function": in_function,
                    "function_level": function_level,
                }

        return comment_map

    def _should_preserve_comment(self, comment, line_index, comment_map):
        """基于上下文和重要性决定是否保留注释"""
        # 特定标记的注释总是保留
        for marker in KEEP_COMMENT_MARKERS:
            if marker in comment:
                return True

        # 子例程标记总是保留
        if RE_SUBROUTINE.match(comment) or "; End of function" in comment:
            return True

        # __unwind 相关的注释选择性保留
        if "; __unwind {" in comment or "; }" in comment:
            return True

        # 计算注释重要性
        importance = self._calculate_comment_importance(comment, line_index, comment_map)

        # 基于保留级别决定
        return importance >= (1.0 - self.preservation_level)

    def _calculate_comment_importance(self, comment, line_index, comment_map):
        """计算注释的重要性得分"""
        score = 0.0

        # 基于模式匹配计算基础分
        for pattern_name, pattern in self.comment_patterns.items():
            if pattern.search(comment):
                if pattern_name == "separator":
                    score += 0.1
                elif pattern_name == "xref":
                    score += 0.7
                elif pattern_name == "address":
                    score += 0.5
                elif pattern_name == "function":
                    score += 0.9
                elif pattern_name == "struct_field":
                    score += 0.6
                elif pattern_name == "subroutine":
                    score += 1.0
                elif pattern_name == "unwind":
                    score += 0.8
                elif pattern_name == "end_bracket":
                    score += 0.8
                else:
                    score += 0.3

        # 检查是否是功能描述注释（不是分隔符，不是XRef，含有可读的单词）
        if score < 0.5 and comment.count(" ") > 3 and not RE_SEPARATOR.match(comment):
            # 可能是功能描述
            word_count = len(re.findall(r"\b[a-zA-Z]{3,}\b", comment))
            if word_count >= 3:
                score += 0.6  # 可能是描述性注释

        # 归一化得分
        return min(1.0, score)

    def _optimize_comment_format(self, comment):
        """优化注释格式，减少空间占用"""
        # 简化分隔符
        if RE_SEPARATOR.match(comment):
            if len(comment) > 40:
                return "; " + "-" * 30
            return comment

        # 检查是否为XREF注释
        xref_code = RE_CODE_XREF.search(comment)
        xref_data = RE_DATA_XREF.search(comment)

        if xref_code or xref_data:
            # 简化XREF格式但保留核心信息
            xref_type = "CODE" if xref_code else "DATA"
            refs = xref_code.group(1) if xref_code else xref_data.group(1)

            # 提取主要引用，删除冗余部分
            simplified_refs = []
            for ref in refs.split(";"):
                ref = ref.strip()
                if "/" in ref:
                    parts = ref.split("/")
                    if len(parts) >= 2:
                        source = parts[0].strip()
                        # 删除上下箭头和多余空格
                        source = re.sub(r"[↑↓]\s*", "", source)
                        simplified_refs.append(f"{source}")

            if simplified_refs:
                return f"; {xref_type} XREF: " + "; ".join(simplified_refs)

        # 检查是否为子例程标记
        if RE_SUBROUTINE.match(comment):
            level = 2  # 可以根据需要调整
            if level == 3:
                return "; === SUBROUTINE ==="
            elif level == 2:
                return "; =============== SUBROUTINE ==============="

        # 默认保持原始格式
        return comment


class FormatOptimizer:
    """格式优化器 - 处理空白和对齐"""

    def __init__(self, alignment=0, preserve_structure=True):
        self.alignment = alignment  # 指令对齐宽度，0表示无对齐
        self.preserve_structure = preserve_structure
        self.stats = {"removed_empty_lines": 0, "compressed_instruction_lines": 0}

    def compress(self, asm_content):
        """优化ASM内容的格式"""
        lines = asm_content.split("\n")
        result = []

        # 重置统计
        self.stats = {"removed_empty_lines": 0, "compressed_instruction_lines": 0}

        # 删除多余空行并优化格式
        i = 0
        while i < len(lines):
            line = lines[i]
            if not line.strip():
                # 检查是否为结构分隔空行
                if self.preserve_structure and self._is_structural_blank(i, lines):
                    result.append("")
                else:
                    self.stats["removed_empty_lines"] += 1
            else:
                # 优化非空行格式
                optimized_line = self._optimize_line_format(line)
                result.append(optimized_line)
                if optimized_line != line:
                    self.stats["compressed_instruction_lines"] += 1
            i += 1

        return "\n".join(result)

    def _optimize_line_format(self, line):
        """优化行格式，处理对齐和空白"""
        line_strip = line.strip()

        # 注释行保持原样
        if line_strip.startswith(";"):
            return line

        # 标签行特殊处理
        if ":" in line_strip and " " not in line_strip.split(":", 1)[0]:
            label, rest = line_strip.split(":", 1)
            if not rest.strip():
                # 只有标签，无需对齐
                return f"{label}:"
            else:
                # 标签后有内容
                return f"{label}: {rest.strip()}"

        # 一般指令行处理
        if " " in line_strip:
            parts = line_strip.split(None, 1)
            if len(parts) == 2:
                opcode, operands = parts
                if self.alignment > 0:
                    # 应用指定的对齐
                    return f"{opcode.ljust(self.alignment)} {operands.strip()}"
                else:
                    # 无对齐，最小化空白
                    return f"{opcode} {operands.strip()}"

        return line_strip  # 返回去除首尾空白的结果

    def _is_structural_blank(self, index, lines):
        """判断空行是否为结构分隔（函数间隔等）"""
        # 检查前后几行来判断是否是结构分隔
        context_size = 2  # 检查上下两行

        # 获取上下文
        prev_lines = [lines[i] for i in range(max(0, index - context_size), index) if i < len(lines)]
        next_lines = [lines[i] for i in range(index + 1, min(len(lines), index + context_size + 1))]

        # 函数结束后的空行
        if any("; End of function" in line for line in prev_lines):
            return True

        # 函数开始前的空行
        if any(RE_SUBROUTINE.match(line) for line in next_lines):
            return True

        # 结构体前后的空行
        if any(RE_STRUCT_END.match(line.strip()) for line in prev_lines) or any(
            RE_STRUCT_BEGIN.match(line.strip()) for line in next_lines
        ):
            return True

        # 区段标记前后的空行
        if any("AREA" in line for line in prev_lines) or any("AREA" in line for line in next_lines):
            return True

        # 默认不保留
        return False


class LabelOptimizer:
    """标签优化器 - 处理标签和引用"""

    def __init__(self, preserve_jump_targets=True, compress_locals=True):
        self.preserve_jump_targets = preserve_jump_targets
        self.compress_locals = compress_locals
        self.jump_targets = set()
        self.label_map = {}  # 原始标签到优化标签的映射
        self.stats = {"total_labels": 0, "preserved_labels": 0, "compressed_labels": 0}

    def compress(self, asm_content):
        """优化ASM内容中的标签"""
        lines = asm_content.split("\n")

        # 重置统计和数据
        self.stats = {"total_labels": 0, "preserved_labels": 0, "compressed_labels": 0}
        self.jump_targets = set()
        self.label_map = {}

        # 第一遍：收集跳转目标
        if self.preserve_jump_targets:
            self._collect_jump_targets(lines)

        # 第二遍：优化标签
        result = []
        for i, line in enumerate(lines):
            line_strip = line.strip()
            if ":" in line_strip and not line_strip.startswith(";"):
                # 处理标签行
                self.stats["total_labels"] += 1
                result.append(self._optimize_label_line(line))
            else:
                # 处理引用了标签的行
                result.append(self._optimize_label_references(line))

        return "\n".join(result)

    def _collect_jump_targets(self, lines):
        """收集所有跳转和调用目标"""
        jump_opcodes = JUMP_OPCODES.union(CALL_OPCODES)

        for line in lines:
            line_strip = line.strip()
            if not line_strip.startswith(";"):
                parts = line_strip.split()
                if parts and parts[0].upper().rstrip(".WN") in jump_opcodes and len(parts) > 1:
                    # 提取跳转目标
                    target = parts[-1].rstrip(",;")
                    if "+" in target:  # 处理地址偏移，如"loc_1234+4"
                        target = target.split("+")[0]
                    self.jump_targets.add(target)

    def _optimize_label_line(self, line):
        """优化标签行"""
        line_strip = line.strip()
        label, rest = line_strip.split(":", 1)
        label = label.strip()

        # 计数并决定是否保留
        if label.startswith("loc_") and self.compress_locals and label not in self.jump_targets:
            # 可以压缩的本地标签
            self.stats["compressed_labels"] += 1
            if not self.preserve_jump_targets:
                # 完全删除未使用标签
                return f"; REMOVED: {line_strip}"
            else:
                # 保留标签但添加压缩标记
                return f"{label}: ; COMPRESSED"
        else:
            # 保留标签
            self.stats["preserved_labels"] += 1
            return line_strip

    def _optimize_label_references(self, line):
        """优化对标签的引用 - 目前保持原样，可扩展实现标签重命名等优化"""
        return line


class XrefCompressor:
    """交叉引用压缩器 - 高效处理XREF网络"""

    def __init__(self, compression_level=2):
        self.compression_level = compression_level  # 1-3，压缩级别
        self.xref_graph = defaultdict(list)  # 源地址 -> [(类型, 目标)]列表
        self.xref_targets = set()  # 所有被引用的目标
        self.stats = {"total_xrefs": 0, "compressed_xrefs": 0, "merged_xrefs": 0}

    def compress(self, asm_content):
        """压缩ASM内容中的XREF注释"""
        lines = asm_content.split("\n")

        # 重置统计和数据
        self.stats = {"total_xrefs": 0, "compressed_xrefs": 0, "merged_xrefs": 0}
        self.xref_graph.clear()
        self.xref_targets.clear()

        # 第一遍：构建XREF图
        self._build_xref_graph(lines)

        # 第二遍：压缩XREF注释
        result = []
        in_xref_section = False
        xref_buffer = []

        for i, line in enumerate(lines):
            if "; CODE XREF:" in line or "; DATA XREF:" in line:
                if not in_xref_section:
                    in_xref_section = True
                    xref_buffer = [line]
                else:
                    xref_buffer.append(line)
                self.stats["total_xrefs"] += 1
            else:
                if in_xref_section:
                    # 处理积累的XREF部分
                    compressed = self._compress_xref_section(xref_buffer)
                    result.extend(compressed)
                    xref_buffer = []
                    in_xref_section = False

                result.append(line)

        # 处理最后可能剩余的XREF缓冲区
        if in_xref_section and xref_buffer:
            compressed = self._compress_xref_section(xref_buffer)
            result.extend(compressed)

        return "\n".join(result)

    def _build_xref_graph(self, lines):
        """构建完整的交叉引用图"""
        xref_pattern_code = RE_CODE_XREF
        xref_pattern_data = RE_DATA_XREF

        for line in lines:
            code_match = xref_pattern_code.search(line)
            data_match = xref_pattern_data.search(line)

            if code_match or data_match:
                xref_type = "CODE" if code_match else "DATA"
                refs = code_match.group(1) if code_match else data_match.group(1)

                # 解析引用列表
                for ref in refs.split(";"):
                    ref = ref.strip()
                    if "/" in ref:
                        source, loc = ref.split("/", 1)
                        source = source.strip()
                        loc = loc.strip()

                        # 清理源地址
                        source = re.sub(r"[↑↓]\s*", "", source)

                        # 添加到引用图
                        self.xref_graph[source].append((xref_type, loc))
                        self.xref_targets.add(source)

    def _compress_xref_section(self, xref_lines):
        """压缩一组XREF行"""
        if not xref_lines:
            return []

        # 按压缩级别处理
        if self.compression_level == 1:
            # 轻度压缩：合并相同类型相邻XREF
            return self._level1_compression(xref_lines)
        elif self.compression_level == 2:
            # 中度压缩：更积极地合并和简化
            return self._level2_compression(xref_lines)
        else:
            # 高度压缩：最小化表示
            return self._level3_compression(xref_lines)

    def _level1_compression(self, xref_lines):
        """1级XREF压缩 - 轻度合并"""
        # 分类XREF
        code_xrefs = []
        data_xrefs = []

        for line in xref_lines:
            if "; CODE XREF:" in line:
                code_match = RE_CODE_XREF.search(line)
                if code_match:
                    code_xrefs.extend(self._parse_xref_list(code_match.group(1)))
            elif "; DATA XREF:" in line:
                data_match = RE_DATA_XREF.search(line)
                if data_match:
                    data_xrefs.extend(self._parse_xref_list(data_match.group(1)))

        result = []

        # 生成合并后的XREF行
        if code_xrefs:
            result.append(f"; CODE XREF: {'; '.join(code_xrefs)}")
            self.stats["merged_xrefs"] += len(code_xrefs) - 1 if len(code_xrefs) > 1 else 0

        if data_xrefs:
            result.append(f"; DATA XREF: {'; '.join(data_xrefs)}")
            self.stats["merged_xrefs"] += len(data_xrefs) - 1 if len(data_xrefs) > 1 else 0

        self.stats["compressed_xrefs"] += len(xref_lines) - len(result)
        return result

    def _level2_compression(self, xref_lines):
        """2级XREF压缩 - 中度简化"""
        # 分类和简化XREF
        code_xrefs = []
        data_xrefs = []

        for line in xref_lines:
            if "; CODE XREF:" in line:
                code_match = RE_CODE_XREF.search(line)
                if code_match:
                    code_xrefs.extend(self._simplify_xrefs(self._parse_xref_list(code_match.group(1))))
            elif "; DATA XREF:" in line:
                data_match = RE_DATA_XREF.search(line)
                if data_match:
                    data_xrefs.extend(self._simplify_xrefs(self._parse_xref_list(data_match.group(1))))

        result = []

        # 生成简化后的XREF行，限制长度
        if code_xrefs:
            simplified = self._format_limited_xrefs(code_xrefs, 80)
            for line in simplified:
                result.append(f"; CODE XREF: {line}")
            self.stats["merged_xrefs"] += len(code_xrefs) - len(simplified)

        if data_xrefs:
            simplified = self._format_limited_xrefs(data_xrefs, 80)
            for line in simplified:
                result.append(f"; DATA XREF: {line}")
            self.stats["merged_xrefs"] += len(data_xrefs) - len(simplified)

        self.stats["compressed_xrefs"] += len(xref_lines) - len(result)
        return result

    def _level3_compression(self, xref_lines):
        """3级XREF压缩 - 极度简化"""
        # 对于极度压缩，我们只保留最基本信息
        code_xrefs = set()
        data_xrefs = set()

        for line in xref_lines:
            if "; CODE XREF:" in line:
                code_match = RE_CODE_XREF.search(line)
                if code_match:
                    for ref in self._parse_xref_list(code_match.group(1)):
                        if "/" in ref:
                            source = ref.split("/", 1)[0].strip()
                            code_xrefs.add(source)
            elif "; DATA XREF:" in line:
                data_match = RE_DATA_XREF.search(line)
                if data_match:
                    for ref in self._parse_xref_list(data_match.group(1)):
                        if "/" in ref:
                            source = ref.split("/", 1)[0].strip()
                            data_xrefs.add(source)

        result = []

        # 生成最简化的XREF行
        if code_xrefs:
            result.append(f"; CODE XREF: {', '.join(sorted(code_xrefs))}")
        if data_xrefs:
            result.append(f"; DATA XREF: {', '.join(sorted(data_xrefs))}")

        self.stats["compressed_xrefs"] += len(xref_lines) - len(result)
        self.stats["merged_xrefs"] += (len(code_xrefs) + len(data_xrefs)) - len(result)
        return result

    def _parse_xref_list(self, refs_str):
        """解析XREF列表字符串为单独引用列表"""
        refs = []
        for ref in refs_str.split(";"):
            ref = ref.strip()
            if ref:
                refs.append(ref)
        return refs

    def _simplify_xrefs(self, xrefs):
        """简化XREF列表，删除冗余部分"""
        simplified = []
        for ref in xrefs:
            if "/" in ref:
                parts = ref.split("/")
                if len(parts) >= 2:
                    source = parts[0].strip()
                    # 删除上下箭头和多余空格
                    source = re.sub(r"[↑↓]\s*", "", source)
                    simplified.append(f"{source}/{parts[1].strip()}")
            else:
                simplified.append(ref)
        return simplified

    def _format_limited_xrefs(self, xrefs, max_length):
        """将XREF列表格式化为固定长度的多行"""
        if not xrefs:
            return []

        result = []
        current_line = []
        current_length = 0

        for ref in xrefs:
            # 预计增加的长度
            added_length = len(ref) + 2  # +2 for "; "

            if current_length + added_length > max_length and current_line:
                # 当前行已满，添加到结果并开始新行
                result.append("; ".join(current_line))
                current_line = [ref]
                current_length = added_length
            else:
                # 添加到当前行
                current_line.append(ref)
                current_length += added_length

        # 添加最后一行
        if current_line:
            result.append("; ".join(current_line))

        return result


class DataDefinitionCompressor:
    """数据定义压缩器 - 优化数据区域"""

    def __init__(self, compression_level=2):
        self.compression_level = compression_level
        self.data_patterns = self._compile_patterns()
        self.stats = {"total_data_defs": 0, "compressed_strings": 0, "compressed_arrays": 0, "compressed_spaces": 0}

    def _compile_patterns(self):
        """编译数据定义模式"""
        patterns = {
            "string": RE_STRING_DCB,
            "array": re.compile(r"([a-zA-Z0-9_]+)\s+(DCD|DCW|DCB)\s+(.+)"),
            "space": re.compile(r"([a-zA-Z0-9_]+)\s+SPACE\s+(\d+)"),
            "align": RE_ALIGN_DIRECTIVE,
            "repeated": RE_REPEATED_OP,
        }
        return patterns

    def compress(self, asm_content):
        """压缩ASM内容中的数据定义"""
        lines = asm_content.split("\n")
        result = []

        # 重置统计
        self.stats = {"total_data_defs": 0, "compressed_strings": 0, "compressed_arrays": 0, "compressed_spaces": 0}

        i = 0
        while i < len(lines):
            line = lines[i]
            line_strip = line.strip()

            # 检查是否为数据定义行
            is_data_def = False
            for pattern_name, pattern in self.data_patterns.items():
                if pattern.search(line_strip):
                    self.stats["total_data_defs"] += 1
                    # 根据数据类型应用特定压缩
                    compressed_lines, skip = self._compress_data_definition(line, pattern_name, lines, i)
                    result.extend(compressed_lines)

                    # 跳过已处理的行
                    i += skip
                    is_data_def = True
                    break

            if not is_data_def:
                result.append(line)
                i += 1

        return "\n".join(result)

    def _compress_data_definition(self, line, pattern_name, lines, start_index):
        """基于数据类型应用压缩策略"""
        if pattern_name == "string":
            return self._compress_string_definition(line, lines, start_index)
        elif pattern_name == "array":
            return self._compress_array_definition(line, lines, start_index)
        elif pattern_name == "space":
            return self._compress_space_definition(line, lines, start_index)
        elif pattern_name == "align":
            return self._compress_align_directive(line, lines, start_index)
        elif pattern_name == "repeated":
            return self._compress_repeated_op(line, lines, start_index)
        else:
            return [line], 1

    def _compress_string_definition(self, line, lines, start_index):
        """压缩字符串定义"""
        match = self.data_patterns["string"].search(line.strip())
        if match:
            label, string, comment = match.groups()
            comment = comment if comment else ""

            # 检查ALIGN行
            next_index = start_index + 1
            has_align = False
            if next_index < len(lines) and "ALIGN" in lines[next_index]:
                has_align = True

            # 基于压缩级别处理
            if self.compression_level >= 2 and has_align:
                # 合并字符串和ALIGN行
                self.stats["compressed_strings"] += 1
                return [f"{label} DCB \"{string}\",0{' ; ' + comment.strip() if comment.strip() else ''} ; +ALIGN"], 2
            elif self.compression_level >= 3:
                # 更激进的压缩
                self.stats["compressed_strings"] += 1
                simplified_comment = self._simplify_comment(comment)
                result = f'{label} DCB "{string}",0'
                if simplified_comment:
                    result += f" ; {simplified_comment}"
                if has_align:
                    result += " ; +ALIGN"
                    return [result], 2
                return [result], 1

        # 默认情况
        return [line], 1

    def _compress_array_definition(self, line, lines, start_index):
        """压缩数组定义"""
        match = self.data_patterns["array"].search(line.strip())
        if match:
            label, data_type, values = match.groups()

            # 检测连续数组定义
            if self.compression_level >= 3:
                array_lines = [line]
                current_index = start_index + 1
                while current_index < len(lines):
                    next_line = lines[current_index].strip()
                    if next_line.startswith(data_type) and ";" not in next_line.split(data_type, 1)[0]:
                        # 连续的数组定义行
                        array_lines.append(lines[current_index])
                        current_index += 1
                    else:
                        break

                if len(array_lines) > 1:
                    # 合并多行数组定义
                    self.stats["compressed_arrays"] += len(array_lines) - 1
                    # 返回简化的表示
                    return (
                        [
                            f"{label} {data_type} ... ; {len(array_lines)} consecutive definitions"
                        ],
                        current_index - start_index,
                    )

            # 单行数组优化
            if self.compression_level >= 2:
                # 检查是否有冗长的注释
                if ";" in line:
                    parts = line.split(";", 1)
                    definition, comment = parts
                    simplified_comment = self._simplify_comment(comment)
                    self.stats["compressed_arrays"] += 1
                    return [f"{definition.strip()}{' ; ' + simplified_comment if simplified_comment else ''}"], 1

        # 默认情况
        return [line], 1

    def _compress_space_definition(self, line, lines, start_index):
        """压缩SPACE定义"""
        match = self.data_patterns["space"].search(line.strip())
        if match:
            label, size = match.groups()

            # SPACE定义通常很简单，保持原样
            # 可以在这里添加SPACE特定的优化逻辑

        return [line], 1

    def _compress_align_directive(self, line, lines, start_index):
        """压缩ALIGN指令"""
        match = self.data_patterns["align"].search(line.strip())
        if match:
            _ = match.group(1)  # 使用_接收，表示已知此值但暂不使用

            # 尝试查找前一行是否为数据定义
            if start_index > 0:
                prev_line = lines[start_index - 1].strip()
                for pattern_name, pattern in self.data_patterns.items():
                    if pattern_name != "align" and pattern.search(prev_line):
                        # 前一行是数据定义，此ALIGN已在其他地方处理
                        if self.compression_level >= 2:
                            return [], 1  # 跳过这个ALIGN

        # 默认情况保持ALIGN指令
        return [line], 1

    def _compress_repeated_op(self, line, lines, start_index):
        """压缩重复操作符"""
        match = self.data_patterns["repeated"].search(line.strip())
        if match:
            count = int(match.group(1))

            # 检测连续的重复操作
            if self.compression_level >= 2:
                repeated_lines = [line]
                current_index = start_index + 1
                total_count = count

                while current_index < len(lines):
                    next_line = lines[current_index].strip()
                    next_match = self.data_patterns["repeated"].search(next_line)
                    if next_match:
                        next_count = int(next_match.group(1))
                        total_count += next_count
                        repeated_lines.append(lines[current_index])
                        current_index += 1
                    else:
                        break

                if len(repeated_lines) > 1:
                    # 合并连续的重复操作
                    self.stats["compressed_spaces"] += len(repeated_lines) - 1
                    if self.compression_level >= 3:
                        # 最小化表示
                        return [f"% {total_count} ; combined {len(repeated_lines)} ops"], current_index - start_index
                    else:
                        # 标准压缩
                        return (
                            [
                                f"% {total_count} ; combined from {len(repeated_lines)} repetition ops"
                            ],
                            current_index - start_index,
                        )

        # 默认情况
        return [line], 1

    def _simplify_comment(self, comment):
        """简化注释内容"""
        if not comment:
            return ""

        comment = comment.strip()

        # 删除常见的冗余注释部分
        if self.compression_level >= 3:
            # 极端简化
            if "Literal Pool" in comment:
                return "LPool"
            elif "Jump Table" in comment:
                return "JTable"
            elif "offset" in comment.lower() and any(c.isdigit() for c in comment):
                # 提取偏移量
                offset_match = re.search(r"offset\s+(\w+)", comment, re.IGNORECASE)
                if offset_match:
                    return f"off_{offset_match.group(1)}"
            elif len(comment) > 40:
                # 截断过长注释
                return comment[:37] + "..."

        return comment


class StructCompressor:
    """结构体压缩器 - 优化结构体定义"""

    def __init__(self, compression_level=2):
        self.compression_level = compression_level
        self.struct_patterns = {"begin": RE_STRUCT_BEGIN, "end": RE_STRUCT_END, "field": RE_STRUCT_FIELD}
        self.stats = {"total_structs": 0, "compressed_structs": 0, "removed_struct_comments": 0}

    def compress(self, asm_content):
        """压缩ASM内容中的结构体定义"""
        lines = asm_content.split("\n")
        result = []

        # 重置统计
        self.stats = {"total_structs": 0, "compressed_structs": 0, "removed_struct_comments": 0}

        i = 0
        while i < len(lines):
            begin_match = self.struct_patterns["begin"].match(lines[i].strip())

            if begin_match:
                # 找到结构体定义开始
                struct_name = begin_match.group(1)
                struct_lines = [lines[i]]
                i += 1

                # 收集整个结构体定义
                while i < len(lines) and not self.struct_patterns["end"].match(lines[i].strip()):
                    struct_lines.append(lines[i])
                    i += 1

                if i < len(lines):  # 添加结构体结束行
                    struct_lines.append(lines[i])
                    i += 1

                # 压缩结构体定义
                self.stats["total_structs"] += 1
                compressed_struct = self._compress_struct_definition(struct_name, struct_lines)
                result.extend(compressed_struct)

                if len(compressed_struct) < len(struct_lines):
                    self.stats["compressed_structs"] += 1
                    self.stats["removed_struct_comments"] += len(struct_lines) - len(compressed_struct)
            else:
                result.append(lines[i])
                i += 1

        return "\n".join(result)

    def _compress_struct_definition(self, struct_name, struct_lines):
        """压缩结构体定义"""
        # 检查是否为ELF结构体
        is_elf = is_elf_struct(struct_name)

        # 根据压缩级别选择压缩策略
        if is_elf and self.compression_level >= 2:
            # ELF结构体使用更激进的压缩
            return self._apply_heavy_compression(struct_lines)
        elif self.compression_level == 1:
            # 轻度压缩：仅删除非必要空行和简化注释
            return self._apply_light_compression(struct_lines)
        elif self.compression_level == 2:
            # 中度压缩：简化字段表示，合并相似注释
            return self._apply_medium_compression(struct_lines)
        else:
            # 高度压缩：最小化表示，合并字段
            return self._apply_heavy_compression(struct_lines)

    def _apply_light_compression(self, struct_lines):
        """轻度压缩结构体"""
        result = []
        for line in struct_lines:
            if line.strip():  # 跳过空行
                if line.strip().startswith(";"):
                    # 简化注释
                    comment = line.strip()
                    if "XREF:" in comment:
                        # 保留XREF但简化
                        result.append(self._simplify_xref_comment(comment))
                    elif any(marker in comment for marker in ["field at", "size", "align"]):
                        # 保留结构信息注释
                        result.append(comment)
                    else:
                        # 其他注释保留
                        result.append(comment)
                else:
                    # 保留非注释行
                    result.append(line.strip())
        return result

    def _apply_medium_compression(self, struct_lines):
        """中度压缩结构体"""
        result = []
        xrefs = []
        fields = []

        # 提取结构体开始和结束行
        struct_begin = struct_lines[0].strip()
        struct_end = struct_lines[-1].strip() if struct_lines else ""

        # 收集XREF和字段
        for line in struct_lines[1:-1]:
            line_strip = line.strip()
            if line_strip.startswith(";"):
                if "XREF:" in line_strip:
                    xref_match = re.search(r"; (CODE|DATA) XREF: (.+)", line_strip)
                    if xref_match:
                        xref_type, refs = xref_match.groups()
                        xrefs.append((xref_type, refs))
                elif any(marker in line_strip for marker in ["field at", "size", "align"]):
                    # 保留重要结构信息，但不单独处理
                    pass
            elif line_strip:
                # 处理字段行
                field_match = self.struct_patterns["field"].match(line_strip)
                if field_match:
                    field_name, field_type = field_match.groups()
                    # 提取可能的注释
                    field_comment = ""
                    if ";" in line_strip:
                        parts = line_strip.split(";", 1)
                        field_comment = parts[1].strip()
                    fields.append((field_name, field_type, field_comment))

        # 添加结构体开始
        result.append(struct_begin)

        # 添加合并的XREF
        if xrefs:
            code_xrefs = []
            data_xrefs = []
            for xtype, refs in xrefs:
                if xtype == "CODE":
                    code_xrefs.extend(refs.split(";"))
                else:
                    data_xrefs.extend(refs.split(";"))

            if code_xrefs:
                result.append(f"    ; CODE XREF: {'; '.join(ref.strip() for ref in code_xrefs)}")
            if data_xrefs:
                result.append(f"    ; DATA XREF: {'; '.join(ref.strip() for ref in data_xrefs)}")

        # 添加字段
        for field_name, field_type, field_comment in fields:
            field_line = f"    {field_name} {field_type}"
            if field_comment:
                # 简化字段注释
                simplified_comment = self._simplify_field_comment(field_comment)
                if simplified_comment:
                    field_line += f" ; {simplified_comment}"
            result.append(field_line)

        # 添加结构体结束
        result.append(struct_end)

        return result

    def _apply_heavy_compression(self, struct_lines):
        """重度压缩结构体"""
        result = []
        field_count = 0

        # 提取结构体开始和结束行
        struct_begin = struct_lines[0].strip()
        struct_end = struct_lines[-1].strip() if struct_lines else ""

        # 添加结构体开始
        result.append(struct_begin)

        # 合并所有XREF为一行
        xrefs = self._extract_xrefs(struct_lines)
        if xrefs:
            result.append(f"    ; Combined XREFs: {xrefs}")

        # 压缩处理字段
        fields = self._extract_fields(struct_lines)
        for field_name, field_type, field_comment in fields:
            field_count += 1
            field_line = f"    {field_name} {field_type}"

            # 只保留最关键的注释
            if self.compression_level < 3 and field_comment:
                essential_comment = self._extract_essential_comment(field_comment)
                if essential_comment:
                    field_line += f" ; {essential_comment}"

            result.append(field_line)

        # 添加字段计数注释
        if field_count > 0 and self.compression_level >= 3:
            result.append(f"    ; {field_count} fields total")

        # 添加结构体结束
        result.append(struct_end)

        return result

    def _simplify_xref_comment(self, comment):
        """简化XREF注释"""
        # 提取XREF类型和引用
        xref_match = re.search(r"; (CODE|DATA) XREF: (.+)", comment)
        if xref_match:
            xref_type, refs = xref_match.groups()
            # 简化引用列表
            simplified_refs = []
            for ref in refs.split(";"):
                ref = ref.strip()
                if "/" in ref:
                    parts = ref.split("/", 1)
                    source = parts[0].strip()
                    # 删除上下箭头
                    source = re.sub(r"[↑↓]\s*", "", source)
                    simplified_refs.append(source)
                else:
                    simplified_refs.append(ref)

            return f"; {xref_type} XREF: {'; '.join(simplified_refs)}"
        return comment

    def _simplify_field_comment(self, comment):
        """简化字段注释"""
        if not comment:
            return ""

        # 提取最重要的信息
        if "offset" in comment.lower():
            # 提取偏移信息
            offset_match = re.search(r"offset\s+(\w+)", comment, re.IGNORECASE)
            if offset_match:
                return f"offset {offset_match.group(1)}"
        elif "field at" in comment:
            # 提取字段位置
            field_match = re.search(r"field at (\w+)", comment)
            if field_match:
                return f"at {field_match.group(1)}"
        elif len(comment) > 40 and self.compression_level >= 2:
            # 截断过长注释
            return comment[:37] + "..."

        return comment

    def _extract_xrefs(self, struct_lines):
        """从结构体定义中提取所有XREF"""
        xref_sources = []

        for line in struct_lines:
            if "; CODE XREF:" in line or "; DATA XREF:" in line:
                xref_match = re.search(r"; (CODE|DATA) XREF: (.+)", line.strip())
                if xref_match:
                    refs = xref_match.group(2)
                    for ref in refs.split(";"):
                        ref = ref.strip()
                        if "/" in ref:
                            source = ref.split("/", 1)[0].strip()
                            source = re.sub(r"[↑↓]\s*", "", source)
                            xref_sources.append(source)

        # 删除重复项并限制长度
        unique_sources = list(dict.fromkeys(xref_sources))  # 保持顺序的去重

        if len(unique_sources) > 5 and self.compression_level >= 3:
            # 限制XREF数量
            return f"{', '.join(unique_sources[:5])}, +{len(unique_sources) - 5} more"
        else:
            return ", ".join(unique_sources)

    def _extract_fields(self, struct_lines):
        """从结构体定义中提取所有字段"""
        fields = []

        for line in struct_lines:
            line_strip = line.strip()
            field_match = self.struct_patterns["field"].match(line_strip)
            if field_match:
                field_name, field_type = field_match.groups()
                # 提取可能的注释
                field_comment = ""
                if ";" in line_strip:
                    parts = line_strip.split(";", 1)
                    field_comment = parts[1].strip()
                fields.append((field_name, field_type, field_comment))

        return fields

    def _extract_essential_comment(self, comment):
        """提取注释中的核心信息"""
        if not comment:
            return ""

        # 关键词列表，按优先级排序
        keywords = [
            ("offset", r"offset\s+(\w+)"),
            ("field at", r"field at (\w+)"),
            ("size", r"size (\w+)"),
            ("align", r"align (\w+)"),
            ("type", r"type (\w+)"),
        ]

        # 尝试提取关键信息
        for keyword, pattern in keywords:
            if keyword in comment.lower():
                match = re.search(pattern, comment, re.IGNORECASE)
                if match:
                    return f"{keyword} {match.group(1)}"

        # 如果没有关键词，但注释很短，保留原样
        if len(comment) <= 20:
            return comment

        # 否则截断长注释
        if len(comment) > 40:
            return comment[:37] + "..."

        return comment


class ReadabilityBalancer:
    """可读性平衡器 - 在压缩和可读性之间找到平衡点"""

    def __init__(self, target_readability=0.6, target_compression=0.7):
        self.target_readability = target_readability  # 0.0-1.0
        self.target_compression = target_compression  # 0.0-1.0
        self.readability_metrics = self._init_metrics()
        self.stats = {"iterations": 0, "final_readability": 0.0, "final_compression": 0.0, "applied_compressors": []}

    def _init_metrics(self):
        """初始化可读性度量标准"""
        return {
            "function_boundary_clarity": 1.0,  # 函数边界清晰度
            "control_flow_clarity": 1.0,  # 控制流清晰度
            "critical_comment_presence": 1.0,  # 关键注释保留度
            "instruction_readability": 1.0,  # 指令可读性
            "identifier_preservation": 1.0,  # 标识符保留度
        }

    def balance_compression(self, original_content, compressors, config=None):
        """在压缩和可读性之间找到平衡点"""
        if config is None:
            config = {}

        # 从配置中获取目标值
        self.target_readability = config.get("target_readability", self.target_readability)
        self.target_compression = config.get("target_compression", self.target_compression)

        # 重置统计
        self.stats = {"iterations": 0, "final_readability": 0.0, "final_compression": 0.0, "applied_compressors": []}

        # 初始应用保守压缩
        current_content = original_content
        current_compression = 0.0
        current_readability = self._evaluate_readability(current_content)

        # 定义压缩器应用顺序 - 先应用保留可读性的
        compressor_order = [
            "format",  # 首先优化格式，影响最小
            "xref",  # 然后压缩XREF，这通常不影响代码理解
            "struct",  # 结构体压缩
            "data",  # 数据定义压缩
            "label",  # 标签优化
            "comment",  # 最后压缩注释，因为这影响最大
        ]

        # 应用迭代压缩策略
        for compressor_name in compressor_order:
            if compressor_name not in compressors:
                continue

            self.stats["iterations"] += 1

            # 测试当前压缩器
            test_content = compressors[compressor_name].compress(current_content)
            test_compression = calculate_compression_ratio(original_content, test_content)
            test_readability = self._evaluate_readability(test_content)

            # 决定是否应用此压缩器
            if self._is_acceptable_balance(test_compression, test_readability):
                current_content = test_content
                current_compression = test_compression
                current_readability = test_readability
                self.stats["applied_compressors"].append(compressor_name)
                # 记录详细统计
                self.stats[f"{compressor_name}_compression"] = current_compression
                self.stats[f"{compressor_name}_readability"] = current_readability
            else:
                # 跳过这个压缩器，会降低可读性过多
                self.stats[f"{compressor_name}_skipped"] = True

        # 记录最终结果
        self.stats["final_readability"] = current_readability
        self.stats["final_compression"] = current_compression

        return current_content

    def _evaluate_readability(self, content):
        """评估内容的可读性得分"""
        # 实现多维度可读性评估
        scores = {}

        # 评估函数边界清晰度
        scores["function_boundary_clarity"] = self._evaluate_function_boundaries(content)

        # 评估控制流清晰度
        scores["control_flow_clarity"] = self._evaluate_control_flow(content)

        # 评估关键注释保留
        scores["critical_comment_presence"] = self._evaluate_critical_comments(content)

        # 评估指令可读性
        scores["instruction_readability"] = self._evaluate_instruction_readability(content)

        # 评估标识符保留
        scores["identifier_preservation"] = self._evaluate_identifier_preservation(content)

        # 计算加权平均分
        weights = {
            "function_boundary_clarity": 0.25,
            "control_flow_clarity": 0.25,
            "critical_comment_presence": 0.2,
            "instruction_readability": 0.2,
            "identifier_preservation": 0.1,
        }

        self.readability_metrics = scores
        weighted_score = sum(scores[metric] * weights[metric] for metric in scores)
        return weighted_score

    def _is_acceptable_balance(self, compression, readability):
        """判断当前压缩率和可读性是否可接受"""
        if readability < self.target_readability:
            return False
        if compression < self.target_compression and readability > self.target_readability + 0.1:
            # 可读性有余量，可以牺牲一些换取更好的压缩
            return True
        return compression >= self.target_compression or readability >= self.target_readability

    # 可读性评估函数
    def _evaluate_function_boundaries(self, content):
        """评估函数边界清晰度"""
        # 检查函数边界标记保留情况
        lines = content.split("\n")

        function_markers = 0
        for line in lines:
            if RE_SUBROUTINE.match(line) or "; End of function" in line:
                function_markers += 1

        # 估算函数数量
        estimated_functions = sum(1 for line in lines if RE_SUBROUTINE.match(line))
        if estimated_functions == 0:
            estimated_functions = 1  # 避免除零

        # 计算边界标记对数量
        expected_markers = estimated_functions * 2  # 每个函数应有开始和结束标记

        # 计算保留率
        retention_rate = min(1.0, function_markers / expected_markers)

        # 根据保留率评分
        if retention_rate >= 0.9:
            return 0.95  # 几乎所有函数边界都保留
        elif retention_rate >= 0.7:
            return 0.8  # 大多数函数边界保留
        elif retention_rate >= 0.5:
            return 0.6  # 一半以上函数边界保留
        else:
            return 0.4  # 函数边界保留不足

    def _evaluate_control_flow(self, content):
        """评估控制流清晰度"""
        lines = content.split("\n")

        # 检查跳转指令格式
        jumps_total = 0
        well_formatted_jumps = 0

        for line in lines:
            line_strip = line.strip()
            if not line_strip.startswith(";") and any(line_strip.upper().startswith(op) for op in JUMP_OPCODES):
                jumps_total += 1
                # 检查格式是否清晰
                if "  " in line or self._is_well_formatted_jump(line):
                    well_formatted_jumps += 1

        # 计算良好格式的跳转比例
        jump_format_score = 1.0 if jumps_total == 0 else min(1.0, well_formatted_jumps / jumps_total)

        # 检查标签保留情况
        label_score = self._evaluate_label_preservation(content)

        # 组合得分
        return 0.6 * jump_format_score + 0.4 * label_score

    def _is_well_formatted_jump(self, jump_line):
        """检查跳转指令格式是否清晰"""
        # 检查指令和目标之间是否有足够空白
        parts = jump_line.split()
        if len(parts) < 2:
            return False

        # 检查目标标签是否清晰
        target = parts[-1].rstrip(",;")
        if target.startswith("loc_") or target.startswith("sub_"):
            return True

        return False

    def _evaluate_label_preservation(self, content):
        """评估标签保留情况"""
        lines = content.split("\n")

        # 计算标签数量
        labels = sum(1 for line in lines if ":" in line and not line.strip().startswith(";"))

        # 计算被注释掉的标签
        commented_labels = sum(1 for line in lines if line.strip().startswith("; REMOVED:") and ":" in line)

        # 评估标签保留率
        total_labels = labels + commented_labels
        if total_labels == 0:
            return 1.0  # 没有标签

        retention_rate = labels / total_labels

        # 根据保留率评分
        if retention_rate >= 0.9:
            return 0.95
        elif retention_rate >= 0.7:
            return 0.8
        elif retention_rate >= 0.5:
            return 0.6
        else:
            return 0.4

    def _evaluate_critical_comments(self, content):
        """评估关键注释保留"""
        lines = content.split("\n")

        # 计算关键注释
        critical_markers = KEEP_COMMENT_MARKERS.union({"SUBROUTINE", "End of function"})

        critical_comments = 0
        for line in lines:
            if line.strip().startswith(";") and any(marker in line for marker in critical_markers):
                critical_comments += 1

        # 估算应有的关键注释数
        functions = sum(1 for line in lines if RE_SUBROUTINE.match(line))
        estimated_critical = functions * 3  # 每个函数至少应有开始、结束和一些XREF

        if estimated_critical < 1:
            estimated_critical = 1  # 避免除零

        # 计算保留率
        retention_rate = min(1.0, critical_comments / estimated_critical)

        # 根据保留率评分
        if retention_rate >= 0.9:
            return 0.95
        elif retention_rate >= 0.7:
            return 0.8
        elif retention_rate >= 0.5:
            return 0.6
        else:
            return 0.4

    def _evaluate_instruction_readability(self, content):
        """评估指令可读性"""
        lines = content.split("\n")

        # 计算指令行数量
        instruction_lines = 0
        well_formatted_instructions = 0

        for line in lines:
            line_strip = line.strip()
            if not line_strip.startswith(";") and " " in line_strip and ":" not in line_strip.split()[0]:
                # 可能是指令行
                instruction_lines += 1

                # 检查格式是否清晰
                if "  " in line or self._is_well_formatted_instruction(line):
                    well_formatted_instructions += 1

        # 计算良好格式的指令比例
        if instruction_lines == 0:
            return 1.0  # 没有指令行

        format_score = min(1.0, well_formatted_instructions / instruction_lines)

        # 根据格式评分
        if format_score >= 0.9:
            return 0.95
        elif format_score >= 0.7:
            return 0.8
        elif format_score >= 0.5:
            return 0.6
        else:
            return 0.4

    def _is_well_formatted_instruction(self, instruction_line):
        """检查指令格式是否清晰"""
        parts = instruction_line.split(None, 1)
        if len(parts) < 2:
            return False

        # 检查是否有对齐
        opcode, operands = parts
        if len(opcode) + 2 < len(instruction_line.split(operands)[0]):
            return True  # 有对齐空间

        return False

    def _evaluate_identifier_preservation(self, content):
        """评估标识符保留"""
        # 对于大多数情况，我们假设标识符保留良好
        # 在更复杂的实现中，可以检查函数名、变量名等
        return 0.85  # 默认较高得分
