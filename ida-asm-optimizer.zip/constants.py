#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
IDA反汇编.asm文件智能优化工具 - 常量模块
包含所有常量定义、配置变量和正则表达式
"""

import re

# ===== 常量定义 =====

# 设备特定优化常量
THREAD_COUNT = 4
MEM_CHUNK = 1024 * 1024  # 1MB
BATTERY_SAVE = True

# ARM架构指令集定义
ARM_INSTRUCTION_SETS = {
    "thumb": {
        "opcodes": {"B", "BL", "BLX", "MOV", "ADD", "SUB", "LDR", "STR", "PUSH", "POP", "IT"},
        "suffixes": {".W", ".N", "EQ", "NE", "GT", "LT", "GE", "LE", "CS", "CC", "MI", "PL", "VS", "VC", "HI", "LS"},
        "condition_codes": {"EQ", "NE", "CS", "CC", "MI", "PL", "VS", "VC", "HI", "LS", "GE", "LT", "GT", "LE"},
    },
    "arm": {
        "opcodes": {"B", "BL", "BLX", "MOV", "ADD", "SUB", "LDR", "STR", "LDM", "STM", "PUSH", "POP"},
        "suffixes": {"IA", "IB", "DA", "DB", "FD", "ED", "FA", "EA"},
        "condition_codes": {"EQ", "NE", "CS", "CC", "MI", "PL", "VS", "VC", "HI", "LS", "GE", "LT", "GT", "LE"},
    },
}

# 优化预设配置
OPTIMIZATION_PRESETS = {
    "light": {
        "level": 1,
        "comment_preservation": 0.9,
        "alignment": 12,
        "preserve_structure": True,
        "preserve_jump_targets": True,
        "compress_locals": False,
        "xref_compression": 1,
        "data_compression": 1,
        "struct_compression": 1,
        "target_readability": 0.9,
        "target_compression": 0.3,
        "desc": "轻度优化，最大程度保持可读性",
    },
    "balanced": {
        "level": 2,
        "comment_preservation": 0.6,
        "alignment": 8,
        "preserve_structure": True,
        "preserve_jump_targets": True,
        "compress_locals": True,
        "xref_compression": 2,
        "data_compression": 2,
        "struct_compression": 2,
        "target_readability": 0.7,
        "target_compression": 0.6,
        "desc": "平衡优化，兼顾压缩率和可读性",
    },
    "extreme": {
        "level": 3,
        "comment_preservation": 0.3,
        "alignment": 0,
        "preserve_structure": False,
        "preserve_jump_targets": True,
        "compress_locals": True,
        "xref_compression": 3,
        "data_compression": 3,
        "struct_compression": 3,
        "target_readability": 0.5,
        "target_compression": 0.8,
        "desc": "极致优化，最大化减小文件大小",
    },
    "elf": {
        "level": 3,
        "comment_preservation": 0.3,
        "alignment": 0,
        "preserve_structure": False,
        "preserve_jump_targets": True,
        "compress_locals": True,
        "xref_compression": 3,
        "data_compression": 3,
        "struct_compression": 3,
        "target_readability": 0.5,
        "target_compression": 0.8,
        "desc": "专用于ELF文件的极致优化",
    },
    "cpp": {
        "level": 3,
        "comment_preservation": 0.4,
        "alignment": 4,
        "preserve_structure": False,
        "preserve_jump_targets": True,
        "compress_locals": True,
        "xref_compression": 3,
        "data_compression": 2,
        "struct_compression": 3,
        "target_readability": 0.6,
        "target_compression": 0.7,
        "desc": "专用于C++文件的优化",
    },
}

# 指令类型集合
JUMP_OPCODES = {"B", "BEQ", "BNE", "BLT", "BGT", "BLE", "BGE", "BCS", "BCC", "BMI", "BPL", "BVS", "BVC", "BHI", "BLS"}
CALL_OPCODES = {"BL", "BLX"}
DATA_OPCODES = {"DCB", "DCW", "DCD", "DCDU", "DCDO", "DCQ", "SPACE", "%"}
MEM_OPCODES = {"LDR", "STR", "LDM", "STM", "PUSH", "POP", "LDMFD", "STMFD"}
KEEP_COMMENT_MARKERS = {"CODE XREF", "DATA XREF", "starts at", "End of function"}

# ELF特定结构体
ELF_STRUCTS = {"Elf32_Sym", "Elf32_Rel", "Elf32_Dyn", "Elf32_Ehdr", "Elf32_Phdr", "Elf32_Shdr"}

# ===== 正则表达式编译 =====

# 核心结构正则
RE_SUBROUTINE = re.compile(r"; ={10,} S U B R O U T I N E ={10,}")
RE_VARIABLE = re.compile(r"[a-zA-Z0-9_]+\s+=\s+")
RE_LOCATION = re.compile(r"loc_[0-9A-Fa-f]+\s*:")
RE_SEPARATOR = re.compile(r"; -+")
RE_FUNC_ADDR = re.compile(r"starts at ([0-9A-Fa-f]+)")

# 结构体相关正则
RE_STRUCT_BEGIN = re.compile(r"([a-zA-Z0-9_]+)\s+struc\s*;?")
RE_STRUCT_END = re.compile(r"([a-zA-Z0-9_]+)\s+ends\s*;?")
RE_STRUCT_FIELD = re.compile(r"\s+([a-zA-Z0-9_]+)\s+(DCB|DCW|DCD|DCDU|DCDO|DCQ|%|<)\s+")

# 引用相关正则
RE_DATA_XREF = re.compile(r"; DATA XREF: (.+)")
RE_CODE_XREF = re.compile(r"; CODE XREF: (.+)")
RE_XREF_PATTERN = re.compile(r"([^/]+)/([^/\s:]+)")

# 段和指令正则
RE_AREA_DIRECTIVE = re.compile(r"\s*AREA\s+([a-zA-Z0-9_]+),\s*([a-zA-Z0-9_,\s]+)")
RE_CODE_DIRECTIVE = re.compile(r"\s*CODE(16|32)")
RE_ELF_SIGNATURE = re.compile(r"DCD 0x464C457F\s+; .*File format: \\x7FELF")

# 数据定义正则
RE_STRING_DCB = re.compile(r'([a-zA-Z0-9_]+)\s+DCB\s+"([^"]+)",0\s*;?(.+)?')
RE_ALIGN_DIRECTIVE = re.compile(r"\s*ALIGN\s+(.+)")
RE_REPEATED_OP = re.compile(r"\s*%\s+(\d+)\s*")

# 导入和虚函数表正则
RE_IMPORT_STATEMENT = re.compile(r"\s*IMPORT\s+(__imp_\w+)\s*;?(.+)?")
RE_VTABLE_ENTRY = re.compile(r"\s+DCD\s+([^;]+)\s*;\s*(.+)")
RE_CPP_MANGLED = re.compile(r"_Z[A-Za-z0-9_]+")
