#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
IDA反汇编.asm文件智能优化工具 v4.0
主程序入口和工具函数
"""

import os
import re
import sys
import time
import glob
import argparse
import subprocess

from constants import OPTIMIZATION_PRESETS, BATTERY_SAVE, RE_ELF_SIGNATURE
from core import AsmOptimizerCore, format_size, create_directory_if_not_exists
from cli import AsmOptimizerCLI


def direct_file_optimize(input_path, output_path=None, preset="balanced"):
    """直接优化单个文件 - 命令行模式"""
    if not os.path.exists(input_path):
        print(f"错误: 文件'{input_path}'不存在")
        return False

    if not output_path:
        output_path = f"{os.path.splitext(input_path)[0]}_optimized.asm"

    print(f"正在优化: {input_path}")
    print(f"输出到: {output_path}")
    print(f"使用预设: {preset}")

    # 选择配置
    if preset in OPTIMIZATION_PRESETS:
        config = OPTIMIZATION_PRESETS[preset].copy()
    else:
        print(f"预设'{preset}'不存在，使用'balanced'预设")
        config = OPTIMIZATION_PRESETS["balanced"].copy()

    optimizer = AsmOptimizerCore(preset, config)
    result = optimizer.optimize_file(input_path, output_path)

    if "error" in result:
        print(f"出错: {result['error']}")
        return False

    print("优化完成!")
    print(f"原始大小: {format_size(result['original_size'])}")
    print(f"优化后大小: {format_size(result['optimized_size'])}")
    print(f"减小比例: {result['reduction_percent']:.2f}%")
    return True


def batch_optimize(input_dir, output_dir=None, preset="balanced", recursive=False, smart_preset=True):
    """批量优化目录中的.asm文件并返回统计结果"""
    if not os.path.exists(input_dir) or not os.path.isdir(input_dir):
        print(f"错误: 目录'{input_dir}'不存在")
        return None

    if not output_dir:
        output_dir = f"{input_dir}_optimized"

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    print(f"处理目录: {input_dir}")
    print(f"输出到: {output_dir}")
    print(f"使用预设: {preset}")

    stats = {
        "files_processed": 0,
        "total_original_size": 0,
        "total_optimized_size": 0,
        "total_reduction": 0.0,
        "elf_files": 0,
        "cpp_files": 0,
        "file_details": [],
    }

    pattern = os.path.join(input_dir, "**" if recursive else "", "*.asm")
    for file_path in glob.glob(pattern, recursive=recursive):
        rel_path = os.path.relpath(file_path, input_dir)
        output_path = os.path.join(output_dir, rel_path)
        output_subdir = os.path.dirname(output_path)

        if not os.path.exists(output_subdir):
            os.makedirs(output_subdir)

        print(f"处理: {rel_path}")

        current_preset = preset

        # 自动选择最佳预设
        if smart_preset:
            try:
                with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                    header = f.read(4096)
                    if RE_ELF_SIGNATURE.search(header):
                        current_preset = "elf"
                        print("  检测到ELF文件，使用'elf'预设")
                        stats["elf_files"] += 1
                    elif "::" in header or "_ZN" in header:
                        current_preset = "cpp"
                        print("  检测到C++文件，使用'cpp'预设")
                        stats["cpp_files"] += 1
            except Exception:
                # 文件读取错误，使用默认预设
                pass

        # 优化文件
        optimizer = AsmOptimizerCore(current_preset)
        result = optimizer.optimize_file(file_path, output_path)

        if "error" not in result:
            stats["files_processed"] += 1
            stats["total_original_size"] += result["original_size"]
            stats["total_optimized_size"] += result["optimized_size"]
            stats["total_reduction"] += result["reduction_percent"]

            # 记录详细信息
            stats["file_details"].append(
                {
                    "path": rel_path,
                    "original_size": result["original_size"],
                    "optimized_size": result["optimized_size"],
                    "reduction": result["reduction_percent"],
                    "preset_used": current_preset,
                }
            )

            print(f"  减小: {result['reduction_percent']:.2f}%")

    # 计算平均减小比例
    if stats["files_processed"] > 0:
        stats["avg_reduction"] = stats["total_reduction"] / stats["files_processed"]
    else:
        stats["avg_reduction"] = 0.0

    # 显示总结
    if stats["files_processed"] > 0:
        print(f"\n已处理 {stats['files_processed']} 个文件")
        print(f"平均减小比例: {stats['avg_reduction']:.2f}%")
        print(f"总原始大小: {format_size(stats['total_original_size'])}")
        print(f"总优化大小: {format_size(stats['total_optimized_size'])}")
        saved_size = stats["total_original_size"] - stats["total_optimized_size"]
        print(f"总节省: {format_size(saved_size)}")
    else:
        print("没有找到要处理的.asm文件")

    return stats


def clipboard_optimize_cmd():
    """从剪贴板优化汇编代码并返回结果 - 命令行模式"""
    try:
        # 使用timeout避免hang
        process = subprocess.Popen(["termux-clipboard-get"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, stderr = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            print("获取剪贴板超时")
            return None

        if process.returncode != 0:
            error = stderr.decode("utf-8")
            if "command not found" in error:
                print("错误: 找不到termux-api命令")
                print("请执行: pkg install termux-api")
            else:
                print(f"获取剪贴板内容错误: {error}")
            return None

        content = stdout.decode("utf-8", errors="replace")
        if not content.strip():
            print("剪贴板为空")
            return None

        print("正在优化...")

        # 使用默认平衡设置
        optimizer = AsmOptimizerCore()
        result = optimizer.optimize_content(content)

        # 检查是否效果不明显，尝试更激进的优化
        if result["reduction_percent"] < 15:
            print("优化效果不明显，尝试更激进的优化...")
            optimizer = AsmOptimizerCore("extreme")
            result = optimizer.optimize_content(content)

        # 写回剪贴板
        process = subprocess.Popen(["termux-clipboard-set"], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            process.communicate(input=result["optimized_content"].encode("utf-8"), timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            print("设置剪贴板超时")
            return None

        if process.returncode != 0:
            print(f"设置剪贴板内容错误: {stderr.decode('utf-8')}")
            return None

        print(f"原始大小: {format_size(result['original_size'])}")
        print(f"优化后大小: {format_size(result['optimized_size'])}")
        print(f"减小比例: {result['reduction_percent']:.2f}%")
        print(f"检测架构: {result['stats'].get('detected_arch', 'unknown')}")
        print("\n优化后的汇编代码已复制到剪贴板")

        return result

    except Exception as e:
        print(f"错误: {str(e)}")
        print("注意: 此功能需要安装termux-api软件包")
        return None


def generate_report(stats, input_dir, output_dir):
    """生成批量处理的详细报告"""
    if not stats or stats["files_processed"] == 0:
        return "没有处理文件，无法生成报告"

    report = []
    report.append("=" * 60)
    report.append("IDA汇编优化器批处理报告")
    report.append("=" * 60)
    report.append("")

    report.append(f"输入目录: {input_dir}")
    report.append(f"输出目录: {output_dir}")
    report.append(f"处理时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("")

    report.append(f"处理文件总数: {stats['files_processed']}")
    report.append(f"总原始大小: {format_size(stats['total_original_size'])}")
    report.append(f"总优化大小: {format_size(stats['total_optimized_size'])}")

    saved = stats["total_original_size"] - stats["total_optimized_size"]
    saved_percent = (saved / stats["total_original_size"]) * 100 if stats["total_original_size"] > 0 else 0
    report.append(f"总节省: {format_size(saved)} ({saved_percent:.2f}%)")
    report.append("")

    report.append(f"ELF文件数量: {stats.get('elf_files', 0)}")
    report.append(f"C++文件数量: {stats.get('cpp_files', 0)}")
    report.append("")

    # 统计性能指标
    if stats["file_details"]:
        reductions = [f["reduction"] for f in stats["file_details"]]
        reductions.sort()

        min_reduction = min(reductions)
        max_reduction = max(reductions)
        median = reductions[len(reductions) // 2]
        avg = sum(reductions) / len(reductions)

        report.append("优化性能分析:")
        report.append(f"  最小减小率: {min_reduction:.2f}%")
        report.append(f"  最大减小率: {max_reduction:.2f}%")
        report.append(f"  中位数减小率: {median:.2f}%")
        report.append(f"  平均减小率: {avg:.2f}%")
        report.append("")

    # 详细文件列表
    report.append("处理文件详情:")
    report.append("-" * 60)
    report.append(f"{'文件路径':<30} | {'原始大小':<10} | {'优化大小':<10} | {'减小率':<8} | {'使用预设':<8}")
    report.append("-" * 60)

    for file_info in stats["file_details"]:
        path = file_info["path"]
        # 截断过长的路径
        if len(path) > 30:
            path = "..." + path[-27:]

        report.append(
            f"{path:<30} | {format_size(file_info['original_size']):<10} | "
            f"{format_size(file_info['optimized_size']):<10} | "
            f"{file_info['reduction']:.2f}% | {file_info.get('preset_used', 'balanced'):<8}"
        )

    report.append("-" * 60)
    return "\n".join(report)


def main():
    """主函数 - 处理命令行参数和执行程序"""
    # 创建命令行参数解析器
    parser = argparse.ArgumentParser(
        description="IDA反汇编.asm文件智能优化工具 v4.0 - 最大化减小ASM文件大小同时保持必要可读性"
    )

    # 添加子命令
    subparsers = parser.add_subparsers(dest="command", help="命令")

    # 优化单个文件命令
    optimize_parser = subparsers.add_parser("optimize", help="优化单个.asm文件")
    optimize_parser.add_argument("input", help="输入.asm文件路径")
    optimize_parser.add_argument("-o", "--output", help="输出文件路径 [默认: <输入文件名>_optimized.asm]")
    optimize_parser.add_argument(
        "-p",
        "--preset",
        default="balanced",
        choices=["light", "balanced", "extreme", "elf", "cpp"],
        help="优化预设 [默认: balanced]",
    )

    # 优化目录命令
    dir_parser = subparsers.add_parser("directory", help="优化目录中所有.asm文件")
    dir_parser.add_argument("input_dir", help="输入目录路径")
    dir_parser.add_argument("-o", "--output_dir", help="输出目录路径 [默认: <输入目录>_optimized]")
    dir_parser.add_argument(
        "-p",
        "--preset",
        default="balanced",
        choices=["light", "balanced", "extreme", "elf", "cpp"],
        help="优化预设 [默认: balanced]",
    )
    dir_parser.add_argument("-r", "--recursive", action="store_true", help="递归处理子目录")
    dir_parser.add_argument("-s", "--smart", action="store_true", help="智能选择最佳预设")

    # 剪贴板优化命令
    clipboard_parser = subparsers.add_parser("clipboard", help="从剪贴板优化汇编代码")
    clipboard_parser.add_argument(
        "-p",
        "--preset",
        default="balanced",
        choices=["light", "balanced", "extreme", "elf", "cpp"],
        help="优化预设 [默认: balanced]",
    )
    clipboard_parser.add_argument("-o", "--output", help="同时保存到文件 [可选]")

    # 分析命令
    analyze_parser = subparsers.add_parser("analyze", help="分析.asm文件结构")
    analyze_parser.add_argument("input", help="输入.asm文件路径")

    # 交互模式命令
    subparsers.add_parser("interactive", help="启动交互式界面")

    # 解析命令行参数
    args = parser.parse_args()

    # 没有命令时显示帮助
    if not args.command:
        # 检查是否为直接拖放文件
        if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]) and sys.argv[1].endswith(".asm"):
            print(f"检测到拖放的.asm文件，自动优化: {sys.argv[1]}")
            direct_file_optimize(sys.argv[1])
            return

        # 否则显示交互式界面
        cli = AsmOptimizerCLI()
        cli.interactive_menu()
        return

    # 执行相应命令
    if args.command == "optimize":
        direct_file_optimize(args.input, args.output, args.preset)

    elif args.command == "directory":
        output_dir = args.output_dir if args.output_dir else f"{args.input_dir}_optimized"
        batch_optimize(args.input_dir, output_dir, args.preset, args.recursive, args.smart)

    elif args.command == "clipboard":
        # 从剪贴板优化
        try:
            result = clipboard_optimize_cmd()

            # 如果指定了输出文件，保存结果
            if args.output and result and "optimized_content" in result:
                with open(args.output, "w", encoding="utf-8") as f:
                    f.write(result["optimized_content"])
                print(f"已保存到: {args.output}")
        except Exception as e:
            print(f"剪贴板优化失败: {str(e)}")

    elif args.command == "analyze":
        # 分析文件
        if not os.path.exists(args.input):
            print(f"错误: 文件'{args.input}'不存在")
            return

        print(f"正在分析文件: {args.input}")

        # 创建优化器来分析文件
        optimizer = AsmOptimizerCore()

        # 检测文件类型
        optimizer._detect_file_type(args.input)

        # 读取文件内容
        with open(args.input, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()

        # 分析文件特征
        from core import AdaptiveOptimizer
        adaptive_optimizer = AdaptiveOptimizer()
        features = adaptive_optimizer._analyze_file_features(content)

        # 显示分析报告
        print("\n┌──────────────────────────────────────┐")
        print("│             ASM文件分析报告            │")
        print("└──────────────────────────────────────┘\n")

        print(f"文件名: {os.path.basename(args.input)}")
        print(f"文件大小: {format_size(os.path.getsize(args.input))}")

        if optimizer.stats["is_elf_binary"]:
            print("\n文件类型: ELF二进制反汇编")
        elif features["has_cpp_features"]:
            print("\n文件类型: C++应用程序")
        else:
            print("\n文件类型: 普通汇编代码")

        print(f"\n指令集: {features['arch']}")
        print(f"代码复杂度: {features['complexity'] * 100:.1f}%")
        print(f"注释比例: {features['comment_ratio'] * 100:.1f}%")

        # 显示结构统计
        print(f"\n子例程数量: {features['function_count']}")
        print(f"结构体数量: {features['struct_count']}")
        print(f"段数量: {features['section_count']}")
        print(f"XREF数量: {features['xref_count']}")

        # 优化建议
        print("\n优化建议:")

        # 根据文件类型推荐预设
        if optimizer.stats["is_elf_binary"]:
            print("  - 推荐使用'elf'预设以获得最佳ELF优化")
        elif features["has_cpp_features"]:
            print("  - 推荐使用'cpp'预设以获得最佳C++优化")
        elif features["complexity"] > 0.7:
            print("  - 文件复杂度较高，推荐使用'balanced'预设保持代码可读性")
        elif features["comment_ratio"] > 0.4:
            print("  - 注释比例较高，推荐使用'extreme'预设以显著减小文件大小")

    elif args.command == "interactive":
        # 启动交互式界面
        cli = AsmOptimizerCLI()
        cli.interactive_menu()


if __name__ == "__main__":
    main()
