#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
IDA反汇编.asm文件智能优化工具 - 核心模块
包含核心优化逻辑和控制类
"""

import os
import time

from constants import (
    OPTIMIZATION_PRESETS,
    THREAD_COUNT,
    MEM_CHUNK,
    BATTERY_SAVE,
    RE_ELF_SIGNATURE,
    RE_CODE_DIRECTIVE,
)
from optimizers import (
    CommentCompressor,
    FormatOptimizer,
    LabelOptimizer,
    XrefCompressor,
    DataDefinitionCompressor,
    StructCompressor,
    ReadabilityBalancer,
    calculate_compression_ratio,
)


def format_size(size: int) -> str:
    """格式化大小显示"""
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.2f} KB"
    else:
        return f"{size / (1024 * 1024):.2f} MB"


def create_directory_if_not_exists(directory: str) -> None:
    """如果目录不存在，创建它"""
    if not os.path.exists(directory):
        os.makedirs(directory)


class AdaptiveOptimizer:
    """自适应优化控制器 - 智能选择最佳优化策略"""

    def __init__(self):
        # 初始化不同类型的压缩器
        self.compressors = {}
        self.readability_balancer = None
        self.stats = {"original_size": 0, "optimized_size": 0, "compression_ratio": 0.0, "file_features": {}}

    def initialize_compressors(self, config):
        """初始化压缩器组件"""
        # 创建压缩器
        self.compressors = {
            "comment": CommentCompressor(config.get("comment_preservation", 0.5)),
            "format": FormatOptimizer(config.get("alignment", 0), config.get("preserve_structure", True)),
            "label": LabelOptimizer(config.get("preserve_jump_targets", True), config.get("compress_locals", True)),
            "xref": XrefCompressor(config.get("xref_compression", 2)),
            "data": DataDefinitionCompressor(config.get("data_compression", 2)),
            "struct": StructCompressor(config.get("struct_compression", 2)),
        }

        # 创建可读性平衡器
        self.readability_balancer = ReadabilityBalancer(
            config.get("target_readability", 0.6), config.get("target_compression", 0.7)
        )

    def optimize(self, asm_content, target_profile=None):
        """应用自适应优化"""
        # 首先分析文件特征
        file_features = self._analyze_file_features(asm_content)
        self.stats["file_features"] = file_features
        self.stats["original_size"] = len(asm_content)

        # 选择或调整优化配置
        optimization_config = self._select_optimization_config(file_features, target_profile)

        # 配置压缩器
        self.initialize_compressors(optimization_config)

        # 应用压缩，平衡可读性
        result = self.readability_balancer.balance_compression(asm_content, self.compressors, optimization_config)

        # 更新统计信息
        self.stats["optimized_size"] = len(result)
        self.stats["compression_ratio"] = calculate_compression_ratio(asm_content, result)
        self.stats["readability_score"] = self.readability_balancer.stats["final_readability"]
        self.stats["applied_compressors"] = self.readability_balancer.stats["applied_compressors"]

        # 收集各压缩器的统计信息
        for compressor_name, compressor in self.compressors.items():
            if hasattr(compressor, "stats"):
                self.stats[f"{compressor_name}_stats"] = compressor.stats

        return {"optimized_content": result, "stats": self.stats}

    def _analyze_file_features(self, content):
        """分析ASM文件特征"""
        lines = content.split("\n")

        # 基本特征
        features = {
            "size": len(content),
            "line_count": len(lines),
            "comment_ratio": self._calculate_comment_ratio(lines),
            "has_cpp_features": self._detect_cpp_features(content),
            "has_elf_features": self._detect_elf_features(content),
            "arch": self._detect_architecture(content),
            "complexity": self._estimate_complexity(content),
        }

        # 详细指令分析
        instruction_stats = self._analyze_instruction_types(lines)
        features.update(instruction_stats)

        # 结构分析
        structure_stats = self._analyze_structure(lines)
        features.update(structure_stats)

        return features

    def _select_optimization_config(self, features, target_profile):
        """基于文件特征和目标配置选择优化策略"""
        # 如果指定了目标配置，使用它
        if target_profile and target_profile in OPTIMIZATION_PRESETS:
            base_config = OPTIMIZATION_PRESETS[target_profile].copy()
        else:
            # 否则，基于特征智能选择
            if features["has_cpp_features"]:
                base_config = OPTIMIZATION_PRESETS["cpp"].copy()
            elif features["has_elf_features"]:
                base_config = OPTIMIZATION_PRESETS["elf"].copy()
            else:
                # 根据特征选择合适的配置
                if features["complexity"] > 0.7:
                    # 复杂代码，保持较高可读性
                    base_config = OPTIMIZATION_PRESETS["balanced"].copy()
                elif features["comment_ratio"] > 0.4:
                    # 注释密集，使用高压缩
                    base_config = OPTIMIZATION_PRESETS["extreme"].copy()
                else:
                    # 默认平衡配置
                    base_config = OPTIMIZATION_PRESETS["balanced"].copy()

        # 调整配置以适应特定文件
        config = self._adjust_config_for_file(base_config, features)
        return config

    def _calculate_comment_ratio(self, lines):
        """计算注释行比例"""
        comment_lines = sum(1 for line in lines if line.strip().startswith(";"))
        return comment_lines / len(lines) if lines else 0

    def _analyze_instruction_types(self, lines):
        """分析指令类型分布"""
        from optimizers import get_opcode_type
        
        result = {
            "jump_count": 0,
            "call_count": 0,
            "memory_count": 0,
            "data_count": 0,
            "other_count": 0,
            "label_count": 0,
        }

        for line in lines:
            line_strip = line.strip()
            if not line_strip or line_strip.startswith(";"):
                continue

            # 检测标签
            if ":" in line_strip and " " not in line_strip.split(":", 1)[0]:
                result["label_count"] += 1
                continue

            # 检测指令
            parts = line_strip.split()
            if not parts:
                continue

            opcode = parts[0].upper()
            opcode_type = get_opcode_type(opcode)

            if opcode_type == "jump":
                result["jump_count"] += 1
            elif opcode_type == "call":
                result["call_count"] += 1
            elif opcode_type == "memory":
                result["memory_count"] += 1
            elif opcode_type == "data":
                result["data_count"] += 1
            else:
                result["other_count"] += 1

        return result

    def _analyze_structure(self, lines):
        """分析文件结构特征"""
        from constants import RE_SUBROUTINE, RE_STRUCT_BEGIN
        
        result = {"function_count": 0, "struct_count": 0, "section_count": 0, "xref_count": 0}

        for line in lines:
            line_strip = line.strip()

            if RE_SUBROUTINE.match(line_strip):
                result["function_count"] += 1
            elif RE_STRUCT_BEGIN.match(line_strip):
                result["struct_count"] += 1
            elif "AREA" in line_strip and not line_strip.startswith(";"):
                result["section_count"] += 1
            elif "; CODE XREF:" in line_strip or "; DATA XREF:" in line_strip:
                result["xref_count"] += 1

        return result

    def _detect_cpp_features(self, content):
        """检测C++特性"""
        cpp_indicators = ["vtable", "::operator", "thunk", "RTTI", "exception", "std::"]
        return any(indicator in content for indicator in cpp_indicators)

    def _detect_elf_features(self, content):
        """检测ELF特性"""
        # 检查ELF签名
        if RE_ELF_SIGNATURE.search(content):
            return True

        # 检查ELF相关段和结构
        elf_indicators = [".symtab", ".strtab", ".dynsym", "Elf32_", "Elf64_"]
        return any(indicator in content for indicator in elf_indicators)

    def _detect_architecture(self, content):
        """检测架构类型"""
        # 检查指令集特征
        thumb_indicators = [".W", ".N", "IT ", "ITTEE", "PUSH.W", "POP.W"]
        arm_indicators = ["STMFD", "LDMFD", "STMDB", "LDMIA"]

        sample = content[:4096]  # 仅使用前4KB进行检测

        thumb_count = sum(1 for indicator in thumb_indicators if indicator in sample)
        arm_count = sum(1 for indicator in arm_indicators if indicator in sample)

        # 检测CODE指令
        code_match = RE_CODE_DIRECTIVE.search(sample)
        if code_match:
            code_type = code_match.group(1)
            return "thumb" if code_type == "16" else "arm"

        # 基于指令频率判断
        return "thumb" if thumb_count > arm_count else "arm"

    def _estimate_complexity(self, content):
        """估计代码复杂度"""
        import re
        
        # 简单的复杂度估计
        complexity_score = 0.5  # 默认中等复杂度

        # 行数影响
        lines = content.split("\n")
        if len(lines) > 10000:
            complexity_score += 0.2
        elif len(lines) > 5000:
            complexity_score += 0.1

        # 跳转密度影响
        jump_count = content.count(" B ") + content.count(" BEQ ") + content.count(" BNE ")
        jump_density = jump_count / len(lines) if lines else 0

        if jump_density > 0.1:
            complexity_score += 0.2
        elif jump_density > 0.05:
            complexity_score += 0.1

        # 函数数量影响
        function_count = len(re.findall(r"; ={10,} S U B R O U T I N E", content))
        if function_count > 100:
            complexity_score += 0.1

        return min(1.0, complexity_score)

    def _adjust_config_for_file(self, base_config, features):
        """根据文件特征微调配置"""
        config = base_config.copy()

        # 根据大小调整压缩强度
        if features["size"] > 1000000:  # 大文件
            config["target_compression"] = min(0.9, config["target_compression"] + 0.1)

        # 根据复杂度调整可读性要求
        if features["complexity"] > 0.8:
            config["target_readability"] = max(0.7, config["target_readability"])

        # 根据架构调整
        if features["arch"] == "thumb":
            # Thumb模式通常需要更多可读性
            config["target_readability"] = max(0.6, config["target_readability"])

        # 根据注释比例调整
        if features["comment_ratio"] > 0.5:
            # 注释很多，可以更激进地压缩
            config["comment_preservation"] = min(0.5, config["comment_preservation"])

        return config


class AsmOptimizerCore:
    """ASM优化器核心类 - 协调整个优化过程"""

    def __init__(self, preset="balanced", custom_config=None):
        # 加载配置
        if custom_config:
            self.config = custom_config
        elif preset in OPTIMIZATION_PRESETS:
            self.config = OPTIMIZATION_PRESETS[preset].copy()
        else:
            self.config = OPTIMIZATION_PRESETS["balanced"].copy()

        # 创建自适应优化器
        self.adaptive_optimizer = AdaptiveOptimizer()

        # 统计信息
        self.stats = {
            "original_size": 0,
            "optimized_size": 0,
            "reduction_percent": 0.0,
            "detected_arch": None,
            "is_elf_binary": False,
        }

        # 检测设备性能
        self.thread_count = THREAD_COUNT
        self.battery_save = BATTERY_SAVE

    def optimize_file(self, input_file, output_file):
        """优化单个文件"""
        try:
            file_size = os.path.getsize(input_file)

            # 检测文件类型
            self._detect_file_type(input_file)

            if file_size > 10 * MEM_CHUNK:
                return self._optimize_large_file(input_file, output_file, file_size)

            with open(input_file, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()

            result = self.optimize_content(content)

            with open(output_file, "w", encoding="utf-8") as f:
                f.write(result["optimized_content"])

            return result
        except Exception as e:
            return {"error": str(e)}

    def _detect_file_type(self, input_file):
        """检测文件类型"""
        try:
            with open(input_file, "r", encoding="utf-8", errors="replace") as f:
                # 读取前1000行或前64KB
                header = ""
                for _ in range(1000):
                    line = f.readline()
                    if not line:
                        break
                    header += line
                    if len(header) > 65536:
                        break

            # 检测是否为ELF文件
            if RE_ELF_SIGNATURE.search(header):
                self.stats["is_elf_binary"] = True

                # 如果检测到ELF且用户未指定特定预设，考虑使用ELF预设
                if self.config.get("level", 0) == OPTIMIZATION_PRESETS["balanced"]["level"]:
                    self.config = OPTIMIZATION_PRESETS["elf"].copy()

            # 检测是否为C++应用
            cpp_signs = [
                "_ZN",
                "vtable",
                "typeinfo",
                "constructor",
                "destructor",
                "::~",
                "::",
                "exception",
                "std::",
                "operator",
            ]

            cpp_score = sum(1 for sign in cpp_signs if sign in header)
            if cpp_score >= 3:
                self.stats["is_cpp"] = True

                # 如果是C++文件且没有使用特定预设，考虑使用cpp预设
                if (
                    not self.stats["is_elf_binary"]
                    and self.config.get("level", 0) == OPTIMIZATION_PRESETS["balanced"]["level"]
                ):
                    self.config = OPTIMIZATION_PRESETS["cpp"].copy()

        except Exception as e:
            print(f"文件类型检测错误: {str(e)}")

    def _optimize_large_file(self, input_file, output_file, file_size):
        """处理大文件 - 分块读取并处理"""
        chunk_size = MEM_CHUNK
        total_chunks = (file_size + chunk_size - 1) // chunk_size

        results = []
        original_size = 0
        optimized_size = 0

        with open(input_file, "r", encoding="utf-8", errors="replace") as in_file, open(
            output_file, "w", encoding="utf-8"
        ) as out_file:
            for i in range(total_chunks):
                chunk = in_file.read(chunk_size)
                if not chunk:
                    break

                print(f"处理块 {i + 1}/{total_chunks}...")
                chunk_result = self.optimize_content(chunk, is_chunk=True, chunk_index=i)
                results.append(chunk_result)

                original_size += chunk_result["original_size"]
                optimized_size += chunk_result["optimized_size"]

                out_file.write(chunk_result["optimized_content"])

                # 节电模式下，大文件每处理一个块休息一小段时间
                if self.battery_save and i % 5 == 0:
                    time.sleep(0.1)

        reduction = (1 - optimized_size / original_size) * 100 if original_size > 0 else 0

        return {
            "original_size": original_size,
            "optimized_size": optimized_size,
            "reduction_percent": reduction,
            "detected_arch": self.stats["detected_arch"],
            "is_elf_binary": self.stats["is_elf_binary"],
        }

    def optimize_content(self, content, is_chunk=False, chunk_index=0):
        """优化ASM内容"""
        original_size = len(content)

        # 检测架构
        if not is_chunk or chunk_index == 0:
            self._detect_architecture(content[:4096])

        # 使用自适应优化器
        target_profile = None
        for preset_name, preset_config in OPTIMIZATION_PRESETS.items():
            if preset_config == self.config:
                target_profile = preset_name
                break

        result = self.adaptive_optimizer.optimize(content, target_profile)

        # 更新统计信息
        optimized_content = result["optimized_content"]
        optimized_size = len(optimized_content)
        reduction = calculate_compression_ratio(content, optimized_content) * 100

        self.stats["original_size"] = original_size
        self.stats["optimized_size"] = optimized_size
        self.stats["reduction_percent"] = reduction
        self.stats["detected_arch"] = self.stats.get(
            "detected_arch", self.adaptive_optimizer.stats["file_features"].get("arch", "unknown")
        )

        # 合并自适应优化器的统计
        for key, value in self.adaptive_optimizer.stats.items():
            if key not in ["original_size", "optimized_size"]:
                self.stats[key] = value

        return {
            "optimized_content": optimized_content,
            "original_size": original_size,
            "optimized_size": optimized_size,
            "reduction_percent": reduction,
            "stats": self.stats,
        }

    def _detect_architecture(self, sample):
        """检测ASM代码的架构类型"""
        thumb_indicators = [".W", ".N", "IT ", "ITTEE", "PUSH.W", "POP.W"]
        arm_indicators = ["STMFD", "LDMFD", "STMDB", "LDMIA"]

        # 处理CODE指令
        for line in sample.split("\n"):
            code_match = RE_CODE_DIRECTIVE.search(line)
            if code_match:
                code_type = code_match.group(1)
                self.stats["detected_arch"] = "thumb" if code_type == "16" else "arm"
                return

        # 基于指令频率判断
        thumb_count = sum(1 for line in sample.split("\n") if any(ti in line for ti in thumb_indicators))
        arm_count = sum(1 for line in sample.split("\n") if any(ai in line for ai in arm_indicators))

        self.stats["detected_arch"] = "thumb" if thumb_count > arm_count else "arm"
