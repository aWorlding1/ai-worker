#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
IDA反汇编.asm文件智能优化工具 - 命令行接口模块
包含交互式界面和用户交互功能
"""

import os
import json
import time
import glob
import subprocess

from constants import OPTIMIZATION_PRESETS, BATTERY_SAVE, RE_ELF_SIGNATURE
from core import AsmOptimizerCore, format_size, create_directory_if_not_exists


class AsmOptimizerCLI:
    """交互式命令行界面"""

    def __init__(self):
        self.config_file = os.path.expanduser("~/.ida_asm_optimizer.json")
        self.load_config()
        self.current_file = None
        self.batch_stats = {}

    def load_config(self):
        """加载配置文件，如果不存在则创建默认配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, "r", encoding="utf-8") as f:
                    self.config = json.load(f)
            else:
                self.config = {
                    "preset": "balanced",
                    "recent_files": [],
                    "recent_dirs": [],
                    "custom_presets": {},
                    "auto_detect_elf": True,
                    "auto_detect_cpp": True,
                    "battery_save": BATTERY_SAVE,
                }
                self.save_config()
        except Exception as e:
            print(f"加载配置文件时出错: {str(e)}")
            self.config = {
                "preset": "balanced",
                "recent_files": [],
                "auto_detect_elf": True,
                "battery_save": BATTERY_SAVE,
            }

    def save_config(self):
        """保存配置到文件"""
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"保存配置文件时出错: {str(e)}")

    def update_recent_files(self, filepath):
        """更新最近使用的文件列表"""
        if filepath in self.config["recent_files"]:
            self.config["recent_files"].remove(filepath)
        self.config["recent_files"].insert(0, filepath)
        self.config["recent_files"] = self.config["recent_files"][:10]  # 保留最近10个
        self.save_config()

    def update_recent_dirs(self, dirpath):
        """更新最近使用的目录列表"""
        if "recent_dirs" not in self.config:
            self.config["recent_dirs"] = []

        if dirpath in self.config["recent_dirs"]:
            self.config["recent_dirs"].remove(dirpath)
        self.config["recent_dirs"].insert(0, dirpath)
        self.config["recent_dirs"] = self.config["recent_dirs"][:5]  # 保留最近5个
        self.save_config()

    def _clear_screen(self):
        """清屏，兼容各操作系统"""
        os.system("cls" if os.name == "nt" else "clear")

    def _display_presets(self):
        """显示可用的优化预设"""
        print("\n可用优化预设:")
        for name, preset in OPTIMIZATION_PRESETS.items():
            print(f"- {name}: {preset['desc']}")

        if "custom_presets" in self.config:
            for name, preset in self.config["custom_presets"].items():
                print(f"- {name} (自定义): {preset.get('desc', '')}")

    def interactive_menu(self):
        """显示交互式菜单"""
        while True:
            self._clear_screen()
            print("\n┌──────────────────────────────────────┐")
            print("│     IDA汇编优化器 - 智能压缩版 4.0     │")
            print("└──────────────────────────────────────┘\n")
            print("1. 优化单个.asm文件")
            print("2. 优化目录中所有.asm文件")
            print("3. 从剪贴板优化汇编代码")
            print("4. 修改优化设置")
            print("5. 查看最近处理的文件")
            print("6. 批量处理(.asm拖放模式)")
            print("7. 高级优化选项")
            print("8. 分析.asm文件结构")
            print("q. 退出程序")

            choice = input("\n选择操作: ")

            if choice == "1":
                self.optimize_file()
            elif choice == "2":
                self.optimize_directory()
            elif choice == "3":
                self.optimize_clipboard()
            elif choice == "4":
                self.change_settings()
            elif choice == "5":
                self.show_recent_files()
            elif choice == "6":
                self.batch_process()
            elif choice == "7":
                self.advanced_options()
            elif choice == "8":
                self.analyze_asm_file()
            elif choice.lower() == "q":
                break

    def optimize_file(self):
        """优化单个文件的交互流程"""
        self._clear_screen()
        print("\n[优化单个.asm文件]\n")

        if self.config["recent_files"]:
            print("最近文件:")
            for i, f in enumerate(self.config["recent_files"][:5]):
                print(f"{i + 1}. {f}")
            print("r. 输入新路径")

            choice = input("\n选择文件或输入'r': ")

            if choice.isdigit() and 1 <= int(choice) <= min(5, len(self.config["recent_files"])):
                filepath = self.config["recent_files"][int(choice) - 1]
            else:
                filepath = input("输入.asm文件路径: ").strip()
        else:
            filepath = input("输入.asm文件路径: ").strip()

        if not os.path.exists(filepath):
            print(f"错误: 文件'{filepath}'不存在")
            input("按Enter继续...")
            return

        output_path = input(f"输出文件路径 [默认: {os.path.splitext(filepath)[0]}_optimized.asm]: ").strip()
        if not output_path:
            output_path = f"{os.path.splitext(filepath)[0]}_optimized.asm"

        # 显示预设选项
        self._display_presets()
        preset = input(f"选择优化预设 [默认: {self.config['preset']}]: ").strip()
        if not preset:
            preset = self.config["preset"]
        elif preset not in OPTIMIZATION_PRESETS and preset not in self.config.get("custom_presets", {}):
            print(f"预设'{preset}'不存在，使用默认预设'{self.config['preset']}'")
            preset = self.config["preset"]

        print("\n正在优化，请稍候...")

        # 选择配置
        if preset in OPTIMIZATION_PRESETS:
            config = OPTIMIZATION_PRESETS[preset].copy()
        elif preset in self.config.get("custom_presets", {}):
            config = self.config["custom_presets"][preset].copy()
        else:
            config = OPTIMIZATION_PRESETS[self.config["preset"]].copy()

        # 创建优化器并运行
        optimizer = AsmOptimizerCore(preset, config)
        result = optimizer.optimize_file(filepath, output_path)

        if "error" in result:
            print(f"出错: {result['error']}")
        else:
            print("\n优化完成!")
            print(f"原始大小: {format_size(result['original_size'])}")
            print(f"优化后大小: {format_size(result['optimized_size'])}")
            print(f"减小比例: {result['reduction_percent']:.2f}%")
            print(f"检测架构: {result.get('detected_arch', 'unknown')}")

            if result.get("is_elf_binary", False):
                print("文件类型: ELF二进制反汇编")

            # 显示详细统计
            if "compression_ratio" in result["stats"]:
                print(f"\n压缩比: {result['stats']['compression_ratio'] * 100:.2f}%")

            if "readability_score" in result["stats"]:
                print(f"可读性评分: {result['stats']['readability_score'] * 100:.2f}%")

            if "applied_compressors" in result["stats"]:
                print(f"应用的优化器: {', '.join(result['stats']['applied_compressors'])}")

            self.update_recent_files(filepath)
            self.current_file = filepath

        # 添加后续操作选项
        print("\n后续操作:")
        print("1. 返回主菜单")
        print("2. 分析优化后的文件")
        print("3. 使用不同预设重新优化")
        print("4. 比较优化前后的文件")

        choice = input("\n选择操作: ")

        if choice == "2":
            self.analyze_optimized_file(output_path)
        elif choice == "3":
            self.reoptimize_file(filepath, output_path)
        elif choice == "4":
            self.compare_files(filepath, output_path)

        input("\n按Enter继续...")

    def optimize_directory(self):
        """优化目录中所有.asm文件"""
        self._clear_screen()
        print("\n[优化目录中所有.asm文件]\n")

        if "recent_dirs" in self.config and self.config["recent_dirs"]:
            print("最近目录:")
            for i, d in enumerate(self.config["recent_dirs"]):
                print(f"{i + 1}. {d}")
            print("r. 输入新路径")

            choice = input("\n选择目录或输入'r': ")

            if choice.isdigit() and 1 <= int(choice) <= len(self.config["recent_dirs"]):
                dirpath = self.config["recent_dirs"][int(choice) - 1]
            else:
                dirpath = input("输入目录路径: ").strip()
        else:
            dirpath = input("输入目录路径: ").strip()

        if not os.path.exists(dirpath) or not os.path.isdir(dirpath):
            print(f"错误: 目录'{dirpath}'不存在")
            input("按Enter继续...")
            return

        output_dir = input(f"输出目录 [默认: {dirpath}_optimized]: ").strip()
        if not output_dir:
            output_dir = f"{dirpath}_optimized"

        recursive = input("是否递归处理子目录? (y/n) [默认: n]: ").strip().lower()
        recursive = recursive == "y"

        # 是否启用智能预设选择
        smart_preset = input("是否自动选择最佳预设(针对文件类型)? (y/n) [默认: y]: ").strip().lower() != "n"

        # 显示预设选项
        self._display_presets()

        # 默认预设
        default_preset = self.config.get("preset", "balanced")
        preset = input(f"选择默认优化预设 [默认: {default_preset}]: ").strip()
        if not preset:
            preset = default_preset
        elif preset not in OPTIMIZATION_PRESETS and preset not in self.config.get("custom_presets", {}):
            print(f"预设'{preset}'不存在，使用默认预设'{default_preset}'")
            preset = default_preset

        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        print("\n开始处理目录中的.asm文件...")

        files_processed = 0
        total_reduction = 0
        total_original_size = 0
        total_optimized_size = 0
        elf_files = 0
        cpp_files = 0

        # 收集文件和结果统计
        self.batch_stats = {
            "files": [],
            "total_original": 0,
            "total_optimized": 0,
            "elf_count": 0,
            "cpp_count": 0,
            "arm_count": 0,
            "thumb_count": 0,
        }

        pattern = os.path.join(dirpath, "**" if recursive else "", "*.asm")
        for file_path in glob.glob(pattern, recursive=recursive):
            rel_path = os.path.relpath(file_path, dirpath)
            output_path = os.path.join(output_dir, rel_path)
            output_subdir = os.path.dirname(output_path)

            if not os.path.exists(output_subdir):
                os.makedirs(output_subdir)

            print(f"处理: {rel_path}")

            current_preset = preset

            # 自动检测文件类型并使用适当预设
            if smart_preset:
                with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                    header = f.read(4096)
                    if self.config.get("auto_detect_elf", True) and RE_ELF_SIGNATURE.search(header):
                        current_preset = "elf"
                        print("  检测到ELF文件，使用'elf'预设")
                        elf_files += 1
                    elif self.config.get("auto_detect_cpp", True) and ("::" in header or "_ZN" in header):
                        current_preset = "cpp"
                        print("  检测到C++文件，使用'cpp'预设")
                        cpp_files += 1

            # 选择配置
            if current_preset in OPTIMIZATION_PRESETS:
                config = OPTIMIZATION_PRESETS[current_preset].copy()
            elif current_preset in self.config.get("custom_presets", {}):
                config = self.config["custom_presets"][current_preset].copy()
            else:
                config = OPTIMIZATION_PRESETS[default_preset].copy()

            optimizer = AsmOptimizerCore(current_preset, config)
            result = optimizer.optimize_file(file_path, output_path)

            if "error" not in result:
                files_processed += 1
                current_reduction = result["reduction_percent"]
                total_reduction += current_reduction
                total_original_size += result["original_size"]
                total_optimized_size += result["optimized_size"]

                # 记录文件统计
                self.batch_stats["files"].append(
                    {
                        "path": rel_path,
                        "original_size": result["original_size"],
                        "optimized_size": result["optimized_size"],
                        "reduction": current_reduction,
                        "arch": result.get("detected_arch", "unknown"),
                        "is_elf": result.get("is_elf_binary", False),
                        "is_cpp": result.get("is_cpp", False),
                    }
                )

                if result.get("is_elf_binary", False):
                    self.batch_stats["elf_count"] += 1
                if result.get("is_cpp", False):
                    self.batch_stats["cpp_count"] += 1
                if result.get("detected_arch", "") == "arm":
                    self.batch_stats["arm_count"] += 1
                elif result.get("detected_arch", "") == "thumb":
                    self.batch_stats["thumb_count"] += 1

                print(f"  减小: {current_reduction:.2f}%")

                # 节电模式
                if self.config.get("battery_save", BATTERY_SAVE) and files_processed % 5 == 0:
                    time.sleep(0.2)

        self.batch_stats["total_original"] = total_original_size
        self.batch_stats["total_optimized"] = total_optimized_size

        if files_processed > 0:
            self.update_recent_dirs(dirpath)
            avg_reduction = total_reduction / files_processed
            print(f"\n已处理 {files_processed} 个文件")
            print(f"平均减小比例: {avg_reduction:.2f}%")
            print(f"总原始大小: {format_size(total_original_size)}")
            print(f"总优化大小: {format_size(total_optimized_size)}")
            print(f"总节省: {format_size(total_original_size - total_optimized_size)}")

            if elf_files > 0:
                print(f"ELF文件数量: {elf_files}")
            if cpp_files > 0:
                print(f"C++文件数量: {cpp_files}")

            # 提供批处理结果分析选项
            print("\n后续操作:")
            print("1. 返回主菜单")
            print("2. 查看批处理详细统计")
            print("3. 导出批处理报告")

            choice = input("\n选择操作: ")

            if choice == "2":
                self.show_batch_statistics()
            elif choice == "3":
                self.export_batch_report(dirpath, output_dir)
        else:
            print("没有找到要处理的.asm文件")

        input("\n按Enter继续...")

    def optimize_clipboard(self):
        """从剪贴板优化汇编代码"""
        self._clear_screen()
        print("\n[从剪贴板优化汇编代码]\n")

        # 显示预设选项
        self._display_presets()
        preset = input(f"选择优化预设 [默认: {self.config['preset']}]: ").strip()
        if not preset:
            preset = self.config["preset"]
        elif preset not in OPTIMIZATION_PRESETS and preset not in self.config.get("custom_presets", {}):
            print(f"预设'{preset}'不存在，使用默认预设'{self.config['preset']}'")
            preset = self.config["preset"]

        print("\n从剪贴板获取内容并优化...")

        try:
            import subprocess

            # 使用timeout避免hang
            process = subprocess.Popen(["termux-clipboard-get"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                print("获取剪贴板超时")
                input("\n按Enter继续...")
                return

            if process.returncode != 0:
                error = stderr.decode("utf-8")
                if "command not found" in error:
                    print("错误: 找不到termux-api命令")
                    print("请执行: pkg install termux-api")
                else:
                    print(f"获取剪贴板内容错误: {error}")
                input("\n按Enter继续...")
                return

            content = stdout.decode("utf-8", errors="replace")
            if not content.strip():
                print("剪贴板为空")
                input("\n按Enter继续...")
                return

            # 自动检测文件类型
            if self.config.get("auto_detect_elf", True) and RE_ELF_SIGNATURE.search(content):
                print("检测到ELF格式代码，推荐使用'elf'预设")
                if input("是否切换到'elf'预设? (y/n) [默认: y]: ").strip().lower() != "n":
                    preset = "elf"
                    print("已切换到'elf'预设")
            elif self.config.get("auto_detect_cpp", True) and ("::" in content or "_ZN" in content):
                print("检测到C++代码，推荐使用'cpp'预设")
                if input("是否切换到'cpp'预设? (y/n) [默认: y]: ").strip().lower() != "n":
                    preset = "cpp"
                    print("已切换到'cpp'预设")

            # 选择配置
            if preset in OPTIMIZATION_PRESETS:
                config = OPTIMIZATION_PRESETS[preset].copy()
            elif preset in self.config.get("custom_presets", {}):
                config = self.config["custom_presets"][preset].copy()
            else:
                config = OPTIMIZATION_PRESETS[self.config["preset"]].copy()

            optimizer = AsmOptimizerCore(preset, config)
            result = optimizer.optimize_content(content)

            # 检查压缩效果
            if result["reduction_percent"] < 10:
                retry = (
                    input(
                        f"优化效果不明显 ({result['reduction_percent']:.2f}%)，是否尝试更激进的优化? (y/n) [默认: y]: "
                    )
                    .strip()
                    .lower()
                )
                if retry != "n":
                    print("使用'extreme'预设重新优化...")
                    optimizer = AsmOptimizerCore("extreme")
                    result = optimizer.optimize_content(content)

            # 写回剪贴板
            process = subprocess.Popen(["termux-clipboard-set"], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                process.communicate(input=result["optimized_content"].encode("utf-8"), timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                print("设置剪贴板超时")
                input("\n按Enter继续...")
                return

            if process.returncode != 0:
                print(f"设置剪贴板内容错误: {stderr.decode('utf-8')}")
            else:
                print(f"原始大小: {format_size(result['original_size'])}")
                print(f"优化后大小: {format_size(result['optimized_size'])}")
                print(f"减小比例: {result['reduction_percent']:.2f}%")
                print(f"检测架构: {result['stats']['detected_arch']}")

                if result["stats"].get("is_elf_binary", False):
                    print("文件类型: ELF二进制反汇编")

                # 显示可读性评分
                if "readability_score" in result["stats"]:
                    print(f"可读性评分: {result['stats']['readability_score'] * 100:.2f}%")

                # 显示应用的压缩器
                if "applied_compressors" in result["stats"]:
                    print(f"应用的优化器: {', '.join(result['stats']['applied_compressors'])}")

                print("\n优化后的汇编代码已复制到剪贴板")

                # 提供保存到文件选项
                if input("\n是否保存到文件? (y/n) [默认: n]: ").strip().lower() == "y":
                    file_path = input("输入文件路径: ").strip()
                    if file_path:
                        try:
                            with open(file_path, "w", encoding="utf-8") as f:
                                f.write(result["optimized_content"])
                            print(f"已保存到: {file_path}")
                        except Exception as e:
                            print(f"保存文件时出错: {str(e)}")

        except Exception as e:
            print(f"错误: {str(e)}")
            print("注意: 此功能需要安装termux-api软件包")

        input("\n按Enter继续...")

    def change_settings(self):
        """更改优化设置"""
        while True:
            self._clear_screen()
            print("\n[修改优化设置]\n")

            print("1. 更改默认优化预设")
            print("2. 创建自定义预设")
            print("3. 删除自定义预设")
            print("4. 配置自动文件检测")
            print("5. 配置电池优化选项")
            print("6. 返回主菜单")

            choice = input("\n选择操作: ")

            if choice == "1":
                self._change_default_preset()
            elif choice == "2":
                self._create_custom_preset()
            elif choice == "3":
                self._delete_custom_preset()
            elif choice == "4":
                self._configure_auto_detection()
            elif choice == "5":
                self._configure_battery_saving()
            elif choice == "6":
                return

    def _change_default_preset(self):
        """更改默认优化预设"""
        self._clear_screen()
        print("\n[更改默认优化预设]\n")

        self._display_presets()
        preset = input(f"\n选择新的默认预设 [当前: {self.config['preset']}]: ").strip()

        if preset in OPTIMIZATION_PRESETS or preset in self.config.get("custom_presets", {}):
            self.config["preset"] = preset
            self.save_config()
            print(f"默认预设已更改为: {preset}")
        else:
            print(f"错误: 预设'{preset}'不存在")

        input("\n按Enter继续...")

    def _create_custom_preset(self):
        """创建自定义预设"""
        self._clear_screen()
        print("\n[创建自定义预设]\n")

        name = input("输入预设名称: ").strip()
        if not name:
            print("预设名称不能为空")
            input("\n按Enter继续...")
            return

        if name in OPTIMIZATION_PRESETS:
            print(f"错误: '{name}'是内置预设，无法覆盖")
            input("\n按Enter继续...")
            return

        if "custom_presets" not in self.config:
            self.config["custom_presets"] = {}

        desc = input("输入预设描述: ").strip()

        print("\n选择优化级别:")
        print("1 - 轻度优化 (保持可读性)")
        print("2 - 中度优化 (平衡大小与可读性)")
        print("3 - 高度优化 (最小化文件大小)")

        level = input("选择级别 [1-3]: ").strip()
        if not level.isdigit() or int(level) < 1 or int(level) > 3:
            print("无效的级别，使用默认值 2")
            level = 2
        else:
            level = int(level)

        # 创建预设条目
        self.config["custom_presets"][name] = {}
        
        self.config["custom_presets"][name]["comment_preservation"] = (
            0.9 if input("保留注释? (y/n) [默认: y]: ").strip().lower() != "n" else 0.3
        )

        print("\n选择操作码对齐方式:")
        print("0 - 不对齐")
        print("8 - 8字符对齐")
        print("12 - 12字符对齐")
        print("16 - 16字符对齐")

        align = input("选择对齐 [0/8/12/16]: ").strip()
        if not align.isdigit():
            print("无效的对齐值，使用默认值 8")
            align = 8
        else:
            align = int(align)

        self.config["custom_presets"][name]["preserve_jump_targets"] = (
            input("保留位置标签? (y/n) [默认: y]: ").strip().lower() != "n"
        )

        # 目标可读性和压缩率
        target_readability = input("目标可读性评分 (0.0-1.0) [默认: 0.7]: ").strip()
        if not target_readability:
            target_readability = 0.7
        else:
            try:
                target_readability = float(target_readability)
                if target_readability < 0.0 or target_readability > 1.0:
                    print("无效的可读性评分，使用默认值 0.7")
                    target_readability = 0.7
            except ValueError:
                print("无效的可读性评分，使用默认值 0.7")
                target_readability = 0.7

        target_compression = input("目标压缩率 (0.0-1.0) [默认: 0.6]: ").strip()
        if not target_compression:
            target_compression = 0.6
        else:
            try:
                target_compression = float(target_compression)
                if target_compression < 0.0 or target_compression > 1.0:
                    print("无效的压缩率，使用默认值 0.6")
                    target_compression = 0.6
            except ValueError:
                print("无效的压缩率，使用默认值 0.6")
                target_compression = 0.6

        # 完成预设的创建
        self.config["custom_presets"][name] = {
            "level": level,
            "comment_preservation": 0.9 if level == 1 else (0.6 if level == 2 else 0.3),
            "alignment": align,
            "preserve_structure": level < 3,
            "preserve_jump_targets": True,
            "compress_locals": level > 1,
            "xref_compression": level,
            "data_compression": level,
            "struct_compression": level,
            "target_readability": target_readability,
            "target_compression": target_compression,
            "desc": desc,
        }

        self.save_config()
        print(f"\n自定义预设 '{name}' 已创建")
        input("\n按Enter继续...")

    def _delete_custom_preset(self):
        """删除自定义预设"""
        self._clear_screen()
        print("\n[删除自定义预设]\n")

        if "custom_presets" not in self.config or not self.config["custom_presets"]:
            print("没有自定义预设可删除")
            input("\n按Enter继续...")
            return

        print("可删除的自定义预设:")
        for i, name in enumerate(self.config["custom_presets"].keys()):
            print(f"{i + 1}. {name}")

        choice = input("\n选择要删除的预设编号 (0=取消): ").strip()

        if choice == "0":
            return

        if choice.isdigit() and 1 <= int(choice) <= len(self.config["custom_presets"]):
            name = list(self.config["custom_presets"].keys())[int(choice) - 1]

            confirm = input(f"确认删除预设 '{name}'? (y/n): ").strip().lower()
            if confirm == "y":
                # 如果删除的是当前默认预设，重置为"balanced"
                if self.config["preset"] == name:
                    self.config["preset"] = "balanced"
                    print("默认预设已重置为: balanced")

                del self.config["custom_presets"][name]
                self.save_config()
                print(f"预设 '{name}' 已删除")
        else:
            print("无效的选择")

        input("\n按Enter继续...")

    def _configure_auto_detection(self):
        """配置自动检测选项"""
        self._clear_screen()
        print("\n[自动文件类型检测配置]\n")

        print("当前设置:")
        print(f"1. 自动检测ELF文件: {'启用' if self.config.get('auto_detect_elf', True) else '禁用'}")
        print(f"2. 自动检测C++文件: {'启用' if self.config.get('auto_detect_cpp', True) else '禁用'}")
        print(
            f"3. 全部{
                '启用' if self.config.get(
                    'auto_detect_elf',
                    True) and self.config.get(
                    'auto_detect_cpp',
                    True) else '禁用'}"
        )
        print("4. 返回上级菜单")

        choice = input("\n选择要切换的设置: ")

        if choice == "1":
            self.config["auto_detect_elf"] = not self.config.get("auto_detect_elf", True)
            print(f"\n自动检测ELF文件已{'启用' if self.config['auto_detect_elf'] else '禁用'}")
            self.save_config()
        elif choice == "2":
            self.config["auto_detect_cpp"] = not self.config.get("auto_detect_cpp", True)
            print(f"\n自动检测C++文件已{'启用' if self.config['auto_detect_cpp'] else '禁用'}")
            self.save_config()
        elif choice == "3":
            enable_all = not (self.config.get("auto_detect_elf", True) and self.config.get("auto_detect_cpp", True))
            self.config["auto_detect_elf"] = enable_all
            self.config["auto_detect_cpp"] = enable_all
            print(f"\n自动检测功能已全部{'启用' if enable_all else '禁用'}")
            self.save_config()

        input("\n按Enter继续...")

    def _configure_battery_saving(self):
        """配置电池节省选项"""
        # 注意：这涉及全局变量
        global BATTERY_SAVE

        self._clear_screen()
        print("\n[电池优化选项]\n")

        current = self.config.get("battery_save", BATTERY_SAVE)

        print(f"当前电池优化模式: {'开启' if current else '关闭'}")
        print("\n开启电池优化后，程序会减少CPU和内存使用，适合长时间运行。")
        print("关闭电池优化可提高性能，但会增加电池消耗。")

        choice = input("\n是否切换设置? (y/n): ").strip().lower()

        if choice == "y":
            self.config["battery_save"] = not current
            self.save_config()
            print(f"\n电池优化已{'启用' if not current else '禁用'}")

            # 更新全局变量
            BATTERY_SAVE = self.config["battery_save"]
            
        input("\n按Enter继续...")

    def advanced_options(self):
        """高级优化选项菜单"""
        self._clear_screen()
        print("\n[高级优化选项]\n")

        print("1. 压缩与可读性平衡设置")
        print("2. 指令集特定优化选项")
        print("3. 结构体优化选项")
        print("4. XREF处理选项")
        print("5. 数据定义优化选项")
        print("6. 返回主菜单")

        choice = input("\n选择操作: ")

        if choice == "1":
            self._configure_compression_readability_balance()
        elif choice == "2":
            self._configure_instruction_set_options()
        elif choice == "3":
            self._configure_struct_options()
        elif choice == "4":
            self._configure_xref_options()
        elif choice == "5":
            self._configure_data_definition_options()
        else:
            return

    def _configure_compression_readability_balance(self):
        """配置压缩与可读性平衡"""
        self._clear_screen()
        print("\n[压缩与可读性平衡设置]\n")

        if "advanced_settings" not in self.config:
            self.config["advanced_settings"] = {}

        current_readability = self.config["advanced_settings"].get("target_readability", 0.7)
        current_compression = self.config["advanced_settings"].get("target_compression", 0.6)

        print(f"当前目标可读性: {current_readability:.2f} (0.0-1.0)")
        print(f"当前目标压缩率: {current_compression:.2f} (0.0-1.0)")
        print("\n较高的可读性值会保留更多原始格式，但减少压缩率")
        print("较高的压缩率值会更激进地压缩，但可能降低可读性")

        new_readability = input("\n新的目标可读性 (0.0-1.0) [回车保持当前值]: ").strip()
        if new_readability:
            try:
                new_readability = float(new_readability)
                if 0.0 <= new_readability <= 1.0:
                    self.config["advanced_settings"]["target_readability"] = new_readability
                else:
                    print("无效的值，必须在0.0-1.0之间")
            except ValueError:
                print("无效的输入，必须是小数")

        new_compression = input("\n新的目标压缩率 (0.0-1.0) [回车保持当前值]: ").strip()
        if new_compression:
            try:
                new_compression = float(new_compression)
                if 0.0 <= new_compression <= 1.0:
                    self.config["advanced_settings"]["target_compression"] = new_compression
                else:
                    print("无效的值，必须在0.0-1.0之间")
            except ValueError:
                print("无效的输入，必须是小数")

        self.save_config()
        print("\n设置已更新")

        input("\n按Enter继续...")

    def _configure_instruction_set_options(self):
        """配置指令集特定优化选项"""
        self._clear_screen()
        print("\n[指令集特定优化选项]\n")

        if "advanced_settings" not in self.config:
            self.config["advanced_settings"] = {}
        if "instruction_set" not in self.config["advanced_settings"]:
            self.config["advanced_settings"]["instruction_set"] = {}

        settings = self.config["advanced_settings"]["instruction_set"]

        print("ARM指令集优化选项:")
        print(f"1. 优化IT块: {'是' if settings.get('optimize_it_blocks', True) else '否'}")
        print(f"2. 合并LDR/STR为LDM/STM: {'是' if settings.get('merge_memory_ops', True) else '否'}")
        print(f"3. 优化条件执行: {'是' if settings.get('optimize_conditional', True) else '否'}")
        print("4. 返回上级菜单")

        choice = input("\n选择要修改的选项: ")

        if choice == "1":
            current = settings.get("optimize_it_blocks", True)
            settings["optimize_it_blocks"] = not current
            print(f"优化IT块已{'禁用' if current else '启用'}")
            self.save_config()
        elif choice == "2":
            current = settings.get("merge_memory_ops", True)
            settings["merge_memory_ops"] = not current
            print(f"合并LDR/STR为LDM/STM已{'禁用' if current else '启用'}")
            self.save_config()
        elif choice == "3":
            current = settings.get("optimize_conditional", True)
            settings["optimize_conditional"] = not current
            print(f"优化条件执行已{'禁用' if current else '启用'}")
            self.save_config()

        input("\n按Enter继续...")

    def _configure_struct_options(self):
        """配置结构体优化选项"""
        self._clear_screen()
        print("\n[结构体优化选项]\n")

        if "advanced_settings" not in self.config:
            self.config["advanced_settings"] = {}
        if "struct_settings" not in self.config["advanced_settings"]:
            self.config["advanced_settings"]["struct_settings"] = {}

        settings = self.config["advanced_settings"]["struct_settings"]

        print("结构体压缩选项:")
        print(f"1. 优化ELF结构体: {'是' if settings.get('optimize_elf_structs', True) else '否'}")
        print(f"2. 保留结构体字段注释: {'是' if settings.get('keep_field_comments', True) else '否'}")
        print("3. 结构体压缩级别: {0}".format(settings.get("compression_level", 2)))
        print("4. 返回上级菜单")

        choice = input("\n选择要修改的选项: ")

        if choice == "1":
            current = settings.get("optimize_elf_structs", True)
            settings["optimize_elf_structs"] = not current
            print(f"优化ELF结构体已{'禁用' if current else '启用'}")
            self.save_config()
        elif choice == "2":
            current = settings.get("keep_field_comments", True)
            settings["keep_field_comments"] = not current
            print(f"保留结构体字段注释已{'禁用' if current else '启用'}")
            self.save_config()
        elif choice == "3":
            current = settings.get("compression_level", 2)
            print("\n结构体压缩级别:")
            print("1 - 轻度 (保留大部分格式)")
            print("2 - 中度 (平衡压缩与可读性)")
            print("3 - 高度 (最大化压缩)")

            new_level = input(f"选择新的压缩级别 [当前: {current}]: ").strip()
            if new_level.isdigit() and 1 <= int(new_level) <= 3:
                settings["compression_level"] = int(new_level)
                print(f"结构体压缩级别已设置为: {new_level}")
                self.save_config()
            else:
                print("无效的选择")

        input("\n按Enter继续...")

    def _configure_xref_options(self):
        """配置XREF处理选项"""
        self._clear_screen()
        print("\n[XREF处理选项]\n")

        if "advanced_settings" not in self.config:
            self.config["advanced_settings"] = {}
        if "xref_settings" not in self.config["advanced_settings"]:
            self.config["advanced_settings"]["xref_settings"] = {}

        settings = self.config["advanced_settings"]["xref_settings"]

        print("XREF处理选项:")
        print(f"1. XREF压缩级别: {settings.get('compression_level', 2)}")
        print(f"2. 合并连续XREF: {'是' if settings.get('merge_consecutive', True) else '否'}")
        print(f"3. 简化XREF格式: {'是' if settings.get('simplify_format', True) else '否'}")
        print("4. 返回上级菜单")

        choice = input("\n选择要修改的选项: ")

        if choice == "1":
            current = settings.get("compression_level", 2)
            print("\nXREF压缩级别:")
            print("1 - 轻度 (基本合并)")
            print("2 - 中度 (压缩格式)")
            print("3 - 高度 (最小化表示)")

            new_level = input(f"选择新的压缩级别 [当前: {current}]: ").strip()
            if new_level.isdigit() and 1 <= int(new_level) <= 3:
                settings["compression_level"] = int(new_level)
                print(f"XREF压缩级别已设置为: {new_level}")
                self.save_config()
            else:
                print("无效的选择")
        elif choice == "2":
            current = settings.get("merge_consecutive", True)
            settings["merge_consecutive"] = not current
            print(f"合并连续XREF已{'禁用' if current else '启用'}")
            self.save_config()
        elif choice == "3":
            current = settings.get("simplify_format", True)
            settings["simplify_format"] = not current
            print(f"简化XREF格式已{'禁用' if current else '启用'}")
            self.save_config()

        input("\n按Enter继续...")

    def _configure_data_definition_options(self):
        """配置数据定义优化选项"""
        self._clear_screen()
        print("\n[数据定义优化选项]\n")

        if "advanced_settings" not in self.config:
            self.config["advanced_settings"] = {}
        if "data_settings" not in self.config["advanced_settings"]:
            self.config["advanced_settings"]["data_settings"] = {}

        settings = self.config["advanced_settings"]["data_settings"]

        print("数据定义优化选项:")
        print(f"1. 字符串压缩级别: {settings.get('string_compression', 2)}")
        print(f"2. 优化ALIGN指令: {'是' if settings.get('optimize_align', True) else '否'}")
        print(f"3. 合并重复数据: {'是' if settings.get('merge_repeated', True) else '否'}")
        print("4. 返回上级菜单")

        choice = input("\n选择要修改的选项: ")

        if choice == "1":
            current = settings.get("string_compression", 2)
            print("\n字符串压缩级别:")
            print("1 - 轻度 (基本格式优化)")
            print("2 - 中度 (合并ALIGN)")
            print("3 - 高度 (最小化表示)")

            new_level = input(f"选择新的压缩级别 [当前: {current}]: ").strip()
            if new_level.isdigit() and 1 <= int(new_level) <= 3:
                settings["string_compression"] = int(new_level)
                print(f"字符串压缩级别已设置为: {new_level}")
                self.save_config()
            else:
                print("无效的选择")
        elif choice == "2":
            current = settings.get("optimize_align", True)
            settings["optimize_align"] = not current
            print(f"优化ALIGN指令已{'禁用' if current else '启用'}")
            self.save_config()
        elif choice == "3":
            current = settings.get("merge_repeated", True)
            settings["merge_repeated"] = not current
            print(f"合并重复数据已{'禁用' if current else '启用'}")
            self.save_config()

        input("\n按Enter继续...")

    def show_recent_files(self):
        """显示最近处理的文件"""
        self._clear_screen()
        print("\n[最近处理的文件]\n")

        if not self.config["recent_files"]:
            print("没有最近处理的文件记录")
            input("\n按Enter继续...")
            return

        print("最近处理的文件:")
        for i, f in enumerate(self.config["recent_files"]):
            print(f"{i + 1}. {f}")

        if "recent_dirs" in self.config and self.config["recent_dirs"]:
            print("\n最近处理的目录:")
            for i, d in enumerate(self.config["recent_dirs"]):
                print(f"{i + 1}. {d}")

        choice = input("\n选择文件重新优化 (0=返回): ").strip()

        if choice == "0":
            return

        if choice.isdigit() and 1 <= int(choice) <= len(self.config["recent_files"]):
            filepath = self.config["recent_files"][int(choice) - 1]

            if os.path.exists(filepath):
                self._clear_screen()
                print(f"已选择文件: {filepath}")

                output_path = input(f"输出文件路径 [默认: {os.path.splitext(filepath)[0]}_optimized.asm]: ").strip()
                if not output_path:
                    output_path = f"{os.path.splitext(filepath)[0]}_optimized.asm"

                self._display_presets()
                preset = input(f"选择优化预设 [默认: {self.config['preset']}]: ").strip()
                if not preset:
                    preset = self.config["preset"]

                print("\n正在优化，请稍候...")

                # 选择配置
                if preset in OPTIMIZATION_PRESETS:
                    config = OPTIMIZATION_PRESETS[preset].copy()
                elif preset in self.config.get("custom_presets", {}):
                    config = self.config["custom_presets"][preset].copy()
                else:
                    config = OPTIMIZATION_PRESETS[self.config["preset"]].copy()

                optimizer = AsmOptimizerCore(preset, config)
                result = optimizer.optimize_file(filepath, output_path)

                if "error" in result:
                    print(f"出错: {result['error']}")
                else:
                    print("\n优化完成!")
                    print(f"原始大小: {format_size(result['original_size'])}")
                    print(f"优化后大小: {format_size(result['optimized_size'])}")
                    print(f"减小比例: {result['reduction_percent']:.2f}%")
            else:
                print(f"错误: 文件'{filepath}'不存在")
        else:
            print("无效的选择")

        input("\n按Enter继续...")

    def batch_process(self):
        """批量处理模式 - 拖放.asm文件"""
        self._clear_screen()
        print("\n[批量处理模式]\n")
        print("此模式允许您将多个.asm文件直接拖放到Termux窗口进行处理")
        print("用法: 将.asm文件拖放到此窗口，然后按Enter\n")

        paths = input("拖放文件或输入路径 (多个文件用空格分隔): ").strip()
        if not paths:
            return

        file_paths = paths.split()
        valid_files = []

        for path in file_paths:
            path = path.strip("\"'")  # 移除可能的引号
            if os.path.exists(path):
                if os.path.isfile(path) and path.endswith(".asm"):
                    valid_files.append(path)
                elif os.path.isdir(path):
                    for root, dirs, files in os.walk(path):
                        for file in files:
                            if file.endswith(".asm"):
                                valid_files.append(os.path.join(root, file))

        if not valid_files:
            print("没有找到有效的.asm文件")
            input("\n按Enter继续...")
            return

        print(f"\n找到 {len(valid_files)} 个.asm文件")

        self._display_presets()
        preset = input(f"选择优化预设 [默认: {self.config['preset']}]: ").strip()
        if not preset:
            preset = self.config["preset"]

        optimize_in_place = input("是否原地优化文件? (y/n) [默认: n]: ").strip().lower() == "y"

        if not optimize_in_place:
            output_dir = input("输出目录 [默认: ./optimized]: ").strip()
            if not output_dir:
                output_dir = "./optimized"

            if not os.path.exists(output_dir):
                os.makedirs(output_dir)

        print("\n开始批量处理...")

        # 选择配置
        if preset in OPTIMIZATION_PRESETS:
            config = OPTIMIZATION_PRESETS[preset].copy()
        elif preset in self.config.get("custom_presets", {}):
            config = self.config["custom_presets"][preset].copy()
        else:
            config = OPTIMIZATION_PRESETS[self.config["preset"]].copy()

        files_processed = 0
        total_reduction = 0
        total_original_size = 0
        total_optimized_size = 0

        for filepath in valid_files:
            if optimize_in_place:
                output_path = filepath
                backup_path = f"{filepath}.bak"
                if not os.path.exists(backup_path):
                    os.rename(filepath, backup_path)
                    filepath = backup_path
            else:
                rel_path = os.path.basename(filepath)
                output_path = os.path.join(output_dir, rel_path)

            print(f"处理: {os.path.basename(filepath)}")
            optimizer = AsmOptimizerCore(preset, config)
            result = optimizer.optimize_file(filepath, output_path)

            if "error" not in result:
                files_processed += 1
                current_reduction = result["reduction_percent"]
                total_reduction += current_reduction
                total_original_size += result["original_size"]
                total_optimized_size += result["optimized_size"]
                print(f"  减小: {current_reduction:.2f}%")

        if files_processed > 0:
            avg_reduction = total_reduction / files_processed
            print(f"\n已处理 {files_processed} 个文件")
            print(f"平均减小比例: {avg_reduction:.2f}%")
            print(f"总原始大小: {format_size(total_original_size)}")
            print(f"总优化大小: {format_size(total_optimized_size)}")
            print(f"总节省: {format_size(total_original_size - total_optimized_size)}")

            if optimize_in_place:
                print("\n注意: 原文件已备份为.bak文件")
            else:
                print(f"\n优化后的文件已保存到: {output_dir}")
        else:
            print("没有成功处理任何文件")

        input("\n按Enter继续...")

    def analyze_asm_file(self):
        """分析ASM文件结构"""
        self._clear_screen()
        print("\n[分析.asm文件结构]\n")

        if self.config["recent_files"]:
            print("最近文件:")
            for i, f in enumerate(self.config["recent_files"][:5]):
                print(f"{i + 1}. {f}")
            print("r. 输入新路径")

            choice = input("\n选择文件或输入'r': ")

            if choice.isdigit() and 1 <= int(choice) <= min(5, len(self.config["recent_files"])):
                filepath = self.config["recent_files"][int(choice) - 1]
            else:
                filepath = input("输入.asm文件路径: ").strip()
        else:
            filepath = input("输入.asm文件路径: ").strip()

        if not os.path.exists(filepath):
            print(f"错误: 文件'{filepath}'不存在")
            input("按Enter继续...")
            return

        print(f"\n正在分析文件: {filepath}")

        # 创建优化器来分析文件
        optimizer = AsmOptimizerCore()

        # 检测文件类型
        optimizer._detect_file_type(filepath)

        # 读取文件内容
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()

        # 分析文件特征
        from core import AdaptiveOptimizer
        adaptive_optimizer = AdaptiveOptimizer()
        features = adaptive_optimizer._analyze_file_features(content)

        # 显示分析报告
        self._clear_screen()
        print("\n┌──────────────────────────────────────┐")
        print("│             ASM文件分析报告            │")
        print("└──────────────────────────────────────┘\n")

        print(f"文件名: {os.path.basename(filepath)}")
        print(f"文件大小: {format_size(os.path.getsize(filepath))}")

        if optimizer.stats["is_elf_binary"]:
            print("\n文件类型: ELF二进制反汇编")
        elif features["has_cpp_features"]:
            print("\n文件类型: C++应用程序")
        else:
            print("\n文件类型: 普通汇编代码")

        print(f"\n指令集: {features['arch']}")
        print(f"代码复杂度: {features['complexity'] * 100:.1f}%")
        print(f"注释比例: {features['comment_ratio'] * 100:.1f}%")

        # 显示结构统计
        print(f"\n子例程数量: {features['function_count']}")
        print(f"结构体数量: {features['struct_count']}")
        print(f"段数量: {features['section_count']}")
        print(f"XREF数量: {features['xref_count']}")

        # 显示指令统计
        print(f"\n标签数量: {features['label_count']}")
        print(f"跳转指令: {features['jump_count']}")
        print(f"调用指令: {features['call_count']}")
        print(f"内存操作: {features['memory_count']}")
        print(f"数据定义: {features['data_count']}")

        # 优化建议
        print("\n优化建议:")

        # 根据文件类型推荐预设
        if optimizer.stats["is_elf_binary"]:
            print("  - 推荐使用'elf'预设以获得最佳ELF优化")
        elif features["has_cpp_features"]:
            print("  - 推荐使用'cpp'预设以获得最佳C++优化")
        elif features["complexity"] > 0.7:
            print("  - 文件复杂度较高，推荐使用'balanced'预设保持代码可读性")
        elif features["comment_ratio"] > 0.4:
            print("  - 注释比例较高，推荐使用'extreme'预设以显著减小文件大小")
        else:
            print("  - 推荐使用'balanced'预设以平衡压缩与可读性")

        # 预计优化效果
        estimate_reduction = 0.0

        # 基础减小
        estimate_reduction += 0.1  # 基础格式优化

        # 根据注释比例
        estimate_reduction += features["comment_ratio"] * 0.8

        # 根据结构体数量
        if features["struct_count"] > 0:
            estimate_reduction += min(0.08, features["struct_count"] / 1000 * 0.08)

        # 根据XREF数量
        if features["xref_count"] > 0:
            estimate_reduction += min(0.1, features["xref_count"] / 1000 * 0.1)

        # 确保预估在合理范围内
        estimate_reduction = min(0.85, max(0.2, estimate_reduction))

        print(f"\n预计可优化空间: {estimate_reduction * 100:.1f}%")
        print(f"预计优化后大小: {format_size(int(os.path.getsize(filepath) * (1 - estimate_reduction)))}")

        # 更新最近文件列表
        self.update_recent_files(filepath)

        input("\n按Enter继续...")

    def analyze_optimized_file(self, filepath):
        """分析优化后的文件"""
        if not os.path.exists(filepath):
            print(f"错误: 文件'{filepath}'不存在")
            return

        print(f"\n正在分析文件: {filepath}")

        # 创建优化器来分析文件
        optimizer = AsmOptimizerCore()

        # 检测文件类型
        optimizer._detect_file_type(filepath)

        # 读取文件内容
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()

        # 分析文件特征
        from core import AdaptiveOptimizer
        adaptive_optimizer = AdaptiveOptimizer()
        features = adaptive_optimizer._analyze_file_features(content)

        # 显示分析报告
        print("\n┌──────────────────────────────────────┐")
        print("│          优化后文件分析报告            │")
        print("└──────────────────────────────────────┘\n")

        print(f"文件名: {os.path.basename(filepath)}")
        print(f"文件大小: {format_size(os.path.getsize(filepath))}")

        if optimizer.stats["is_elf_binary"]:
            print("\n文件类型: ELF二进制反汇编")
        elif features["has_cpp_features"]:
            print("\n文件类型: C++应用程序")
        else:
            print("\n文件类型: 普通汇编代码")

        print(f"\n指令集: {features['arch']}")
        print(f"代码复杂度: {features['complexity'] * 100:.1f}%")
        print(f"注释比例: {features['comment_ratio'] * 100:.1f}%")

        # 显示结构统计
        print(f"\n子例程数量: {features['function_count']}")
        print(f"结构体数量: {features['struct_count']}")
        print(f"段数量: {features['section_count']}")
        print(f"XREF数量: {features['xref_count']}")

    def reoptimize_file(self, filepath, last_output):
        """使用不同预设重新优化文件"""
        self._clear_screen()
        print("\n[使用不同预设重新优化]\n")

        # 显示预设选项
        self._display_presets()

        preset = input("\n选择新的优化预设: ").strip()
        if not preset or (preset not in OPTIMIZATION_PRESETS and preset not in self.config.get("custom_presets", {})):
            print(f"预设'{preset}'不存在，取消操作")
            return

        new_output = input(f"输出文件路径 [默认: {os.path.splitext(filepath)[0]}_{preset}.asm]: ").strip()
        if not new_output:
            new_output = f"{os.path.splitext(filepath)[0]}_{preset}.asm"

        print("\n正在优化，请稍候...")

        # 选择配置
        if preset in OPTIMIZATION_PRESETS:
            config = OPTIMIZATION_PRESETS[preset].copy()
        elif preset in self.config.get("custom_presets", {}):
            config = self.config["custom_presets"][preset].copy()
        else:
            config = OPTIMIZATION_PRESETS[self.config["preset"]].copy()

        optimizer = AsmOptimizerCore(preset, config)
        result = optimizer.optimize_file(filepath, new_output)

        if "error" in result:
            print(f"出错: {result['error']}")
        else:
            print("\n优化完成!")
            print(f"原始大小: {format_size(result['original_size'])}")
            print(f"优化后大小: {format_size(result['optimized_size'])}")
            print(f"减小比例: {result['reduction_percent']:.2f}%")

            # 与上一个优化结果比较
            if os.path.exists(last_output):
                last_size = os.path.getsize(last_output)
                new_size = result["optimized_size"]
                size_diff = new_size - last_size
                diff_percent = (size_diff / last_size) * 100 if last_size > 0 else 0

                print("\n与上一个优化结果比较:")
                print(f"  上一个优化大小: {format_size(last_size)}")
                print(f"  新优化大小: {format_size(new_size)}")

                if size_diff < 0:
                    print(f"  额外减小: {format_size(abs(size_diff))} ({abs(diff_percent):.2f}%)")
                elif size_diff > 0:
                    print(f"  增加: {format_size(size_diff)} ({diff_percent:.2f}%)")
                else:
                    print("  大小相同")

    def compare_files(self, original, optimized):
        """比较优化前后的文件"""
        if not os.path.exists(original) or not os.path.exists(optimized):
            print("错误: 需比较的文件不存在")
            return

        print("\n正在比较文件...")

        original_size = os.path.getsize(original)
        optimized_size = os.path.getsize(optimized)

        saved_bytes = original_size - optimized_size
        saved_percent = (saved_bytes / original_size) * 100 if original_size > 0 else 0

        print("\n文件大小比较:")
        print(f"  原始文件: {os.path.basename(original)}")
        print(f"  大小: {format_size(original_size)}")
        print(f"  优化文件: {os.path.basename(optimized)}")
        print(f"  大小: {format_size(optimized_size)}")
        print(f"  节省: {format_size(saved_bytes)} ({saved_percent:.2f}%)")

        # 读取文件内容进行更详细的比较
        try:
            with open(original, "r", encoding="utf-8", errors="replace") as f:
                original_content = f.read()
            with open(optimized, "r", encoding="utf-8", errors="replace") as f:
                optimized_content = f.read()

            # 行数比较
            original_lines = original_content.count("\n") + 1
            optimized_lines = optimized_content.count("\n") + 1
            line_reduction = (original_lines - optimized_lines) / original_lines * 100 if original_lines > 0 else 0

            print("\n内容比较:")
            print(f"  原始行数: {original_lines:,}")
            print(f"  优化后行数: {optimized_lines:,}")
            print(f"  行数减少: {original_lines - optimized_lines:,} ({line_reduction:.2f}%)")

            # 注释比较
            original_comments = sum(1 for line in original_content.split("\n") if line.strip().startswith(";"))
            optimized_comments = sum(1 for line in optimized_content.split("\n") if line.strip().startswith(";"))
            comment_reduction = (
                (original_comments - optimized_comments) / original_comments * 100 if original_comments > 0 else 0
            )

            print(f"  原始注释行: {original_comments:,}")
            print(f"  优化后注释行: {optimized_comments:,}")
            print(f"  注释减少: {original_comments - optimized_comments:,} ({comment_reduction:.2f}%)")

            # 空行比较
            original_empty = sum(1 for line in original_content.split("\n") if not line.strip())
            optimized_empty = sum(1 for line in optimized_content.split("\n") if not line.strip())
            empty_reduction = (original_empty - optimized_empty) / original_empty * 100 if original_empty > 0 else 0

            print(f"  原始空行: {original_empty:,}")
            print(f"  优化后空行: {optimized_empty:,}")
            print(f"  空行减少: {original_empty - optimized_empty:,} ({empty_reduction:.2f}%)")

        except Exception as e:
            print(f"比较内容时出错: {str(e)}")

    def show_batch_statistics(self):
        """显示批处理详细统计"""
        if not self.batch_stats or not self.batch_stats["files"]:
            print("没有可用的批处理统计")
            return

        self._clear_screen()
        print("\n┌──────────────────────────────────────┐")
        print("│            批处理详细统计             │")
        print("└──────────────────────────────────────┘\n")

        stats = self.batch_stats

        print(f"处理文件总数: {len(stats['files'])}")
        print(f"总原始大小: {format_size(stats['total_original'])}")
        print(f"总优化大小: {format_size(stats['total_optimized'])}")

        saved = stats["total_original"] - stats["total_optimized"]
        saved_percent = (saved / stats["total_original"]) * 100 if stats["total_original"] > 0 else 0
        print(f"总节省: {format_size(saved)} ({saved_percent:.2f}%)")

        print(f"\nELF文件数量: {stats['elf_count']}")
        print(f"C++文件数量: {stats['cpp_count']}")
        print(f"ARM指令集文件: {stats['arm_count']}")
        print(f"Thumb指令集文件: {stats['thumb_count']}")

        # 计算性能分布
        reductions = [f["reduction"] for f in stats["files"]]
        reductions.sort()

        if reductions:
            min_reduction = min(reductions)
            max_reduction = max(reductions)
            median = reductions[len(reductions) // 2]
            avg = sum(reductions) / len(reductions)

            print("\n优化性能分析:")
            print(f"  最小减小率: {min_reduction:.2f}%")
            print(f"  最大减小率: {max_reduction:.2f}%")
            print(f"  中位数减小率: {median:.2f}%")
            print(f"  平均减小率: {avg:.2f}%")

        # 显示TOP 5最佳优化文件
        if len(stats["files"]) > 0:
            print("\nTOP 5优化效果最好的文件:")
            top_files = sorted(stats["files"], key=lambda x: x["reduction"], reverse=True)[:5]
            for i, f in enumerate(top_files):
                print(f"  {i + 1}. {f['path']}: 减小 {f['reduction']:.2f}%")

        # 显示TOP 5最大文件
        if len(stats["files"]) > 0:
            print("\nTOP 5最大的文件:")
            largest_files = sorted(stats["files"], key=lambda x: x["original_size"], reverse=True)[:5]
            for i, f in enumerate(largest_files):
                print(f"  {i + 1}. {f['path']}: {format_size(f['original_size'])}")

    def export_batch_report(self, input_dir, output_dir):
        """导出批处理报告到文件"""
        if not self.batch_stats or not self.batch_stats["files"]:
            print("没有可用的批处理统计")
            return

        report_path = input("报告文件路径 [默认: batch_report.txt]: ").strip()
        if not report_path:
            report_path = "batch_report.txt"

        try:
            with open(report_path, "w", encoding="utf-8") as f:
                f.write("=================================================\n")
                f.write("           IDA汇编优化器批处理报告\n")
                f.write("=================================================\n\n")

                f.write(f"输入目录: {input_dir}\n")
                f.write(f"输出目录: {output_dir}\n")
                f.write(f"处理时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")

                stats = self.batch_stats

                f.write(f"处理文件总数: {len(stats['files'])}\n")
                f.write(f"总原始大小: {format_size(stats['total_original'])}\n")
                f.write(f"总优化大小: {format_size(stats['total_optimized'])}\n")

                saved = stats["total_original"] - stats["total_optimized"]
                saved_percent = (saved / stats["total_original"]) * 100 if stats["total_original"] > 0 else 0
                f.write(f"总节省: {format_size(saved)} ({saved_percent:.2f}%)\n\n")

                f.write(f"ELF文件数量: {stats['elf_count']}\n")
                f.write(f"C++文件数量: {stats['cpp_count']}\n")
                f.write(f"ARM指令集文件: {stats['arm_count']}\n")
                f.write(f"Thumb指令集文件: {stats['thumb_count']}\n\n")

                # 计算性能分布
                reductions = [f["reduction"] for f in stats["files"]]
                reductions.sort()

                if reductions:
                    min_reduction = min(reductions)
                    max_reduction = max(reductions)
                    median = reductions[len(reductions) // 2]
                    avg = sum(reductions) / len(reductions)

                    f.write("优化性能分析:\n")
                    f.write(f"  最小减小率: {min_reduction:.2f}%\n")
                    f.write(f"  最大减小率: {max_reduction:.2f}%\n")
                    f.write(f"  中位数减小率: {median:.2f}%\n")
                    f.write(f"  平均减小率: {avg:.2f}%\n\n")

                # 详细文件列表
                f.write("处理文件详情:\n")
                f.write("-------------------------------------------------\n")
                f.write("文件路径                  | 原始大小  | 优化大小  | 减小率\n")
                f.write("-------------------------------------------------\n")

                for file_info in stats["files"]:
                    path = file_info["path"]
                    # 截断过长的路径
                    if len(path) > 25:
                        path = "..." + path[-22:]

                    f.write(
                        f"{path.ljust(25)} | {format_size(file_info['original_size']).ljust(8)} | {format_size(file_info['optimized_size']).ljust(8)} | {file_info['reduction']:.2f}%\n"
                    )

                f.write("-------------------------------------------------\n")

            print(f"报告已保存到: {report_path}")
        except Exception as e:
            print(f"导出报告时出错: {str(e)}")
