#include <iostream>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <limits.h>
#include <vector>
#include <algorithm>

// 内联颜色定义
#define COLOR(code) "\033[" code "m"
#define RED COLOR("0;31")
#define GREEN COLOR("0;32")
#define YELLOW COLOR("0;33")
#define NC COLOR("0")

// 批量权限设置（使用fchmodat提升性能）
void setPermissionsBatch(const char* path) {
    std::vector<std::string> paths;
    paths.push_back(path);
    
    size_t index = 0;
    while (index < paths.size()) {
        const char* current_path = paths[index++].c_str();
        
        // 设置当前目录权限
        chmod(current_path, 0777);
        
        DIR* dir = opendir(current_path);
        if (!dir) continue;
        
        char fullpath[PATH_MAX];
        struct dirent* entry;
        while ((entry = readdir(dir))) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) 
                continue;

            snprintf(fullpath, sizeof(fullpath), "%s/%s", current_path, entry->d_name);
            
            // 使用fchmodat替代chmod（性能提升）
            if (fchmodat(AT_FDCWD, fullpath, 0777, 0) == 0) {
                if (entry->d_type == DT_DIR) {
                    paths.push_back(fullpath);
                }
            }
        }
        closedir(dir);
    }
}

// 统计bin目录下的文件数量（优化版）
size_t countFilesInBin(const char* bin_dir) {
    size_t count = 0;
    DIR* dir = opendir(bin_dir);
    if (!dir) return 0;
    
    struct dirent* entry;
    while ((entry = readdir(dir))) {
        if (entry->d_type == DT_REG) { // 只统计普通文件
            count++;
            if (count >= 100) break; // 超过100时提前退出
        }
    }
    closedir(dir);
    return count;
}

// 增强版PATH检查（检查所有文件）
bool checkPathContainsAllFiles(const char* home) {
    const char* path_env = getenv("PATH");
    if (!path_env) return false;

    std::string bin_path = std::string(home) + "/bin";
    const char* path = path_env;
    
    while (*path) {
        const char* colon = strchr(path, ':');
        size_t segment_len = colon ? (colon - path) : strlen(path);
        
        if (segment_len == bin_path.length() && 
            strncmp(path, bin_path.c_str(), segment_len) == 0) {
            return true;
        }
        
        path = colon ? colon + 1 : path + segment_len;
    }
    return false;
}

// 安全添加PATH配置（针对文件数量优化）
void safeAddToBashrc(const char* home, size_t file_count) {
    char bashrc_path[PATH_MAX];
    snprintf(bashrc_path, sizeof(bashrc_path), "%s/.bashrc", home);
    
    // 检查是否已存在配置
    int check_fd = open(bashrc_path, O_RDONLY);
    if (check_fd != -1) {
        char buffer[4096];
        ssize_t bytes_read = read(check_fd, buffer, sizeof(buffer)-1);
        close(check_fd);
        
        if (bytes_read > 0) {
            buffer[bytes_read] = '\0';
            if (strstr(buffer, "$HOME/bin") != nullptr) {
                std::cout << GREEN "配置已存在于 .bashrc" NC << std::endl;
                return;
            }
        }
    }
    
    // 添加新配置
    int fd = open(bashrc_path, O_WRONLY|O_APPEND);
    if (fd != -1) {
        const char* config = "\n# 添加用户 bin 目录到 PATH [由程序添加]\nexport PATH=\"$PATH:$HOME/bin\"\n";
        write(fd, config, strlen(config));
        close(fd);
        
        if (file_count < 100) {
            std::cout << GREEN "✓ 配置添加成功 (检测到 " << file_count 
                      << " 个文件，已优化处理)" NC << std::endl;
        } else {
            std::cout << GREEN "✓ 配置添加成功 (检测到 " << file_count 
                      << " 个文件)" NC << std::endl;
        }
    }
}

int main() {
    const char* home = getenv("HOME");
    if (!home) {
        std::cerr << RED "✗ 无法获取HOME目录" NC << std::endl;
        return 1;
    }

    char bin_dir[PATH_MAX];
    snprintf(bin_dir, sizeof(bin_dir), "%s/bin", home);

    std::cout << YELLOW "=== 开始设置用户 bin 目录 ===" NC << std::endl;

    // 创建目录（使用更高效的模式）
    mkdir(bin_dir, 0777);

    // 批量权限设置
    std::cout << YELLOW "递归设置 777 权限: " << bin_dir << NC << std::endl;
    setPermissionsBatch(bin_dir);
    std::cout << GREEN "✓ 权限设置成功 (777)" NC << std::endl;

    // 统计文件数量
    size_t file_count = countFilesInBin(bin_dir);
    std::cout << YELLOW "检测到 bin 目录中有 " << file_count << " 个文件" NC << std::endl;

    // 增强版PATH检查
    if (checkPathContainsAllFiles(home)) {
        std::cout << GREEN "~/bin 已在 PATH 环境变量中" NC << std::endl;
    } else {
        safeAddToBashrc(home, file_count);
    }

    // 结果展示
    std::cout << "\n" YELLOW "=== 操作结果 ===" NC << std::endl
              << GREEN "✓ 操作完成！" NC << std::endl
              << YELLOW "目录权限信息:" NC << std::endl;
    
    // 使用vfork+exec优化进程创建
    pid_t pid = vfork();
    if (pid == 0) {
        execlp("ls", "ls", "-ld", bin_dir, nullptr);
        _exit(1);
    } else if (pid > 0) {
        wait(nullptr);
    }

    std::cout << YELLOW "\n当前 PATH 中包含以下 bin 目录:" NC << std::endl;
    pid = vfork();
    if (pid == 0) {
        execlp("sh", "sh", "-c", "echo \"$PATH\" | tr ':' '\\n' | grep -n 'bin'", nullptr);
        _exit(1);
    } else if (pid > 0) {
        wait(nullptr);
    }

    return 0;
}
