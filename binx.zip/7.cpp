#include <iostream>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <limits.h>
#include <errno.h>

#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define NC "\033[0m"

// 简化的单次遍历权限设置（针对小规模场景优化）
static void setPermissionsSimple(const char* path) {
    chmod(path, 0777);  // 777权限
    
    DIR* dir = opendir(path);
    if (!dir) return;
    
    int dir_fd = dirfd(dir);
    struct dirent* entry;
    
    while ((entry = readdir(dir))) {
        if (entry->d_name[0] == '.') continue;  // 快速跳过隐藏文件
        
        // 使用fchmodat避免拼接路径
        fchmodat(dir_fd, entry->d_name, 0777, 0);
        
        if (entry->d_type == DT_DIR) {
            char subpath[PATH_MAX];
            snprintf(subpath, sizeof(subpath), "%s/%s", path, entry->d_name);
            setPermissionsSimple(subpath);  // 递归处理子目录
        }
    }
    closedir(dir);
}

// 一次性检查PATH并追加配置
static bool ensurePathConfig(const char* home) {
    char bin_path[PATH_MAX];
    snprintf(bin_path, sizeof(bin_path), "%s/bin", home);
    
    // 快速检查PATH
    const char* path_env = getenv("PATH");
    if (path_env && strstr(path_env, bin_path)) {
        return true;  // 已存在
    }
    
    // 检查.bashrc是否已配置
    char bashrc_path[PATH_MAX];
    snprintf(bashrc_path, sizeof(bashrc_path), "%s/.bashrc", home);
    
    FILE* read_file = fopen(bashrc_path, "r");
    if (read_file) {
        char line[512];
        while (fgets(line, sizeof(line), read_file)) {
            if (strstr(line, "$HOME/bin") || strstr(line, "~/bin")) {
                fclose(read_file);
                return true;  // 配置已存在
            }
        }
        fclose(read_file);
    }
    
    // 追加配置
    FILE* append_file = fopen(bashrc_path, "a");
    if (!append_file) return false;
    
    fprintf(append_file, "\n# User bin directory\nexport PATH=\"$HOME/bin:$PATH\"\n");
    fclose(append_file);
    return false;
}

int main() {
    const char* home = getenv("HOME");
    if (!home) {
        std::cerr << RED "✗ HOME环境变量未设置" << NC << std::endl;
        return 1;
    }
    
    char bin_dir[PATH_MAX];
    snprintf(bin_dir, sizeof(bin_dir), "%s/bin", home);
    
    std::cout << YELLOW "=== ~/bin 目录初始化 ===" << NC << std::endl;
    
    // 创建目录
    if (mkdir(bin_dir, 0777) == -1) {
        if (errno != EEXIST) {
            std::cerr << RED "✗ 创建失败: " << strerror(errno) << NC << std::endl;
            return 1;
        }
    } else {
        std::cout << GREEN "✓ 目录创建成功" << NC << std::endl;
    }
    
    // 设置权限
    setPermissionsSimple(bin_dir);
    std::cout << GREEN "✓ 权限设置完成" << NC << std::endl;
    
    // 配置PATH
    bool already_configured = ensurePathConfig(home);
    if (already_configured) {
        std::cout << GREEN "✓ PATH已配置" << NC << std::endl;
    } else {
        std::cout << GREEN "✓ 配置已添加到.bashrc" << NC << std::endl;
        std::cout << YELLOW "运行生效: source ~/.bashrc" << NC << std::endl;
    }
    
    return 0;
}
