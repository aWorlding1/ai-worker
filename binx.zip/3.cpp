#include <iostream>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <sys/wait.h>  // 添加wait头文件
#include <limits.h>

// 内联颜色定义
#define COLOR(code) "\033[" code "m"
#define RED COLOR("0;31")
#define GREEN COLOR("0;32")
#define YELLOW COLOR("0;33")
#define NC COLOR("0")

void setPermissionsSimple(const char* path) {
    DIR* dir = opendir(path);
    if (!dir) return;

    chmod(path, 0777);
    
    char fullpath[PATH_MAX];
    struct dirent* entry;
    while ((entry = readdir(dir))) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) 
            continue;

        snprintf(fullpath, sizeof(fullpath), "%s/%s", path, entry->d_name);
        chmod(fullpath, 0777);
        
        if (entry->d_type == DT_DIR) {
            DIR* subdir = opendir(fullpath);
            if (subdir) {
                chmod(fullpath, 0777);
                closedir(subdir);
            }
        }
    }
    closedir(dir);
}

bool checkPathContainsBin(const char* home) {
    const char* path = getenv("PATH");
    if (!path) return false;

    const char* needle = "/bin";
    size_t home_len = strlen(home);
    size_t needle_len = strlen(needle);

    while ((path = strstr(path, home))) {
        if ((path == getenv("PATH") || *(path-1) == ':') &&
            strncmp(path + home_len, needle, needle_len) == 0 &&
            (path[home_len + needle_len] == '\0' || 
             path[home_len + needle_len] == ':')) {
            return true;
        }
        path += home_len;
    }
    return false;
}

int main() {
    const char* home = getenv("HOME");
    if (!home) {
        std::cerr << RED "✗ 无法获取HOME目录" NC << std::endl;
        return 1;
    }

    char bin_dir[PATH_MAX];
    snprintf(bin_dir, sizeof(bin_dir), "%s/bin", home);

    std::cout << YELLOW "=== 开始设置用户 bin 目录 ===" NC << std::endl;

    mkdir(bin_dir, 0777);

    std::cout << YELLOW "递归设置 777 权限: " << bin_dir << NC << std::endl;
    setPermissionsSimple(bin_dir);
    std::cout << GREEN "✓ 权限设置成功 (777)" NC << std::endl;

    if (checkPathContainsBin(home)) {
        std::cout << GREEN "~/bin 已在 PATH 环境变量中" NC << std::endl;
    } else {
        char bashrc_path[PATH_MAX];
        snprintf(bashrc_path, sizeof(bashrc_path), "%s/.bashrc", home);
        
        int fd = open(bashrc_path, O_WRONLY|O_APPEND);
        if (fd != -1) {
            const char* config = "\n# 添加用户 bin 目录到 PATH [由程序添加]\nexport PATH=\"$PATH:$HOME/bin\"\n";
            write(fd, config, strlen(config));
            close(fd);
            std::cout << GREEN "✓ 配置添加成功" NC << std::endl;
        }
    }

    std::cout << "\n" YELLOW "=== 操作结果 ===" NC << std::endl
              << GREEN "✓ 操作完成！" NC << std::endl
              << YELLOW "目录权限信息:" NC << std::endl;
    
    pid_t pid = fork();
    if (pid == 0) {
        execlp("ls", "ls", "-ld", bin_dir, nullptr);
        _exit(1);
    } else if (pid > 0) {
        wait(nullptr);
    }

    std::cout << YELLOW "\n当前 PATH 中包含以下 bin 目录:" NC << std::endl;
    pid = fork();
    if (pid == 0) {
        execlp("sh", "sh", "-c", "echo \"$PATH\" | tr ':' '\\n' | grep -n 'bin'", nullptr);
        _exit(1);
    } else if (pid > 0) {
        wait(nullptr);
    }

    return 0;
}
