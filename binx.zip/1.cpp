#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <dirent.h>
#include <stdlib.h>

using namespace std;

// 颜色定义（完全保留Bash的显示风格）
const string RED = "\033[0;31m";
const string GREEN = "\033[0;32m";
const string YELLOW = "\033[0;33m";
const string NC = "\033[0m";

// 递归设置777权限（完全对应Bash的`chmod -R 777`）
void setRecursive777(const string &path) {
    DIR *dir = opendir(path.c_str());
    if (!dir) {
        perror(("opendir " + path).c_str());
        exit(1);
    }

    chmod(path.c_str(), 0777); // 当前目录权限

    dirent *entry;
    while ((entry = readdir(dir))) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) 
            continue;

        string fullpath = path + "/" + entry->d_name;
        
        struct stat st;
        if (lstat(fullpath.c_str(), &st) != 0) {
            perror(("lstat " + fullpath).c_str());
            continue;
        }

        if (S_ISDIR(st.st_mode)) {
            setRecursive777(fullpath); // 递归子目录
        }
        chmod(fullpath.c_str(), 0777); // 强制设置权限
    }
    closedir(dir);
}

// 检查PATH是否包含$HOME/bin（完全对应Bash的`:$PATH:`匹配逻辑）
bool isInPath(const string &home) {
    const char *env_path = getenv("PATH");
    if (!env_path) return false;
    return string(env_path).find(home + "/bin") != string::npos;
}

// 更新.bashrc（完全保留Bash的追加行为）
void updateBashrc(const string &home) {
    string bashrc = home + "/.bashrc";
    string line = "export PATH=\"$PATH:$HOME/bin\"";

    ifstream in(bashrc);
    string content((istreambuf_iterator<char>(in)), 
                  istreambuf_iterator<char>());

    if (content.find("$HOME/bin") != string::npos) {
        cout << GREEN << "配置已存在于 .bashrc" << NC << endl;
        return;
    }

    ofstream out(bashrc, ios::app);
    out << "\n# 添加用户 bin 目录到 PATH [由程序添加]\n"
        << line << "\n";
    cout << GREEN << "✓ 配置添加成功" << NC << endl;
}

int main() {
    const char *home = getenv("HOME");
    if (!home) {
        cerr << RED << "✗ 无法获取HOME目录" << NC << endl;
        return 1;
    }

    string bin_dir = string(home) + "/bin";
    
    cout << YELLOW << "=== 开始设置用户 bin 目录 ===" << NC << endl;

    // 1. 创建目录（对应Bash的mkdir -p）
    mkdir(bin_dir.c_str(), 0777);

    // 2. 递归设置777权限（完全对应Bash的chmod -R 777）
    cout << YELLOW << "递归设置 777 权限: " << bin_dir << NC << endl;
    setRecursive777(bin_dir);
    cout << GREEN << "✓ 权限设置成功 (777)" << NC << endl;

    // 3. PATH处理（完全对应Bash的检查逻辑）
    if (isInPath(home)) {
        cout << GREEN << "~/bin 已在 PATH 环境变量中" << NC << endl;
    } else {
        updateBashrc(home);
    }

    // 4. 显示结果（完全保留Bash的输出格式）
    cout << "\n" << YELLOW << "=== 操作结果 ===" << NC << endl;
    cout << GREEN << "✓ 操作完成！" << NC << endl;
    
    cout << YELLOW << "目录权限信息:" << NC << endl;
    system(("ls -ld " + bin_dir).c_str());

    cout << YELLOW << "\n当前 PATH 中包含以下 bin 目录:" << NC << endl;
    system("echo \"$PATH\" | tr ':' '\\n' | grep -n 'bin'");
    
    return 0;
}
