#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <dirent.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

// 颜色定义（使用宏替换字符串常量）
#define RED "\033[0;31m"
#define GREEN "\033[0;32m"
#define YELLOW "\033[0;33m"
#define NC "\033[0m"

// 递归设置权限（非递归版，避免函数调用开销）
void setPermissions(const string &path) {
    vector<string> dirStack;
    dirStack.push_back(path);

    while (!dirStack.empty()) {
        string current = dirStack.back();
        dirStack.pop_back();

        chmod(current.c_str(), 0777);
        
        DIR *dir = opendir(current.c_str());
        if (!dir) continue;

        dirent *entry;
        while ((entry = readdir(dir))) {
            if (strcmp(entry->d_name, ".") == 0 || 
                strcmp(entry->d_name, "..") == 0) continue;

            string fullpath = current + "/" + entry->d_name;
            struct stat st;
            if (lstat(fullpath.c_str(), &st) == 0) {
                if (S_ISDIR(st.st_mode)) {
                    dirStack.push_back(fullpath);
                }
                chmod(fullpath.c_str(), 0777);
            }
        }
        closedir(dir);
    }
}

// 高效PATH检查（避免字符串拷贝）
bool isPathContainsBin(const char* home) {
    const char* env_path = getenv("PATH");
    if (!env_path) return false;

    string search_path = string(home) + "/bin";
    const char* p = env_path;
    
    while ((p = strstr(p, search_path.c_str())) != nullptr) {
        // 检查匹配是否在路径边界
        if ((p == env_path || *(p-1) == ':') && 
            (p[search_path.length()] == '\0' || 
             p[search_path.length()] == ':')) {
            return true;
        }
        p += search_path.length();
    }
    return false;
}

// 快速.bashrc更新（使用低级IO）
void updateShellConfig(const char* home) {
    string bashrc = string(home) + "/.bashrc";
    
    int fd = open(bashrc.c_str(), O_RDWR | O_APPEND);
    if (fd == -1) return;

    // 检查是否已存在
    char buf[4096];
    lseek(fd, 0, SEEK_SET);
    ssize_t n = read(fd, buf, sizeof(buf)-1);
    if (n > 0) {
        buf[n] = '\0';
        if (strstr(buf, "$HOME/bin") != nullptr) {
            cout << GREEN << "配置已存在于 .bashrc" << NC << endl;
            close(fd);
            return;
        }
    }

    const char* config = "\n# 添加用户 bin 目录到 PATH [由程序添加]\n"
                         "export PATH=\"$PATH:$HOME/bin\"\n";
    write(fd, config, strlen(config));
    close(fd);
    
    cout << GREEN << "✓ 配置添加成功" << NC << endl;
}

// 高效执行系统命令并捕获输出
void executeAndPrint(const char* cmd) {
    FILE* pipe = popen(cmd, "r");
    if (!pipe) return;

    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        cout << buffer;
    }
    pclose(pipe);
}

int main() {
    const char* home = getenv("HOME");
    if (!home) {
        cerr << RED << "✗ 无法获取HOME目录" << NC << endl;
        return 1;
    }

    string bin_dir = string(home) + "/bin";
    
    cout << YELLOW << "=== 开始设置用户 bin 目录 ===" << NC << endl;

    // 1. 创建目录（使用一次性系统调用）
    mkdir(bin_dir.c_str(), 0777);

    // 2. 设置权限（迭代替代递归）
    cout << YELLOW << "递归设置 777 权限: " << bin_dir << NC << endl;
    setPermissions(bin_dir);
    cout << GREEN << "✓ 权限设置成功 (777)" << NC << endl;

    // 3. PATH处理（高效检查）
    if (isPathContainsBin(home)) {
        cout << GREEN << "~/bin 已在 PATH 环境变量中" << NC << endl;
    } else {
        updateShellConfig(home);
    }

    // 4. 显示结果（保持原样输出）
    cout << "\n" << YELLOW << "=== 操作结果 ===" << NC << endl;
    cout << GREEN << "✓ 操作完成！" << NC << endl;
    
    cout << YELLOW << "目录权限信息:" << NC << endl;
    executeAndPrint(("ls -ld " + bin_dir).c_str());

    cout << YELLOW << "\n当前 PATH 中包含以下 bin 目录:" << NC << endl;
    executeAndPrint("echo \"$PATH\" | tr ':' '\\n' | grep -n 'bin'");
    
    return 0;
}
