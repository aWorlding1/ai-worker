#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <limits.h>
#include <cerrno>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <sys/mman.h>

// 使用ANSI颜色代码宏（确保每个颜色代码后重置）
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define NC "\033[0m"

// 完整消息定义（确保每个消息以换行符结束）
static const char MSG_HOME_FAIL[] = RED "错误：HOME环境变量未设置\n" NC;
static const char MSG_TITLE[] = YELLOW "=== ~/bin 目录初始化 ===\n" NC;
static const char MSG_MKDIR_FAIL[] = RED "错误：创建目录失败: ";
static const char MSG_DIR_CREATED[] = GREEN "成功：目录创建完成\n" NC;
static const char MSG_PERM_SET[] = GREEN "成功：权限设置完成\n" NC;
static const char MSG_PATH_OK[] = GREEN "提示：PATH已配置\n" NC;
static const char MSG_PATH_ADDED[] = GREEN "提示：配置已添加到.bashrc\n" NC;
static const char MSG_SOURCE_HINT[] = YELLOW "提示：请运行 source ~/.bashrc 使配置生效\n" NC;

// 安全写入函数（确保完整写入）
static void safe_write(int fd, const char* buf, size_t len) {
    while (len > 0) {
        ssize_t ret = write(fd, buf, len);
        if (ret <= 0) break;
        buf += ret;
        len -= ret;
    }
}

// 快速路径拼接
static void fast_path_join(char* dest, const char* dir, const char* file) {
    while (*dir) *dest++ = *dir++;
    *dest++ = '/';
    while (*file) *dest++ = *file++;
    *dest = '\0';
}

// 优化的目录权限设置
static void fast_set_perms(const char* path) {
    fchmodat(AT_FDCWD, path, 0777, 0);
    
    int dir_fd = open(path, O_RDONLY | O_DIRECTORY);
    if (dir_fd == -1) return;
    
    char* buffer = (char*)malloc(PATH_MAX);
    if (!buffer) {
        close(dir_fd);
        return;
    }
    
    DIR* dir = fdopendir(dir_fd);
    if (!dir) {
        free(buffer);
        close(dir_fd);
        return;
    }
    
    struct dirent* entry;
    while ((entry = readdir(dir))) {
        if (entry->d_name[0] == '.') continue;
        
        fchmodat(dir_fd, entry->d_name, 0777, 0);
        
        if (entry->d_type == DT_DIR) {
            fast_path_join(buffer, path, entry->d_name);
            fast_set_perms(buffer);
        }
    }
    
    free(buffer);
    closedir(dir);
}

// 检查PATH配置
static bool is_path_configured(const char* home) {
    const char* path_env = getenv("PATH");
    if (!path_env) return false;
    
    char search_str[32];
    int len = snprintf(search_str, sizeof(search_str), "%s/bin:", home);
    if (len >= (int)sizeof(search_str)) return false;
    
    const char* p = path_env;
    while (*p) {
        if (strncmp(p, search_str, len) == 0) return true;
        while (*p && *p != ':') ++p;
        if (*p == ':') ++p;
    }
    
    return false;
}

// 检查bashrc配置
static bool is_bashrc_configured(const char* home) {
    char bashrc_path[PATH_MAX];
    fast_path_join(bashrc_path, home, ".bashrc");
    
    int fd = open(bashrc_path, O_RDONLY);
    if (fd == -1) return false;
    
    struct stat st;
    if (fstat(fd, &st) == -1) {
        close(fd);
        return false;
    }
    size_t size = st.st_size;
    
    char* map = (char*)mmap(0, size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (map == MAP_FAILED) {
        close(fd);
        return false;
    }
    
    bool found = false;
    const char* search_terms[] = {"$HOME/bin", "~/bin"};
    
    for (size_t i = 0; i < size; ++i) {
        for (int t = 0; t < 2; ++t) {
            size_t term_len = strlen(search_terms[t]);
            if (i + term_len <= size && 
                strncmp(&map[i], search_terms[t], term_len) == 0) {
                found = true;
                goto done;
            }
        }
    }
    
done:
    munmap(map, size);
    close(fd);
    return found;
}

// 追加bashrc配置
static void append_bashrc_config(const char* home) {
    char bashrc_path[PATH_MAX];
    fast_path_join(bashrc_path, home, ".bashrc");
    
    int fd = open(bashrc_path, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd == -1) return;
    
    const char config[] = "\n# User bin directory\nexport PATH=\"$HOME/bin:$PATH\"\n";
    write(fd, config, sizeof(config) - 1);
    close(fd);
}

int main() {
    // 确保完整消息输出
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    
    const char* home = getenv("HOME");
    if (!home) {
        safe_write(STDERR_FILENO, MSG_HOME_FAIL, strlen(MSG_HOME_FAIL));
        return 1;
    }
    
    safe_write(STDOUT_FILENO, MSG_TITLE, strlen(MSG_TITLE));
    
    char bin_dir[PATH_MAX];
    fast_path_join(bin_dir, home, "bin");
    
    if (mkdir(bin_dir, 0777) == -1) {
        if (errno != EEXIST) {
            safe_write(STDERR_FILENO, MSG_MKDIR_FAIL, strlen(MSG_MKDIR_FAIL));
            const char* errmsg = strerror(errno);
            safe_write(STDERR_FILENO, errmsg, strlen(errmsg));
            safe_write(STDERR_FILENO, "\n", 1);
            return 1;
        }
    } else {
        safe_write(STDOUT_FILENO, MSG_DIR_CREATED, strlen(MSG_DIR_CREATED));
    }
    
    fast_set_perms(bin_dir);
    safe_write(STDOUT_FILENO, MSG_PERM_SET, strlen(MSG_PERM_SET));
    
    if (is_path_configured(home) || is_bashrc_configured(home)) {
        safe_write(STDOUT_FILENO, MSG_PATH_OK, strlen(MSG_PATH_OK));
    } else {
        append_bashrc_config(home);
        safe_write(STDOUT_FILENO, MSG_PATH_ADDED, strlen(MSG_PATH_ADDED));
        safe_write(STDOUT_FILENO, MSG_SOURCE_HINT, strlen(MSG_SOURCE_HINT));
    }
    
    return 0;
}
