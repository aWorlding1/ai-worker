#include <iostream>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <limits.h>
#include <vector>
#include <algorithm>
#include <omp.h>
#include <sys/resource.h>
#include <errno.h>

// 颜色定义（兼容所有平台）
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define NC "\033[0m"

// UFS 2.2优化的批量权限设置
void setPermissionsBatch(const char* path) {
    const int UFS_BATCH_SIZE = 64;
    std::vector<std::string> dirs_to_process;
    dirs_to_process.reserve(512);

    dirs_to_process.emplace_back(path);

    while (!dirs_to_process.empty()) {
        size_t batch_size = std::min(dirs_to_process.size(), (size_t)UFS_BATCH_SIZE);
        
        #pragma omp parallel for schedule(dynamic, 4)
        for (size_t i = 0; i < batch_size; ++i) {
            char current_path[PATH_MAX];
            strncpy(current_path, dirs_to_process[i].c_str(), PATH_MAX);

            chmod(current_path, 0777);

            DIR* dir = opendir(current_path);
            if (!dir) continue;

            struct dirent* entry;
            while ((entry = readdir(dir))) {
                if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) 
                    continue;

                char fullpath[PATH_MAX];
                snprintf(fullpath, sizeof(fullpath), "%s/%s", current_path, entry->d_name);
                
                fchmodat(AT_FDCWD, fullpath, 0777, AT_SYMLINK_NOFOLLOW);

                if (entry->d_type == DT_DIR) {
                    #pragma omp critical
                    dirs_to_process.emplace_back(fullpath);
                }
            }
            closedir(dir);
        }
        dirs_to_process.erase(dirs_to_process.begin(), dirs_to_process.begin() + batch_size);
    }
}

// 安全的文件计数（修复memcpy警告）
size_t countFilesInBin(const char* bin_dir) {
    size_t count = 0;
    DIR* dir = opendir(bin_dir);
    if (!dir) return 0;
    
    struct dirent* entry;
    while ((entry = readdir(dir))) {
        if (entry->d_type == DT_REG) {
            // 安全的缓存行填充（避免memcpy警告）
            volatile char dummy_buf[256];
            size_t copy_size = sizeof(*entry) < sizeof(dummy_buf) ? 
                              sizeof(*entry) : sizeof(dummy_buf);
            memcpy((void*)dummy_buf, entry, copy_size);
            
            count++;
        }
    }
    closedir(dir);
    return count;
}

// 安全添加PATH配置
void safeAddToBashrc(const char* home, size_t file_count) {
    char bashrc_path[PATH_MAX];
    snprintf(bashrc_path, sizeof(bashrc_path), "%s/.bashrc", home);
    
    FILE* file = fopen(bashrc_path, "a");
    if (file) {
        const char* config = "\n# 添加用户bin目录到PATH\n"
                            "export PATH=\"$PATH:$HOME/bin\"\n";
        fwrite(config, 1, strlen(config), file);
        fclose(file);
        std::cout << GREEN "✓ 配置添加成功 (检测到 " << file_count << " 个文件)" << NC << std::endl;
    } else {
        std::cerr << RED "无法打开.bashrc文件" << NC << std::endl;
    }
}

// 检查PATH配置
bool checkPathContainsBin(const char* home) {
    const char* path_env = getenv("PATH");
    if (!path_env) return false;

    std::string bin_path = std::string(home) + "/bin";
    const char* path = path_env;
    
    while (*path) {
        const char* colon = strchr(path, ':');
        size_t segment_len = colon ? (colon - path) : strlen(path);
        
        if (segment_len == bin_path.length() && 
            strncmp(path, bin_path.c_str(), segment_len) == 0) {
            return true;
        }
        
        path = colon ? colon + 1 : path + segment_len;
    }
    return false;
}

int main() {
    // 设置IO优先级（兼容性写法）
    nice(10);

    const char* home = getenv("HOME");
    if (!home) {
        std::cerr << RED "✗ 无法获取HOME目录" << NC << std::endl;
        return 1;
    }

    char bin_dir[PATH_MAX];
    snprintf(bin_dir, sizeof(bin_dir), "%s/bin", home);

    std::cout << YELLOW "=== 用户bin目录设置工具 ===" << NC << std::endl;

    // 创建目录
    if (mkdir(bin_dir, 0777) == -1 && errno != EEXIST) {
        std::cerr << RED "创建目录失败: " << strerror(errno) << NC << std::endl;
        return 1;
    }

    // 批量权限设置
    std::cout << YELLOW "设置目录权限..." << NC << std::endl;
    setPermissionsBatch(bin_dir);

    // 文件统计
    size_t file_count = countFilesInBin(bin_dir);
    std::cout << YELLOW "检测到文件数: " << file_count << NC << std::endl;

    // 检查并更新PATH
    if (checkPathContainsBin(home)) {
        std::cout << GREEN "✓ ~/bin 已在PATH环境变量中" << NC << std::endl;
    } else {
        safeAddToBashrc(home, file_count);
        std::cout << YELLOW "请运行以下命令使更改生效:\nsource ~/.bashrc" << NC << std::endl;
    }

    std::cout << GREEN "\n✓ 操作完成" << NC << std::endl;
    return 0;
}
