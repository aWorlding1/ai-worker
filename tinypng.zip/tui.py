#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os
import sys
import time
import glob
import asyncio
import signal
import shutil  # 添加shutil模块导入
from typing import List, Tuple, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TaskProgressColumn
from rich.panel import Panel
from rich.table import Table
from rich.live import Live
from rich.layout import Layout
from rich.prompt import Prompt, Confirm, IntPrompt
from rich.text import Text
from rich.columns import Columns
from rich.box import ROUNDED
from rich import box
from rich.rule import Rule
from rich.align import Align
from rich.tree import Tree

from core import (
    ApiKeyManager, CompressionCache, CompressionMode, 
    load_config, save_config, format_size, format_time, VERSION, SUPPORTED_FORMATS
)
from optimizers import OptimizerManager

# 常量定义
API_KEYS_FILE = "Tinypng API密钥.txt"
USAGE_DATA_FILE = os.path.expanduser("~/.tinypng_usage.json")
CONFIG_FILE = os.path.expanduser("~/.tinypng_config.json")
CACHE_FILE = os.path.expanduser("~/.tinypng_cache.json")

# 初始化Rich控制台
console = Console()

class FileSystemBrowser:
    """交互式文件系统浏览器，用于选择目录和文件"""
    def __init__(self, starting_path='.'):
        self.current_path = os.path.abspath(starting_path)
        
    def browse(self) -> str:
        """交互式浏览界面，返回选择的路径"""
        while True:
            self._display_current_directory()
            choice = self._get_user_choice()
            
            if choice == '..':
                # 向上一级目录
                parent = os.path.dirname(self.current_path)
                if os.path.exists(parent):
                    self.current_path = parent
            elif choice == '.':
                # 选择当前目录
                return self.current_path
            elif os.path.isdir(os.path.join(self.current_path, choice)):
                # 进入选择的目录
                self.current_path = os.path.join(self.current_path, choice)
            elif os.path.isfile(os.path.join(self.current_path, choice)):
                # 选择文件
                return os.path.join(self.current_path, choice)
    
    def _display_current_directory(self) -> None:
        """显示当前目录内容"""
        console.clear()
        console.print(Panel(f"[bold cyan]文件浏览器[/bold cyan]\n当前路径: [yellow]{self.current_path}[/yellow]"))
        
        # 创建目录列表树
        tree = Tree(f"[bold yellow]{self.current_path}[/bold yellow]")
        
        # 添加父目录
        tree.add("[bold blue].. (上级目录)[/bold blue]")
        
        # 添加当前目录选择
        tree.add("[bold green]. (选择此目录)[/bold green]")
        
        # 先列出目录
        dirs = []
        files = []
        
        try:
            for item in sorted(os.listdir(self.current_path)):
                full_path = os.path.join(self.current_path, item)
                if os.path.isdir(full_path):
                    dirs.append(item)
                elif os.path.isfile(full_path) and any(item.lower().endswith(ext) for ext in SUPPORTED_FORMATS):
                    files.append(item)
        except PermissionError:
            console.print("[bold red]访问此目录权限被拒绝！[/bold red]")
            dirs = []
            files = []
        
        # 向树添加目录
        for d in dirs:
            tree.add(f"[bold blue]{d}/[/bold blue]")
        
        # 向树添加图像文件
        for f in files:
            _, ext = os.path.splitext(f)
            file_size = os.path.getsize(os.path.join(self.current_path, f))
            tree.add(f"[bold green]{f}[/bold green] ({format_size(file_size)})")
        
        console.print(tree)
    
    def _get_user_choice(self) -> str:
        """获取用户在当前目录中的选择"""
        items = ['..', '.'] + sorted(os.listdir(self.current_path))
        
        # 过滤只显示目录和支持的图像文件
        filtered_items = ['..', '.'] + [
            item for item in items[2:] 
            if (os.path.isdir(os.path.join(self.current_path, item)) or 
                any(item.lower().endswith(ext) for ext in SUPPORTED_FORMATS))
        ]
        
        # 如果没有有效项目，强制选择父目录
        if not filtered_items:
            console.print("[bold yellow]此位置没有目录或支持的图像文件。[/bold yellow]")
            return '..'
        
        try:
            choice = Prompt.ask(
                "输入项目编号或名称",
                choices=filtered_items,
                show_choices=False
            )
            return choice
        except KeyboardInterrupt:
            console.print("\n[bold yellow]操作已取消。[/bold yellow]")
            sys.exit(0)

class TinyPngOptimizer:
    """TinyPNG优化器主类，集成TUI支持"""
    def __init__(self):
        self.key_manager = ApiKeyManager(API_KEYS_FILE, USAGE_DATA_FILE)
        self.cache = CompressionCache(CACHE_FILE)
        self.config = load_config(CONFIG_FILE)
        self.optimizer_manager = OptimizerManager(self.key_manager, self.config)
        
        self.stats = {
            'total_files': 0,
            'processed_files': 0,
            'skipped_files': 0,
            'error_files': 0,
            'total_size_before': 0,
            'total_size_after': 0,
            'start_time': time.time(),
            'current_file': "",
            'current_progress': 0,
            'eta': 0
        }
        self.running = True
        
        # 注册信号处理器
        signal.signal(signal.SIGINT, self._handle_interrupt)
    
    def _handle_interrupt(self, sig, frame):
        """优雅处理键盘中断"""
        self.running = False
        console.print("\n[bold yellow]正在优雅关闭。请稍候...[/bold yellow]")
    
    def save_config(self):
        """保存配置"""
        save_config(self.config, CONFIG_FILE)
    
    async def compress_image(self, input_file: str, output_file: str, width: int = -1, 
                           progress_callback=None) -> Tuple[bool, int, int]:
        """压缩单个图像"""
        # 更新当前文件统计信息
        self.stats['current_file'] = os.path.basename(input_file)
        
        # 检查文件是否需要压缩（缓存检查）
        if not self.cache.needs_compression(input_file, width):
            self.stats['skipped_files'] += 1
            if progress_callback:
                progress_callback()
            size = os.path.getsize(input_file)
            return True, size, size
        
        # 创建备份（如果启用）
        if self.config['backup_enabled']:
            backup_dir = os.path.join(os.path.dirname(input_file), '.tinypng_backup')
            backup_file = os.path.join(backup_dir, os.path.basename(input_file))
            try:
                os.makedirs(backup_dir, exist_ok=True)
                if not os.path.exists(backup_file):
                    shutil.copy2(input_file, backup_file)
            except Exception as e:
                print(f"创建备份错误: {e}")
        
        # 使用优化器管理器进行多级压缩
        success, size_before, size_after = await self.optimizer_manager.optimize(
            input_file, output_file, width)
        
        # 更新统计信息
        if success:
            self.stats['total_size_before'] += size_before
            self.stats['total_size_after'] += size_after
            self.stats['processed_files'] += 1
            
            # 更新缓存
            self.cache.update_cache(input_file, output_file, width)
        else:
            self.stats['error_files'] += 1
        
        # 更新进度
        if progress_callback:
            progress_callback()
        
        return success, size_before, size_after
    
    async def process_files(self, files_to_process: List[Tuple[str, str, int]]) -> None:
        """处理多个文件，显示实时UI界面"""
        # 创建布局
        layout = Layout()
        layout.split(
            Layout(name="header", size=3),
            Layout(name="main"),
            Layout(name="footer", size=3)
        )
        
        # 分割主区域
        layout["main"].split_row(
            Layout(name="progress", ratio=2),
            Layout(name="stats", ratio=1)
        )
        
        # 初始化计数器
        total_files = len(files_to_process)
        self.stats['total_files'] = total_files
        processed = 0
        
        # 计算初始ETA
        self.stats['eta'] = 0
        
        def update_progress():
            nonlocal processed
            processed += 1
            progress_val = processed / total_files if total_files > 0 else 0
            self.stats['current_progress'] = progress_val
            
            # 更新ETA
            elapsed = time.time() - self.stats['start_time']
            if processed > 0:
                self.stats['eta'] = (elapsed / processed) * (total_files - processed)
        
        # 使用 asyncio 处理文件
        with Live(layout, refresh_per_second=4, screen=True) as live:
            while self.running and processed < total_files:
                # 更新头部
                header_text = Text.from_markup(f"[bold cyan]TinyPNG优化器 v{VERSION}[/bold cyan] - 处理{total_files}个文件")
                layout["header"].update(Panel(header_text, style="cyan"))
                
                # 更新进度区域
                progress_layout = Layout()
                progress_layout.split(
                    Layout(Panel(
                        self._create_progress_bar(),
                        title="[bold]进度[/bold]",
                        border_style="green"
                    ), size=3),
                    Layout(Panel(
                        self._create_file_list(files_to_process, processed),
                        title="[bold]文件[/bold]",
                        border_style="blue"
                    ))
                )
                layout["progress"].update(progress_layout)
                
                # 更新统计区域
                layout["stats"].update(Panel(
                    self._create_stats_display(),
                    title="[bold]统计信息[/bold]",
                    border_style="magenta"
                ))
                
                # 更新底部
                footer_text = Text.from_markup("[bold]按Ctrl+C取消[/bold]")
                layout["footer"].update(Panel(footer_text))
                
                # 批处理文件以提高响应性
                chunk_size = min(5, self.config['max_workers'])
                if processed < total_files:
                    # 创建当前批次的任务
                    tasks = []
                    end_idx = min(processed + chunk_size, total_files)
                    
                    for i in range(processed, end_idx):
                        input_file, output_file, width = files_to_process[i]
                        task = self.compress_image(input_file, output_file, width, update_progress)
                        tasks.append(asyncio.ensure_future(task))
                    
                    if tasks:
                        # 等待当前批次任务完成
                        await asyncio.gather(*tasks)
                
                # 小延迟允许UI更新
                await asyncio.sleep(0.1)
        
        # 保存缓存和使用数据
        self.cache.save_cache()
        self.key_manager.save_usage_data()
        
        # 显示最终统计信息
        console.clear()
        console.print(self._create_final_stats_panel())
    
    def _create_progress_bar(self) -> Text:
        """创建基于文本的进度条"""
        progress = self.stats['current_progress']
        width = 40
        filled = int(width * progress)
        
        # 颜色渐变
        if progress < 0.3:
            color = "red"
        elif progress < 0.7:
            color = "yellow"
        else:
            color = "green"
            
        # 进度条
        text = Text()
        text.append(f"[{int(progress * 100)}%] ", style="bold")
        text.append("█" * filled, style=color)
        text.append("░" * (width - filled), style="dim")
        
        # ETA
        eta = self.stats['eta']
        if eta > 0:
            text.append(f" 预计剩余时间: {format_time(eta)}", style="italic")
        
        return text
    
    def _create_file_list(self, files: List[Tuple[str, str, int]], processed: int) -> Text:
        """创建正在处理的文件列表"""
        text = Text()
        
        # 显示当前和下几个文件
        current_idx = min(processed, len(files) - 1)
        end_idx = min(current_idx + 5, len(files))
        
        # 当前文件
        if current_idx < len(files):
            input_file, _, _ = files[current_idx]
            text.append(f"▶ 当前: ", style="bold green")
            text.append(os.path.basename(input_file), style="bold")
            text.append("\n")
        
        # 下一个文件
        if current_idx + 1 < len(files):
            text.append("下一个文件:\n", style="dim")
            for i in range(current_idx + 1, end_idx):
                input_file, _, _ = files[i]
                text.append(f"  {os.path.basename(input_file)}\n", style="dim")
        
        return text
    
    def _create_stats_display(self) -> Text:
        """创建当前统计信息显示"""
        text = Text()
        
        # 处理统计
        text.append("已处理: ", style="bold")
        text.append(f"{self.stats['processed_files']} / {self.stats['total_files']}\n")
        
        text.append("已跳过: ", style="bold")
        text.append(f"{self.stats['skipped_files']}\n")
        
        text.append("错误: ", style="bold")
        text.append(f"{self.stats['error_files']}\n")
        
        # 时间信息
        elapsed = time.time() - self.stats['start_time']
        text.append("已用时间: ", style="bold")
        text.append(f"{format_time(elapsed)}\n")
        
        # 大小信息
        if self.stats['total_size_before'] > 0 and self.stats['total_size_after'] > 0:
            savings = self.stats['total_size_before'] - self.stats['total_size_after']
            savings_percent = (savings / self.stats['total_size_before']) * 100
            
            text.append("原始大小: ", style="bold")
            text.append(f"{format_size(self.stats['total_size_before'])}\n")
            
            text.append("压缩后大小: ", style="bold")
            text.append(f"{format_size(self.stats['total_size_after'])}\n")
            
            text.append("节省: ", style="bold")
            text.append(f"{format_size(savings)} ({savings_percent:.1f}%)\n", 
                      style="green" if savings_percent > 10 else "yellow")
        
        return text
    
    def _create_final_stats_panel(self) -> Panel:
        """创建带有最终统计信息的面板"""
        # 创建统计表格
        table = Table(box=box.ROUNDED)
        table.add_column("统计项", style="cyan", justify="right")
        table.add_column("值", style="green")
        
        # 添加基本统计
        table.add_row("总文件数", str(self.stats['total_files']))
        table.add_row("已处理", str(self.stats['processed_files']))
        table.add_row("已跳过", str(self.stats['skipped_files']))
        table.add_row("错误", str(self.stats['error_files']))
        
        # 添加时间信息
        elapsed = time.time() - self.stats['start_time']
        table.add_row("耗时", format_time(elapsed))
        
        # 添加大小信息
        if self.stats['total_size_before'] > 0 and self.stats['total_size_after'] > 0:
            savings = self.stats['total_size_before'] - self.stats['total_size_after']
            savings_percent = (savings / self.stats['total_size_before']) * 100
            
            table.add_row("原始大小", format_size(self.stats['total_size_before']))
            table.add_row("压缩后大小", format_size(self.stats['total_size_after']))
            table.add_row("节省", f"{format_size(savings)} ({savings_percent:.1f}%)")
        
        # 创建带有表格的面板
        return Panel(
            table,
            title="[bold cyan]压缩完成！[/bold cyan]",
            border_style="green",
            padding=(1, 2)
        )
    
    def compress_directory(self, directory_path: str, width: int = -1, recursive: bool = False) -> None:
        """压缩目录中的所有图像"""
        if not os.path.isdir(directory_path):
            console.print(f"[bold red]'{directory_path}'不是一个目录！[/bold red]")
            return
        
        console.print(f"[bold green]扫描目录: {directory_path}[/bold green]")
        
        from_path = directory_path
        to_path = os.path.join(directory_path, self.config['output_dir'])
        
        # 获取所有要处理的文件
        files_to_process = []
        
        # 修复walk函数的使用方式
        if recursive:
            walk_iter = os.walk(from_path)
        else:
            # 非递归模式下只处理顶层目录
            walk_iter = [(from_path, [d for d in os.listdir(from_path) 
                         if os.path.isdir(os.path.join(from_path, d))], 
                        [f for f in os.listdir(from_path) 
                         if os.path.isfile(os.path.join(from_path, f))])]
        
        for root, dirs, files in walk_iter:
            for name in files:
                _, file_ext = os.path.splitext(name)
                if file_ext.lower() in SUPPORTED_FORMATS:
                    # 跳过输出目录中的文件
                    if self.config['output_dir'] in root.split(os.path.sep):
                        continue
                    
                    # 跳过备份目录
                    if '.tinypng_backup' in root.split(os.path.sep):
                        continue
                    
                    input_file = os.path.join(root, name)
                    
                    # 修复相对路径计算，确保嵌套目录结构被保留
                    relative_path = os.path.relpath(root, from_path)
                    if relative_path == '.':
                        output_dir = to_path
                    else:
                        output_dir = os.path.join(to_path, relative_path)
                        
                    # 确保输出目录存在
                    os.makedirs(output_dir, exist_ok=True)
                    
                    output_file = os.path.join(output_dir, name)
                    files_to_process.append((input_file, output_file, width))
        
        if not files_to_process:
            console.print("[yellow]在目录中未找到支持的图像文件。[/yellow]")
            return
        
        console.print(f"[green]找到{len(files_to_process)}个图像待处理。[/green]")
        
        # 按大小排序文件（最大的先处理）
        files_to_process.sort(key=lambda x: os.path.getsize(x[0]), reverse=True)
        
        # 使用TUI处理文件
        asyncio.run(self.process_files(files_to_process))
    
    def compress_single_file(self, file_path: str, width: int = -1) -> None:
        """压缩单个图像文件"""
        if not os.path.isfile(file_path):
            console.print(f"[bold red]'{file_path}'不是一个文件！[/bold red]")
            return
        
        _, file_ext = os.path.splitext(file_path)
        if file_ext.lower() not in SUPPORTED_FORMATS:
            console.print(f"[bold red]'{file_path}'不是支持的图像格式({', '.join(SUPPORTED_FORMATS)})！[/bold red]")
            return
        
        console.print(f"[bold green]处理文件: {file_path}[/bold green]")
        
        dirname = os.path.dirname(file_path)
        basename = os.path.basename(file_path)
        
        # 创建output_dir子目录来保持与批量处理一致
        output_dir = os.path.join(dirname, self.config['output_dir'])
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, basename)
        
        self.stats['total_files'] = 1
        
        # 使用asyncio运行异步函数
        async def run_compression():
            return await self.compress_image(file_path, output_file, width)
        
        # 处理文件
        success, size_before, size_after = asyncio.run(run_compression())
        
        if success and size_after > 0:
            savings = size_before - size_after
            savings_percent = (savings / size_before) * 100
            
            # 创建一个漂亮的显示面板
            table = Table(box=box.ROUNDED)
            table.add_column("指标", style="cyan", justify="right")
            table.add_column("值", style="green")
            
            table.add_row("文件", basename)
            table.add_row("原始大小", format_size(size_before))
            table.add_row("压缩后大小", format_size(size_after))
            table.add_row("节省", f"{format_size(savings)} ({savings_percent:.1f}%)")
            table.add_row("输出文件", os.path.basename(output_file))
            
            console.print(Panel(
                table,
                title="[bold green]压缩成功！[/bold green]",
                border_style="green"
            ))
            
        elif size_before == 0:
            console.print(Panel(
                f"跳过'{basename}'（已处理过）",
                title="[bold yellow]信息[/bold yellow]",
                border_style="yellow"
            ))

class TinyPngTui:
    """TinyPNG优化器的文本用户界面"""
    def __init__(self):
        self.optimizer = TinyPngOptimizer()
        self.key_manager = self.optimizer.key_manager
    
    def show_main_menu(self) -> None:
        """显示主菜单"""
        console.clear()
        console.print(Panel(
            "[bold cyan]TinyPNG优化器[/bold cyan] [yellow]v{}[/yellow]\n"
            "[green]多级压缩，最佳效果[/green]".format(VERSION),
            title="欢迎使用",
            subtitle="by Claude",
            border_style="cyan"
        ))
        
        # 显示API使用摘要
        summary = self.key_manager.get_usage_summary()
        console.print(f"API使用: [bold]{summary['total_uses']:,}[/bold] / {summary['capacity']:,} 图片 "
                     f"([bold]{summary['used_percent']:.1f}%[/bold])")
        
        console.print("\n[bold cyan]请选择操作:[/bold cyan]")
        
        menu_items = [
            ("1", "压缩单个文件", self.compress_file_menu),
            ("2", "压缩文件夹", self.compress_directory_menu),
            ("3", "查看API使用情况", self.show_api_stats),
            ("4", "配置设置", self.show_config_menu),
            ("5", "恢复备份", self.restore_backups_menu),
            ("0", "退出", lambda: None)
        ]
        
        for key, label, _ in menu_items:
            console.print(f"[bold green]{key}[/bold green]. {label}")
        
        try:
            choice = Prompt.ask("请输入选项", choices=[item[0] for item in menu_items], show_choices=False)
            
            if choice == "0":
                console.print("[bold cyan]谢谢使用，再见！[/bold cyan]")
                sys.exit(0)
            
            # 查找并调用选定的函数
            for key, _, func in menu_items:
                if key == choice:
                    func()
                    # 函数完成后返回主菜单
                    self.show_main_menu()
        except KeyboardInterrupt:
            console.print("\n[bold yellow]操作已取消[/bold yellow]")
            sys.exit(0)
    
    def compress_file_menu(self) -> None:
        """压缩单个文件的菜单"""
        console.clear()
        console.print(Panel("[bold cyan]压缩单个文件[/bold cyan]", border_style="cyan"))
        
        # 询问用户是否要浏览
        if Confirm.ask("是否要浏览文件系统选择文件?"):
            browser = FileSystemBrowser()
            file_path = browser.browse()
        else:
            file_path = Prompt.ask("请输入文件路径")
        
        # 验证文件是否存在
        if not os.path.exists(file_path):
            console.print(f"[bold red]文件不存在: {file_path}[/bold red]")
            console.print("按任意键返回主菜单...")
            input()
            return
        
        # 检查是否是目录
        if os.path.isdir(file_path):
            if Confirm.ask(f"'{file_path}'是一个文件夹。是否要压缩整个文件夹?"):
                self.compress_directory_with_params(file_path)
                return
            else:
                return
        
        # 询问宽度
        width = self._get_width_input()
        
        # 压缩文件
        self.optimizer.compress_single_file(file_path, width)
        
        console.print("\n按任意键返回主菜单...")
        input()
    
    def compress_directory_menu(self) -> None:
        """压缩目录的菜单"""
        console.clear()
        console.print(Panel("[bold cyan]压缩文件夹[/bold cyan]", border_style="cyan"))
        
        # 询问用户是否要浏览
        if Confirm.ask("是否要浏览文件系统选择文件夹?"):
            browser = FileSystemBrowser()
            directory_path = browser.browse()
            
            # 确保它是一个目录
            if not os.path.isdir(directory_path):
                directory_path = os.path.dirname(directory_path)
        else:
            directory_path = Prompt.ask("请输入文件夹路径", default=".")
        
        self.compress_directory_with_params(directory_path)
    
    def compress_directory_with_params(self, directory_path: str) -> None:
        """使用用户提供的参数压缩目录"""
        # 验证目录是否存在
        if not os.path.exists(directory_path) or not os.path.isdir(directory_path):
            console.print(f"[bold red]文件夹不存在: {directory_path}[/bold red]")
            console.print("按任意键返回主菜单...")
            input()
            return
        
        # 获取压缩参数
        recursive = Confirm.ask("是否递归处理子文件夹?")
        width = self._get_width_input()
        
        # 询问输出目录名称
        output_dir = Prompt.ask("输出文件夹名称", default=self.optimizer.config['output_dir'])
        self.optimizer.config['output_dir'] = output_dir
        self.optimizer.save_config()
        
        # 压缩目录
        self.optimizer.compress_directory(directory_path, width, recursive)
        
        console.print("\n按任意键返回主菜单...")
        input()
    
    def show_api_stats(self) -> None:
        """显示API使用统计"""
        console.clear()
        
        # 获取API使用摘要
        summary = self.key_manager.get_usage_summary()
        
        # 创建API密钥使用表格
        table = Table(title="API密钥使用情况", box=box.ROUNDED)
        table.add_column("密钥(最后4位)", justify="right", style="cyan")
        table.add_column("使用次数", justify="right")
        table.add_column("剩余次数", justify="right")
        table.add_column("最后使用时间", justify="right")
        table.add_column("状态", justify="center")
        
        for api_key in sorted(self.key_manager.keys, key=lambda k: k.uses, reverse=True):
            key_display = f"...{api_key.key[-4:]}"
            last_used = "从未使用" if api_key.last_used == 0 else time.strftime("%Y-%m-%d %H:%M", time.localtime(api_key.last_used))
            remaining = 500 - api_key.uses
            
            status = "[green]可用[/green]" if api_key.is_available() else "[red]已达限额[/red]"
            
            # 使用量的颜色渐变
            if api_key.uses < 100:
                usage_style = "green"
            elif api_key.uses < 300:
                usage_style = "yellow"
            else:
                usage_style = "red"
                
            # 剩余量的颜色渐变
            if remaining > 400:
                remaining_style = "green"
            elif remaining > 200:
                remaining_style = "yellow"
            else:
                remaining_style = "red"
            
            table.add_row(
                key_display,
                f"[{usage_style}]{api_key.uses}[/{usage_style}]",
                f"[{remaining_style}]{remaining}[/{remaining_style}]",
                last_used,
                status
            )
        
        # 创建摘要表格
        summary_table = Table(box=None, show_header=False, padding=(0, 2))
        summary_table.add_column("统计")
        summary_table.add_column("值")
        
        summary_table.add_row(
            "本月总API调用:", 
            f"[bold]{summary['total_uses']:,}[/bold]"
        )
        summary_table.add_row(
            "可用密钥:", 
            f"[bold]{summary['available_keys']}/{summary['total_keys']}[/bold]"
        )
        summary_table.add_row(
            "总容量:", 
            f"[bold]{summary['capacity']:,} 图片[/bold]"
        )
        
        # 使用条
        used_percent = summary['used_percent']
        bar_color = "green"
        if used_percent > 50:
            bar_color = "yellow"
        if used_percent > 80:
            bar_color = "red"
            
        bar_width = 40
        filled = int(bar_width * used_percent / 100)
        bar = f"[{bar_color}]{'█' * filled}{'░' * (bar_width - filled)}[/{bar_color}] {used_percent:.1f}%"
        
        summary_table.add_row("使用情况:", bar)
        
        # 月度统计
        month_progress = (summary['days_passed'] / summary['days_in_month']) * 100
        month_bar_width = 30
        month_filled = int(month_bar_width * month_progress / 100)
        month_bar = f"[blue]{'█' * month_filled}{'░' * (month_bar_width - month_filled)}[/blue] {month_progress:.1f}%"
        
        summary_table.add_row(
            "月度进度:", 
            f"{month_bar} (第{summary['days_passed']}天/{summary['days_in_month']}天)"
        )
        
        # 预测使用情况
        if summary['days_passed'] > 0:
            projected_use = (summary['total_uses'] / summary['days_passed']) * summary['days_in_month']
            projected_percent = (projected_use / summary['capacity']) * 100
            
            summary_table.add_row(
                "月底预计使用:", 
                f"[bold]{projected_use:.0f}[/bold] 图片 ({projected_percent:.1f}%)"
            )
        
        # 创建带有两个表格的面板
        panel = Panel(
            Columns([table, summary_table], expand=True),
            title="[bold cyan]API使用统计[/bold cyan]",
            border_style="cyan",
            padding=(1, 2)
        )
        
        console.print(panel)
        console.print("\n按任意键返回主菜单...")
        input()
    
    def show_config_menu(self) -> None:
        """显示配置菜单"""
        console.clear()
        console.print(Panel("[bold cyan]配置设置[/bold cyan]", border_style="cyan"))
        
        # 将CompressionMode枚举值映射到人类可读字符串
        local_opt_map = {
            CompressionMode.NONE.value: '无',
            CompressionMode.LIGHT.value: '轻度',
            CompressionMode.MEDIUM.value: '中度',
            CompressionMode.AGGRESSIVE.value: '强力'
        }
        
        # 反向映射以设置值
        local_opt_reverse_map = {v: k for k, v in local_opt_map.items()}
        
        # 显示当前配置
        table = Table(box=box.ROUNDED)
        table.add_column("设置", style="cyan")
        table.add_column("当前值", style="green")
        
        table.add_row("1. 输出文件夹名称", self.optimizer.config['output_dir'])
        table.add_row("2. 默认宽度", str(self.optimizer.config['default_width']))
        table.add_row("3. 最大工作线程", str(self.optimizer.config['max_workers']))
        table.add_row("4. 本地优化级别", local_opt_map[self.optimizer.config['local_optimization']])
        table.add_row("5. 保留EXIF数据", "是" if self.optimizer.config['respect_exif'] else "否")
        table.add_row("6. 备份原始图片", "是" if self.optimizer.config['backup_enabled'] else "否")
        table.add_row("7. 重试次数", str(self.optimizer.config['retry_count']))
        table.add_row("8. 重试延迟(秒)", str(self.optimizer.config['retry_delay']))
        table.add_row("0. 返回主菜单", "")
        
        console.print(table)
        
        choice = Prompt.ask("请选择要修改的设置", choices=["0", "1", "2", "3", "4", "5", "6", "7", "8"], show_choices=False)
        
        if choice == "0":
            return
        elif choice == "1":
            new_value = Prompt.ask("输入新的输出文件夹名称", default=self.optimizer.config['output_dir'])
            self.optimizer.config['output_dir'] = new_value
        elif choice == "2":
            new_value = IntPrompt.ask("输入新的默认宽度 (-1 为保持原宽度)", default=self.optimizer.config['default_width'])
            self.optimizer.config['default_width'] = new_value
        elif choice == "3":
            new_value = IntPrompt.ask("输入新的最大工作线程数", default=self.optimizer.config['max_workers'])
            self.optimizer.config['max_workers'] = max(1, min(16, new_value))  # 限制在1-16之间
        elif choice == "4":
            options = list(local_opt_map.values())
            new_value = Prompt.ask("选择本地优化级别", choices=options, default=local_opt_map[self.optimizer.config['local_optimization']])
            self.optimizer.config['local_optimization'] = local_opt_reverse_map[new_value]
        elif choice == "5":
            new_value = Confirm.ask("是否保留EXIF数据?", default=self.optimizer.config['respect_exif'])
            self.optimizer.config['respect_exif'] = new_value
        elif choice == "6":
            new_value = Confirm.ask("是否备份原始图片?", default=self.optimizer.config['backup_enabled'])
            self.optimizer.config['backup_enabled'] = new_value
        elif choice == "7":
            new_value = IntPrompt.ask("输入新的重试次数", default=self.optimizer.config['retry_count'])
            self.optimizer.config['retry_count'] = max(1, min(10, new_value))  # 限制在1-10之间
        elif choice == "8":
            new_value = IntPrompt.ask("输入新的重试延迟(秒)", default=self.optimizer.config['retry_delay'])
            self.optimizer.config['retry_delay'] = max(1, min(30, new_value))  # 限制在1-30之间
        
        # 保存配置
        self.optimizer.save_config()
        console.print("[bold green]配置已保存![/bold green]")
        
        # 再次显示配置菜单
        self.show_config_menu()
    
    def restore_backups_menu(self) -> None:
        """恢复备份的菜单"""
        console.clear()
        console.print(Panel("[bold cyan]恢复备份[/bold cyan]", border_style="cyan"))
        
        # 询问用户是否要浏览
        if Confirm.ask("是否要浏览文件系统选择文件夹?"):
            browser = FileSystemBrowser()
            directory_path = browser.browse()
            
            # 确保它是一个目录
            if not os.path.isdir(directory_path):
                directory_path = os.path.dirname(directory_path)
        else:
            directory_path = Prompt.ask("请输入文件夹路径", default=".")
        
        # 检查备份目录是否存在
        backup_dir = os.path.join(directory_path, '.tinypng_backup')
        if not os.path.exists(backup_dir) or not os.path.isdir(backup_dir):
            console.print(f"[bold yellow]没有找到备份文件夹: {backup_dir}[/bold yellow]")
            console.print("按任意键返回主菜单...")
            input()
            return
        
        # 计算备份文件数量
        backup_count = 0
        backup_files = []
        for root, _, files in os.walk(backup_dir):
            for name in files:
                _, file_ext = os.path.splitext(name)
                if file_ext.lower() in SUPPORTED_FORMATS:
                    backup_count += 1
                    backup_file = os.path.join(root, name)
                    # 修复相对路径计算，确保恢复到正确的位置
                    rel_path = os.path.relpath(root, backup_dir)
                    original_dir = os.path.join(directory_path, rel_path if rel_path != '.' else '')
                    original_file = os.path.join(original_dir, name)
                    backup_files.append((backup_file, original_file))
        
        if backup_count == 0:
            console.print("[bold yellow]没有找到备份文件![/bold yellow]")
            console.print("按任意键返回主菜单...")
            input()
            return
        
        console.print(f"[green]找到 {backup_count} 个备份文件[/green]")
        
        # 询问用户是否要恢复所有或选择
        all_files = Confirm.ask("是否恢复所有备份文件?")
        
        if all_files:
            # 恢复所有备份
            with Progress(
                SpinnerColumn(), 
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                TimeElapsedColumn()
            ) as progress:
                task = progress.add_task("[cyan]恢复备份中...", total=backup_count)
                
                for backup_file, original_file in backup_files:
                    # 创建目录（如果不存在）
                    os.makedirs(os.path.dirname(original_file), exist_ok=True)
                    
                    # 复制文件
                    shutil.copy2(backup_file, original_file)
                    progress.update(task, advance=1)
            
            console.print("[bold green]备份恢复完成![/bold green]")
        else:
            # 单个文件恢复功能
            # 显示文件列表供选择
            console.clear()
            console.print("[bold cyan]选择要恢复的文件:[/bold cyan]")
            
            # 将文件分组显示
            grouped_files = {}
            for backup_file, original_file in backup_files:
                rel_dir = os.path.dirname(os.path.relpath(backup_file, backup_dir))
                if rel_dir not in grouped_files:
                    grouped_files[rel_dir] = []
                grouped_files[rel_dir].append((backup_file, original_file))
            
            # 创建文件树显示
            tree = Tree("[bold cyan]备份文件[/bold cyan]")
            file_index = 0
            file_map = {}
            
            for dir_path, files in sorted(grouped_files.items()):
                dir_node = tree.add(f"[bold blue]{dir_path if dir_path else '.'}/[/bold blue]")
                for backup_file, original_file in sorted(files, key=lambda x: os.path.basename(x[0])):
                    file_index += 1
                    basename = os.path.basename(backup_file)
                    size = os.path.getsize(backup_file)
                    file_node = dir_node.add(f"[{file_index}] [green]{basename}[/green] ({format_size(size)})")
                    file_map[str(file_index)] = (backup_file, original_file)
            
            console.print(tree)
            console.print("\n输入文件编号(以逗号分隔)或'all'恢复所有文件:")
            choice = input().strip()
            
            if choice.lower() == 'all':
                # 恢复所有文件
                files_to_restore = backup_files
            else:
                # 恢复选定的文件
                indices = [idx.strip() for idx in choice.split(',') if idx.strip()]
                files_to_restore = [file_map[idx] for idx in indices if idx in file_map]
            
            # 执行恢复
            with Progress(
                SpinnerColumn(), 
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                TimeElapsedColumn()
            ) as progress:
                task = progress.add_task("[cyan]恢复选定文件中...", total=len(files_to_restore))
                
                for backup_file, original_file in files_to_restore:
                    # 创建目录（如果不存在）
                    os.makedirs(os.path.dirname(original_file), exist_ok=True)
                    
                    # 复制文件
                    shutil.copy2(backup_file, original_file)
                    progress.update(task, advance=1)
            
            console.print(f"[bold green]已恢复 {len(files_to_restore)} 个文件![/bold green]")
        
        console.print("\n按任意键返回主菜单...")
        input()
    
    def _get_width_input(self) -> int:
        """从用户获取宽度输入"""
        resize = Confirm.ask("是否调整图片宽度?")
        if resize:
            width = IntPrompt.ask("请输入新的宽度 (像素)", default=1080)
        else:
            width = -1
        return width

# 命令行界面
@click.group(context_settings=dict(help_option_names=['-h', '--help']))
@click.version_option(VERSION, '--version', '-v')
def cli():
    """TinyPNG图像优化器 - 多级压缩策略实现最佳压缩效果"""
    pass

@cli.command('tui')
def launch_tui():
    """启动文本用户界面"""
    tui = TinyPngTui()
    tui.show_main_menu()

@cli.command('file')
@click.argument('file_path', type=click.Path(exists=True))
@click.option('-w', '--width', type=int, default=-1, help='将图像调整为此宽度')
def compress_file(file_path, width):
    """压缩单个图像文件"""
    optimizer = TinyPngOptimizer()
    optimizer.compress_single_file(file_path, width)

@cli.command('dir')
@click.argument('directory', type=click.Path(exists=True), default='.')
@click.option('-w', '--width', type=int, default=-1, help='将图像调整为此宽度')
@click.option('-r', '--recursive', is_flag=True, help='递归处理子目录')
@click.option('-o', '--output', help='输出目录名称')
def compress_directory(directory, width, recursive, output):
    """压缩目录中的所有图像"""
    optimizer = TinyPngOptimizer()
    if output:
        optimizer.config['output_dir'] = output
        optimizer.save_config()
    
    optimizer.compress_directory(directory, width, recursive)

@cli.command('stats')
def show_stats():
    """显示API密钥使用统计"""
    key_manager = ApiKeyManager(API_KEYS_FILE, USAGE_DATA_FILE)
    summary = key_manager.get_usage_summary()
    
    # 创建统计表
    table = Table(title="API密钥使用统计", box=box.ROUNDED)
    table.add_column("统计项", style="cyan", justify="right")
    table.add_column("值", style="green")
    
    table.add_row("总密钥数", str(summary['total_keys']))
    table.add_row("可用密钥数", str(summary['available_keys']))
    table.add_row("总使用次数", str(summary['total_uses']))
    table.add_row("总容量", f"{summary['capacity']} 图片")
    table.add_row("使用百分比", f"{summary['used_percent']:.1f}%")
    
    console.print(table)

# 主程序入口
if __name__ == "__main__":
    # 如果没有提供参数，启动TUI
    if len(sys.argv) == 1:
        launch_tui()
    else:
        try:
            cli()
        except KeyboardInterrupt:
            console.print("\n[yellow]用户取消操作.[/yellow]")
            sys.exit(0)
        except Exception as e:
            console.print(f"[bold red]错误: {e}[/bold red]")
            sys.exit(1)