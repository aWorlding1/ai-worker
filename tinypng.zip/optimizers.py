#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os
import shutil
import subprocess
import asyncio
import tempfile
from abc import ABC, abstractmethod
from typing import Tuple, Dict, Any, Optional, List

from PIL import Image
import tinify
import requests

from core import ApiKeyManager, CompressionMode, format_size

class ImageOptimizer(ABC):
    """图像优化器基类"""
    
    @abstractmethod
    async def optimize(self, input_file: str, output_file: str, width: int = -1, 
                       options: Optional[Dict[str, Any]] = None) -> Tuple[bool, int, int]:
        """
        优化图像
        
        Args:
            input_file: 输入文件路径
            output_file: 输出文件路径
            width: 目标宽度，-1表示保持原始宽度
            options: 附加选项
            
        Returns:
            (成功与否, 原始大小, 压缩后大小)
        """
        pass

class LosslessOptimizer(ImageOptimizer):
    """无损压缩优化器 - 实现第一级压缩"""
    
    async def optimize(self, input_file: str, output_file: str, width: int = -1, 
                       options: Optional[Dict[str, Any]] = None) -> Tuple[bool, int, int]:
        """无损压缩图像，根据格式选择合适的工具"""
        try:
            size_before = os.path.getsize(input_file)
            
            # 创建输出目录
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # 获取文件格式
            _, ext = os.path.splitext(input_file)
            ext = ext.lower()
            
            # 根据格式选择优化方法
            if ext in ['.png']:
                success, size_after = await self._optimize_png(input_file, output_file, width)
            elif ext in ['.jpg', '.jpeg']:
                success, size_after = await self._optimize_jpeg(input_file, output_file, width)
            elif ext in ['.webp']:
                success, size_after = await self._optimize_webp(input_file, output_file, width)
            else:
                # 对于其他格式，直接复制
                shutil.copy2(input_file, output_file)
                size_after = os.path.getsize(output_file)
                success = True
                
            return success, size_before, size_after
        except Exception as e:
            print(f"无损压缩错误: {e}")
            # 出错时尝试复制原始文件
            try:
                shutil.copy2(input_file, output_file)
                return False, size_before, size_before
            except Exception as copy_error:
                print(f"复制原始文件错误: {copy_error}")
                return False, size_before, 0
    
    async def _optimize_png(self, input_file: str, output_file: str, width: int = -1) -> Tuple[bool, int]:
        """优化PNG图像"""
        # 如果需要调整大小，先处理
        temp_file = None
        try:
            if width > 0:
                try:
                    with Image.open(input_file) as img:
                        if img.width > width:
                            # 计算等比例高度
                            ratio = width / img.width
                            height = int(img.height * ratio)
                            # 调整大小
                            resized_img = img.resize((width, height), Image.LANCZOS)
                            # 创建临时文件
                            fd, temp_file = tempfile.mkstemp(suffix='.png')
                            os.close(fd)
                            # 保存调整后的图像
                            resized_img.save(temp_file, 'PNG')
                            input_file = temp_file
                except Exception as e:
                    print(f"调整图像大小错误: {e}")
            
            try:
                # 尝试使用optipng命令行工具
                result = subprocess.run(
                    ['optipng', '-o2', '-quiet', '-out', output_file, input_file],
                    capture_output=True, text=True, check=False
                )
                
                if result.returncode == 0:
                    return True, os.path.getsize(output_file)
            except (subprocess.SubprocessError, FileNotFoundError):
                # optipng不可用，继续尝试其他方法
                pass
            
            # 使用Pillow库备选方案
            with Image.open(input_file) as img:
                img.save(output_file, 'PNG', optimize=True)
                
            return True, os.path.getsize(output_file)
        except Exception as e:
            print(f"PNG优化错误: {e}")
            
            # 失败时复制原文件
            shutil.copy2(input_file, output_file)
            return False, os.path.getsize(output_file)
        finally:
            # 清理临时文件
            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except Exception:
                    pass
    
    async def _optimize_jpeg(self, input_file: str, output_file: str, width: int = -1) -> Tuple[bool, int]:
        """优化JPEG图像"""
        # 如果需要调整大小，先处理
        temp_file = None
        try:
            if width > 0:
                try:
                    with Image.open(input_file) as img:
                        if img.width > width:
                            # 计算等比例高度
                            ratio = width / img.width
                            height = int(img.height * ratio)
                            # 调整大小
                            resized_img = img.resize((width, height), Image.LANCZOS)
                            # 创建临时文件
                            fd, temp_file = tempfile.mkstemp(suffix='.jpg')
                            os.close(fd)
                            # 保存调整后的图像
                            resized_img.save(temp_file, 'JPEG', quality=95)
                            input_file = temp_file
                except Exception as e:
                    print(f"调整图像大小错误: {e}")
            
            try:
                # 尝试使用jpegtran命令行工具
                result = subprocess.run(
                    ['jpegtran', '-copy', 'all', '-optimize', '-outfile', output_file, input_file],
                    capture_output=True, text=True, check=False
                )
                
                if result.returncode == 0:
                    return True, os.path.getsize(output_file)
            except (subprocess.SubprocessError, FileNotFoundError):
                # jpegtran不可用，继续尝试其他方法
                pass
            
            # 使用Pillow库备选方案
            with Image.open(input_file) as img:
                img.save(output_file, 'JPEG', quality=95, optimize=True)
                
            return True, os.path.getsize(output_file)
        except Exception as e:
            print(f"JPEG优化错误: {e}")
            
            # 失败时复制原文件
            shutil.copy2(input_file, output_file)
            return False, os.path.getsize(output_file)
        finally:
            # 清理临时文件
            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except Exception:
                    pass
    
    async def _optimize_webp(self, input_file: str, output_file: str, width: int = -1) -> Tuple[bool, int]:
        """优化WebP图像"""
        # WebP格式使用Pillow库进行优化
        temp_file = None
        try:
            if width > 0:
                try:
                    with Image.open(input_file) as img:
                        if img.width > width:
                            # 计算等比例高度
                            ratio = width / img.width
                            height = int(img.height * ratio)
                            # 调整大小
                            resized_img = img.resize((width, height), Image.LANCZOS)
                            # 创建临时文件
                            fd, temp_file = tempfile.mkstemp(suffix='.webp')
                            os.close(fd)
                            # 保存调整后的图像
                            resized_img.save(temp_file, 'WEBP', quality=95)
                            input_file = temp_file
                except Exception as e:
                    print(f"调整图像大小错误: {e}")
            
            with Image.open(input_file) as img:
                img.save(output_file, 'WEBP', quality=95, method=6)  # 方法6为最佳质量
                
            return True, os.path.getsize(output_file)
        except Exception as e:
            print(f"WebP优化错误: {e}")
            
            # 失败时复制原文件
            shutil.copy2(input_file, output_file)
            return False, os.path.getsize(output_file)
        finally:
            # 清理临时文件
            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except Exception:
                    pass

class TinyPngOptimizer(ImageOptimizer):
    """TinyPNG优化器 - 实现第二级压缩"""
    
    def __init__(self, api_key_manager: ApiKeyManager, retry_count: int = 3, retry_delay: int = 2):
        self.api_key_manager = api_key_manager
        self.retry_count = retry_count
        self.retry_delay = retry_delay
    
    async def optimize(self, input_file: str, output_file: str, width: int = -1, 
                       options: Optional[Dict[str, Any]] = None) -> Tuple[bool, int, int]:
        """使用TinyPNG API压缩图像"""
        try:
            size_before = os.path.getsize(input_file)
            
            # 创建输出目录
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # 尝试多次（包括API密钥切换）
            for attempt in range(self.retry_count):
                try:
                    # 获取API密钥
                    api_key = self.api_key_manager.get_next_key()
                    tinify.key = api_key
                    
                    # 压缩图像
                    source = tinify.from_file(input_file)
                    
                    # 如果需要调整大小
                    if width > 0:
                        resized = source.resize(method="scale", width=width)
                        resized.to_file(output_file)
                    else:
                        source.to_file(output_file)
                    
                    size_after = os.path.getsize(output_file)
                    return True, size_before, size_after
                    
                except (tinify.AccountError, tinify.ClientError) as e:
                    # API密钥错误或客户端错误，尝试下一个密钥
                    print(f"TinyPNG API错误: {e}，尝试下一个密钥")
                    if attempt < self.retry_count - 1:
                        await asyncio.sleep(self.retry_delay)
                    else:
                        return False, size_before, 0
                        
                except tinify.ServerError as e:
                    # 服务器错误，稍后重试
                    print(f"TinyPNG服务器错误: {e}，稍后重试")
                    if attempt < self.retry_count - 1:
                        await asyncio.sleep(self.retry_delay * 2)  # 延长服务器错误的重试间隔
                    else:
                        return False, size_before, 0
                        
                except tinify.ConnectionError as e:
                    # 连接错误，稍后重试
                    print(f"TinyPNG连接错误: {e}，稍后重试")
                    if attempt < self.retry_count - 1:
                        await asyncio.sleep(self.retry_delay)
                    else:
                        return False, size_before, 0
                        
                except Exception as e:
                    # 其他错误
                    print(f"TinyPNG未知错误: {e}")
                    return False, size_before, 0
            
            return False, size_before, 0
            
        except Exception as e:
            print(f"TinyPNG优化过程错误: {e}")
            return False, size_before, 0

class TinyPicOptimizer(ImageOptimizer):
    """TinyPic优化器 - 实现第三级备选压缩"""
    
    def __init__(self, retry_count: int = 2, retry_delay: int = 3):
        self.retry_count = retry_count
        self.retry_delay = retry_delay
        self.url = "https://tinypic.pro/zh-CN/"
        self.api_url = "https://tinypic.pro/api/upload"
    
    async def optimize(self, input_file: str, output_file: str, width: int = -1, 
                       options: Optional[Dict[str, Any]] = None) -> Tuple[bool, int, int]:
        """使用TinyPic网站压缩图像"""
        try:
            size_before = os.path.getsize(input_file)
            
            # 创建输出目录
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # 多次尝试
            for attempt in range(self.retry_count):
                try:
                    # 准备上传文件
                    with open(input_file, 'rb') as f:
                        files = {'file': (os.path.basename(input_file), f)}
                        
                        # 创建会话并设置请求头
                        session = requests.Session()
                        session.headers.update({
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                            'Accept': 'application/json',
                            'Referer': self.url
                        })
                        
                        # 发送上传请求
                        response = session.post(self.api_url, files=files)
                        
                        # 处理响应
                        if response.status_code == 200:
                            try:
                                result = response.json()
                                if 'url' in result:
                                    # 下载压缩后的图像
                                    download_url = result['url']
                                    download_response = session.get(download_url, stream=True)
                                    
                                    if download_response.status_code == 200:
                                        with open(output_file, 'wb') as f:
                                            for chunk in download_response.iter_content(chunk_size=8192):
                                                if chunk:
                                                    f.write(chunk)
                                        
                                        # 如果需要调整大小且不是由TinyPic处理
                                        if width > 0:
                                            try:
                                                with Image.open(output_file) as img:
                                                    if img.width > width:
                                                        # 计算等比例高度
                                                        ratio = width / img.width
                                                        height = int(img.height * ratio)
                                                        # 调整大小
                                                        resized_img = img.resize((width, height), Image.LANCZOS)
                                                        # 保存调整后的图像
                                                        resized_img.save(output_file, quality=95, optimize=True)
                                            except Exception as e:
                                                print(f"调整大小错误: {e}")
                                        
                                        size_after = os.path.getsize(output_file)
                                        return True, size_before, size_after
                            except ValueError:
                                # 如果响应不是JSON格式
                                print("TinyPic响应格式错误")
                
                except Exception as e:
                    print(f"TinyPic处理错误: {e}")
                
                # 如果需要重试
                if attempt < self.retry_count - 1:
                    print(f"TinyPic重试中... ({attempt+1}/{self.retry_count})")
                    await asyncio.sleep(self.retry_delay)
            
            return False, size_before, 0
        except Exception as e:
            print(f"TinyPic优化过程错误: {e}")
            return False, size_before, 0

class LocalOptimizer(ImageOptimizer):
    """本地优化器 - 使用Pillow库进行本地压缩，作为最后备选"""
    
    def __init__(self, compression_mode: CompressionMode = CompressionMode.MEDIUM):
        self.compression_mode = compression_mode
    
    async def optimize(self, input_file: str, output_file: str, width: int = -1, 
                       options: Optional[Dict[str, Any]] = None) -> Tuple[bool, int, int]:
        """使用Pillow库本地压缩图像"""
        try:
            size_before = os.path.getsize(input_file)
            
            # 创建输出目录
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # 设置压缩参数
            quality = 85  # 默认中等质量
            if self.compression_mode == CompressionMode.LIGHT:
                quality = 92
            elif self.compression_mode == CompressionMode.MEDIUM:
                quality = 85
            elif self.compression_mode == CompressionMode.AGGRESSIVE:
                quality = 75
            
            # 打开并处理图像
            with Image.open(input_file) as img:
                # 调整大小（如果需要）
                if width > 0 and img.width > width:
                    ratio = width / img.width
                    height = int(img.height * ratio)
                    img = img.resize((width, height), Image.LANCZOS)
                
                # 保存图像
                _, ext = os.path.splitext(input_file)
                ext = ext.lower()
                
                if ext in ['.jpg', '.jpeg']:
                    img.save(output_file, 'JPEG', quality=quality, optimize=True)
                elif ext in ['.png']:
                    img.save(output_file, 'PNG', optimize=True)
                elif ext in ['.webp']:
                    img.save(output_file, 'WEBP', quality=quality, method=4)
                else:
                    # 对于其他格式，直接保存
                    img.save(output_file)
            
            size_after = os.path.getsize(output_file)
            return True, size_before, size_after
            
        except Exception as e:
            print(f"本地优化错误: {e}")
            # 出错时尝试复制原始文件
            try:
                shutil.copy2(input_file, output_file)
                return False, size_before, size_before
            except Exception as copy_error:
                print(f"复制原始文件错误: {copy_error}")
                return False, size_before, 0

class OptimizerManager:
    """优化器管理器 - 负责调度不同的优化器"""
    
    def __init__(self, api_key_manager: ApiKeyManager, config: Dict[str, Any]):
        self.api_key_manager = api_key_manager
        self.config = config
        self.lossless_optimizer = LosslessOptimizer()
        self.tinypng_optimizer = TinyPngOptimizer(
            api_key_manager, 
            retry_count=config['retry_count'],
            retry_delay=config['retry_delay']
        )
        self.tinypic_optimizer = TinyPicOptimizer(
            retry_count=config['retry_count'],
            retry_delay=config['retry_delay']
        )
        self.local_optimizer = LocalOptimizer(
            compression_mode=CompressionMode(config['local_optimization'])
        )
    
    async def optimize(self, input_file: str, output_file: str, width: int = -1, 
                      options: Optional[Dict[str, Any]] = None) -> Tuple[bool, int, int]:
        """按优先级调度不同的优化器"""
        original_size = os.path.getsize(input_file)
        print(f"正在优化: {os.path.basename(input_file)} ({format_size(original_size)})")
        
        # 创建临时文件
        temp_files = []
        try:
            # 创建3个临时文件
            for i in range(3):
                fd, temp_file = tempfile.mkstemp(suffix=os.path.splitext(input_file)[1])
                os.close(fd)
                temp_files.append(temp_file)
            
            temp_file1, temp_file2, temp_file3 = temp_files
            
            # 1. 首先进行无损压缩
            print("  - 第一级: 无损压缩中...")
            lossless_success, _, lossless_size = await self.lossless_optimizer.optimize(
                input_file, temp_file1, width, options)
            
            if lossless_success:
                print(f"  - 无损压缩完成: {format_size(lossless_size)} ({(lossless_size/original_size*100):.1f}%)")
            else:
                print("  - 无损压缩失败")
            
            # 使用无损压缩结果或原始文件
            next_input = temp_file1 if lossless_success else input_file
            next_size = lossless_size if lossless_success else original_size
            
            # 2. 然后尝试TinyPNG
            print("  - 第二级: TinyPNG处理中...")
            tinypng_success, _, tinypng_size = await self.tinypng_optimizer.optimize(
                next_input, temp_file2, width, options)
            
            if tinypng_success:
                print(f"  - TinyPNG完成: {format_size(tinypng_size)} ({(tinypng_size/original_size*100):.1f}%)")
                # TinyPNG成功
                shutil.copy2(temp_file2, output_file)
                final_success = True
                final_size = tinypng_size
            else:
                print("  - TinyPNG失败，尝试TinyPic...")
                # 3. TinyPNG失败，尝试TinyPic
                tinypic_success, _, tinypic_size = await self.tinypic_optimizer.optimize(
                    next_input, temp_file3, width, options)
                
                if tinypic_success:
                    print(f"  - TinyPic完成: {format_size(tinypic_size)} ({(tinypic_size/original_size*100):.1f}%)")
                    # TinyPic成功
                    shutil.copy2(temp_file3, output_file)
                    final_success = True
                    final_size = tinypic_size
                else:
                    print("  - TinyPic失败，使用本地优化...")
                    # 4. 所有在线优化器都失败，使用本地优化
                    local_success, _, local_size = await self.local_optimizer.optimize(
                        next_input, output_file, width, options)
                    
                    if local_success:
                        print(f"  - 本地优化完成: {format_size(local_size)} ({(local_size/original_size*100):.1f}%)")
                        final_success = True
                        final_size = local_size
                    else:
                        # 所有优化器都失败，使用无损结果或原始文件
                        if lossless_success:
                            print(f"  - 使用无损压缩结果: {format_size(lossless_size)}")
                            shutil.copy2(temp_file1, output_file)
                            final_success = True
                            final_size = lossless_size
                        else:
                            print(f"  - 所有压缩方法失败，使用原始文件")
                            shutil.copy2(input_file, output_file)
                            final_success = False
                            final_size = original_size
            
            return final_success, original_size, final_size
            
        except Exception as e:
            print(f"优化过程错误: {e}")
            # 出错时复制原始文件
            try:
                shutil.copy2(input_file, output_file)
            except Exception as copy_error:
                print(f"复制原始文件错误: {copy_error}")
            return False, original_size, original_size
            
        finally:
            # 清理临时文件
            for temp_file in temp_files:
                try:
                    if os.path.exists(temp_file):
                        os.unlink(temp_file)
                except Exception as e:
                    print(f"清理临时文件错误: {e}")
