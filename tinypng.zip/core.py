#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os
import json
import time
import random
import hashlib
import shutil  # 添加必要的shutil模块导入
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta

# 常量定义
VERSION = "4.0.0"
SUPPORTED_FORMATS = ('.png', '.webp', '.avif', '.jpg', '.jpeg')

# 压缩模式枚举
class CompressionMode(Enum):
    """压缩模式枚举，控制压缩强度"""
    NONE = 0
    LIGHT = 1
    MEDIUM = 2
    AGGRESSIVE = 3

@dataclass
class ApiKey:
    """API密钥管理类，追踪使用情况"""
    key: str
    uses: int = 0
    last_used: float = 0
    monthly_reset: float = field(default_factory=lambda: time.time() + 30*24*60*60)
    
    def is_available(self) -> bool:
        """检查密钥是否可用（未超过月度限制）"""
        current_time = time.time()
        if current_time > self.monthly_reset:
            self.uses = 0
            self.monthly_reset = current_time + 30*24*60*60
        return self.uses < 499  # 安全边界为1
    
    def use(self) -> None:
        """标记密钥为已使用"""
        self.uses += 1
        self.last_used = time.time()

class ApiKeyManager:
    """管理多个TinyPNG API密钥"""
    def __init__(self, api_keys_file, usage_data_file):
        self.api_keys_file = api_keys_file
        self.usage_data_file = usage_data_file
        self.keys: List[ApiKey] = []
        self.load_keys()
        self.load_usage_data()
    
    def load_keys(self) -> None:
        """从文件加载API密钥"""
        try:
            if os.path.exists(self.api_keys_file):
                with open(self.api_keys_file, 'r') as f:
                    for line in f:
                        key = line.strip()
                        if key:
                            self.keys.append(ApiKey(key=key))
            else:
                print(f"API密钥文件未找到：{self.api_keys_file}")
                raise FileNotFoundError(f"API密钥文件未找到：{self.api_keys_file}")
        except Exception as e:
            print(f"加载API密钥错误：{e}")
            raise
    
    def load_usage_data(self) -> None:
        """从文件加载使用数据"""
        if os.path.exists(self.usage_data_file):
            try:
                with open(self.usage_data_file, 'r') as f:
                    data = json.load(f)
                    for key_data in data:
                        for api_key in self.keys:
                            if api_key.key == key_data['key']:
                                api_key.uses = key_data.get('uses', 0)
                                api_key.last_used = key_data.get('last_used', 0)
                                api_key.monthly_reset = key_data.get('monthly_reset', time.time() + 30*24*60*60)
                                break
            except Exception as e:
                print(f"警告：无法加载使用数据：{e}")
    
    def save_usage_data(self) -> None:
        """保存使用数据到文件"""
        try:
            data = []
            for api_key in self.keys:
                data.append({
                    'key': api_key.key,
                    'uses': api_key.uses,
                    'last_used': api_key.last_used,
                    'monthly_reset': api_key.monthly_reset
                })
            
            os.makedirs(os.path.dirname(self.usage_data_file), exist_ok=True)
            
            # 先写入临时文件，然后重命名，避免损坏
            temp_file = f"{self.usage_data_file}.tmp"
            with open(temp_file, 'w') as f:
                json.dump(data, f)
            os.replace(temp_file, self.usage_data_file)
        except Exception as e:
            print(f"警告：无法保存使用数据：{e}")
    
    def get_next_key(self) -> str:
        """获取下一个可用的API密钥，策略是优先使用使用次数最少的密钥"""
        # 按使用量排序密钥
        available_keys = [k for k in self.keys if k.is_available()]
        
        if not available_keys:
            raise Exception("所有API密钥都已达到月度上限！")
            
        # 获取使用量最少的密钥
        next_key = min(available_keys, key=lambda k: k.uses)
        next_key.use()
        
        # 定期保存使用数据（非每次使用都保存）
        if random.random() < 0.1:  # 10%概率保存，减少I/O操作
            self.save_usage_data()
            
        return next_key.key
    
    def get_usage_summary(self) -> Dict[str, Any]:
        """获取API密钥使用情况摘要"""
        total_uses = sum(k.uses for k in self.keys)
        available_keys = sum(1 for k in self.keys if k.is_available())
        total_keys = len(self.keys)
        
        now = datetime.now()
        days_in_month = (datetime(now.year, now.month % 12 + 1, 1) - timedelta(days=1)).day
        days_passed = now.day
        
        return {
            'total_uses': total_uses,
            'available_keys': available_keys,
            'total_keys': total_keys,
            'capacity': total_keys * 500,
            'used_percent': (total_uses / (total_keys * 500)) * 100 if total_keys > 0 else 0,
            'days_passed': days_passed,
            'days_in_month': days_in_month
        }

class CompressionCache:
    """缓存已压缩文件，避免重复压缩"""
    def __init__(self, cache_file):
        self.cache_file = cache_file
        self.cache: Dict[str, Dict] = {}
        self.load_cache()
    
    def load_cache(self) -> None:
        """从文件加载缓存"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    self.cache = json.load(f)
            except Exception as e:
                print(f"警告：无法加载缓存：{e}")
                self.cache = {}
    
    def save_cache(self) -> None:
        """保存缓存到文件"""
        try:
            os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
            
            # 清理过期缓存（超过30天）
            current_time = time.time()
            expired_keys = []
            for file_path, cache_data in self.cache.items():
                if current_time - cache_data.get('timestamp', 0) > 30 * 24 * 60 * 60:
                    expired_keys.append(file_path)
            
            for key in expired_keys:
                del self.cache[key]
            
            # 保存缓存
            with open(self.cache_file, 'w') as f:
                json.dump(self.cache, f)
        except Exception as e:
            print(f"警告：无法保存缓存：{e}")
    
    def get_file_hash(self, file_path: str) -> str:
        """获取文件哈希用于缓存查找"""
        try:
            # 对于大文件，只哈希前1MB和文件大小
            file_size = os.path.getsize(file_path)
            
            if file_size > 1024 * 1024:  # 1MB
                with open(file_path, 'rb') as f:
                    data = f.read(1024 * 1024)  # 读取前1MB
                file_hash = hashlib.md5(data).hexdigest()
                # 结合文件大小确保唯一性
                return f"{file_hash}_{file_size}"
            else:
                with open(file_path, 'rb') as f:
                    file_hash = hashlib.md5(f.read()).hexdigest()
                return file_hash
        except Exception:
            # 如果无法哈希文件，返回时间戳确保处理
            return f"error_{time.time()}"
    
    def needs_compression(self, file_path: str, width: int) -> bool:
        """根据缓存检查文件是否需要压缩"""
        file_hash = self.get_file_hash(file_path)
        file_mod_time = os.path.getmtime(file_path)
        
        if file_path in self.cache:
            cached_data = self.cache[file_path]
            # 检查文件是否已更改或宽度不同
            if (cached_data.get('hash') == file_hash and 
                cached_data.get('mtime') == file_mod_time and 
                cached_data.get('width') == width):
                return False
        
        return True
    
    def update_cache(self, file_path: str, output_path: str, width: int) -> None:
        """成功压缩后更新缓存"""
        file_hash = self.get_file_hash(file_path)
        file_mod_time = os.path.getmtime(file_path)
        
        self.cache[file_path] = {
            'hash': file_hash,
            'mtime': file_mod_time,
            'output': output_path,
            'width': width,
            'timestamp': time.time()
        }
        
        # 定期保存缓存
        if random.random() < 0.05:  # 5%概率保存，减少I/O操作
            self.save_cache()

# 配置管理函数
def load_config(config_file: str) -> Dict[str, Any]:
    """加载配置"""
    default_config = {
        'output_dir': 'tiny',
        'default_width': -1,
        'max_workers': 150,
        'retry_count': 3,
        'retry_delay': 2,
        'local_optimization': CompressionMode.NONE.value,
        'respect_exif': True,
        'backup_enabled': True
    }
    
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                saved_config = json.load(f)
                default_config.update(saved_config)
        except Exception as e:
            print(f"警告：无法加载配置：{e}")
    
    return default_config

def save_config(config: Dict[str, Any], config_file: str) -> None:
    """保存配置"""
    try:
        os.makedirs(os.path.dirname(config_file), exist_ok=True)
        with open(config_file, 'w') as f:
            json.dump(config, f)
    except Exception as e:
        print(f"警告：无法保存配置：{e}")

# 工具函数
def format_size(size_bytes: int) -> str:
    """格式化文件大小为人类可读格式"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.1f} MB"

def format_time(seconds: float) -> str:
    """格式化时间为人类可读格式"""
    if seconds < 60:
        return f"{seconds:.1f} 秒"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        secs = int(seconds % 60)
        return f"{minutes}分 {secs}秒"
    else:
        hours = int(seconds / 3600)
        minutes = int((seconds % 3600) / 60)
        return f"{hours}小时 {minutes}分"